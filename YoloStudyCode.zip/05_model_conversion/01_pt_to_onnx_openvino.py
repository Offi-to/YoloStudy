from ultralytics import YOLO

# Load a model
# model = YOLO(r'C:\Users\30855\Desktop\Offi_Data\Data1\yolov8n.pt')  # load an official model
model = YOLO(r"E:\download\yolov8_garlic_2026_5_24\root\autodl-tmp\garlic\runs\detect\train3\weights\garlic_5_24_yolov8_640x640.pt")  # load a custom trained

# Export the model
model.export(format='onnx')
# model.export(format='openvino')
# 二选一