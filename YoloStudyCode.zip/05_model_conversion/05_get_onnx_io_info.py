import onnxruntime as ort

# 创建推理会话
providers = ["CPUExecutionProvider"]
session_options = ort.SessionOptions()
session_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
session = ort.InferenceSession(r"C:\Users\30855\Desktop\trainer\garlic_identify2.onnx", session_options=session_options, providers=providers)

# 获取输入信息
inputs_info = session.get_inputs()
print("模型输入信息:")
for input in inputs_info:
    print(f"名称: {input.name}, 形状: {input.shape}, 类型: {input.type}")

# 获取输出信息
outputs_info = session.get_outputs()
print("\n模型输出信息:")
for output in outputs_info:
    print(f"名称: {output.name}, 形状: {output.shape}, 类型: {output.type}")