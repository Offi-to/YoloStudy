"""
简化版ONNX导出脚本
"""

import os
from ultralytics import YOLO

def simple_export():
    """最简单的导出方法"""

    # 模型路径
    weights_path = r"C:\Users\30855\Desktop\trainer\runs\detect\train\weights\best.pt"
    output_dir = r"C:\Users\30855\Desktop"

    try:
        # 加载模型
        model = YOLO(weights_path)

        # 导出ONNX
        model.export(
            format='onnx',
            imgsz=640,
            dynamic=False,
            simplify=True,
            opset=12
        )

        print("✅ 导出完成！")
        print("📁 生成的ONNX文件在模型同目录下")

    except Exception as e:
        print(f"❌ 导出失败: {e}")
        print("💡 尝试在命令行中运行:")
        print(f'python -c "from ultralytics import YOLO; YOLO(\'{weights_path}\').export(format=\'onnx\')"')

if __name__ == "__main__":
    simple_export()