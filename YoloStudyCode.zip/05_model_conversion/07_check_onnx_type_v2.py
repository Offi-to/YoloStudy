import onnx
import os
import numpy as np

model_path = r"C:\Users\30855\Desktop\trainer\garlic_identify2.onnx"

# 首先，检查模型文件是否存在
if not os.path.isfile(model_path):
    raise FileNotFoundError(f"未找到模型文件: {model_path}")

try:
    # 加载模型
    model = onnx.load(model_path)

    # 打印模型基本信息
    print(f"Producer name: {model.producer_name}")
    print(f"Producer version: {model.producer_version}")
    print(f"Domain: {model.domain}")

    # 操作集版本信息可能有多个，通常我们关心第一个
    for i, opset in enumerate(model.opset_import):
        print(f"Opset {i} version: {opset.version} | Domain: {opset.domain}")

    # 可选：验证模型格式是否正确
    onnx.checker.check_model(model)
    print("模型格式检查通过。")

except onnx.checker.ValidationError as e:
    print(f"模型验证失败: {e}")
    # 你可以尝试使用 onnx.utils.polish_model 来修复一些简单的错误
    # polished_model = onnx.utils.polish_model(model)
    # onnx.save(polished_model, 'polished_model.onnx')
except Exception as e:
    print(f"加载或检查模型时发生错误: {e}")


