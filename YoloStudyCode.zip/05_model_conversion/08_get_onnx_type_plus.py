import onnx
from onnx import numpy_helper
import onnxruntime as ort
import json


def parse_onnx_model(model_path):
    """
    解析ONNX模型，输出模型结构、节点信息、权重等详细信息，
    并尝试从元数据中查找可能的数据集信息。
    """
    # 加载ONNX模型
    model = onnx.load(r"E:\download\garlic2026_3_23\root\autodl-tmp\garlic\runs\detect\train2\weights\garlic-2026-3-23.onnx")

    # 打印模型基本元数据信息
    print("=" * 50)
    print("模型基本信息")
    print("=" * 50)
    print(f"IR 版本: {model.ir_version}")
    print(f"生产者名称: {model.producer_name}")
    print(f"生产者版本: {model.producer_version}")
    print(f"域名: {model.domain}")
    print(f"模型版本: {model.model_version}")
    print(f"文档字符串: {model.doc_string}")

    # 打印运算符集信息
    print("\n" + "=" * 50)
    print("运算符集信息")
    print("=" * 50)
    for opset in model.opset_import:
        print(f"域名: '{opset.domain}', 版本: {opset.version}")

    # 打印图形输入信息
    print("\n" + "=" * 50)
    print("输入信息")
    print("=" * 50)
    for input in model.graph.input:
        print(f"名称: {input.name}")
        tensor_type = input.type.tensor_type
        print(f"  数据类型: {tensor_type.elem_type}")
        if tensor_type.HasField("shape"):
            dims = []
            for dim in tensor_type.shape.dim:
                if dim.HasField("dim_value"):
                    dims.append(str(dim.dim_value))
                elif dim.HasField("dim_param"):
                    dims.append(dim.dim_param)
                else:
                    dims.append("?")
            print(f"  形状: [{', '.join(dims)}]")
        print()

    # 打印图形输出信息
    print("\n" + "=" * 50)
    print("输出信息")
    print("=" * 50)
    for output in model.graph.output:
        print(f"名称: {output.name}")
        tensor_type = output.type.tensor_type
        print(f"  数据类型: {tensor_type.elem_type}")
        if tensor_type.HasField("shape"):
            dims = []
            for dim in tensor_type.shape.dim:
                if dim.HasField("dim_value"):
                    dims.append(str(dim.dim_value))
                elif dim.HasField("dim_param"):
                    dims.append(dim.dim_param)
                else:
                    dims.append("?")
            print(f"  形状: [{', '.join(dims)}]")
        print()

    # 打印初始器信息（权重和偏置）
    print("\n" + "=" * 50)
    print("初始器信息 (权重/偏置)")
    print("=" * 50)
    for initializer in model.graph.initializer:
        print(f"名称: {initializer.name}")
        print(f"  数据类型: {initializer.data_type}")
        print(f"  维度: {initializer.dims}")
        # 对于大型权重矩阵，不打印具体数值
        if len(initializer.dims) > 0 and sum(initializer.dims) < 10:
            value_array = numpy_helper.to_array(initializer)
            print(f"  值: {value_array}")
        print()

    # 尝试提取元数据属性，这里可能包含训练信息
    print("\n" + "=" * 50)
    print("元数据属性 (可能包含训练信息)")
    print("=" * 50)
    if hasattr(model, 'metadata_props') and model.metadata_props:
        for prop in model.metadata_props:
            print(f"{prop.key}: {prop.value}")
    else:
        print("未找到元数据属性")

    # 检查图形级别的元数据
    if hasattr(model.graph, 'metadata_props') and model.graph.metadata_props:
        print("\n图形级别元数据:")
        for prop in model.graph.metadata_props:
            print(f"{prop.key}: {prop.value}")

    # 使用ONNX Runtime获取额外信息
    print("\n" + "=" * 50)
    print("ONNX Runtime 信息")
    print("=" * 50)
    try:
        sess = ort.InferenceSession(model_path)
        input_info = sess.get_inputs()
        output_info = sess.get_outputs()

        print("输入详细信息:")
        for input in input_info:
            print(f"  名称: {input.name}, 形状: {input.shape}, 类型: {input.type}")

        print("\n输出详细信息:")
        for output in output_info:
            print(f"  名称: {output.name}, 形状: {output.shape}, 类型: {output.type}")

    except Exception as e:
        print(f"ONNX Runtime 错误: {e}")

    # 特别关注：尝试查找可能的类别标签信息
    print("\n" + "=" * 50)
    print("尝试查找类别信息")
    print("=" * 50)

    # 方法1: 检查元数据中是否包含类别信息
    found_classes = False
    if hasattr(model, 'metadata_props') and model.metadata_props:
        for prop in model.metadata_props:
            if 'class' in prop.key.lower() or 'name' in prop.key.lower():
                print(f"可能包含类别信息 - {prop.key}: {prop.value}")
                found_classes = True
            # 尝试解析JSON格式的元数据
            if prop.key == 'names' or prop.key == 'classes':
                try:
                    names = json.loads(prop.value)
                    print(f"解析出的类别名称: {names}")
                except:
                    print(f"类别名称(可能需进一步解析): {prop.value}")

    # 方法2: 检查输出节点名称，有时会包含类别信息
    for output in model.graph.output:
        if 'class' in output.name.lower() or 'score' in output.name.lower():
            print(f"输出节点 {output.name} 可能包含类别预测信息")

    if not found_classes:
        print("未在元数据中找到明确的类别信息。")
        print("提示: 训练数据集信息通常不会直接存储在ONNX模型中。")
        print("您可能需要参考原始训练配置或文档。")


# 使用示例
if __name__ == "__main__":
    model_path = "your_model.onnx"  # 替换为你的ONNX模型路径
    parse_onnx_model(model_path)