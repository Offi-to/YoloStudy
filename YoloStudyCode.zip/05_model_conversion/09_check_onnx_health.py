import cv2
import numpy as np
import os
from datetime import datetime


def sigmoid(x):
    """Sigmoid函数"""
    return 1.0 / (1.0 + np.exp(-x))


def analyze_detailed_output(output):
    """
    详细分析模型输出
    """
    batch_size, num_features, num_detections = output.shape

    print(f"\n=== 详细输出分析 ===")
    print(f"输出形状: [{batch_size}, {num_features}, {num_detections}]")

    # 分析不同部分的检测框
    print(f"\n=== 不同位置的检测框分析 ===")

    # 检查前10个检测框
    print("前10个检测框:")
    for i in range(min(10, num_detections)):
        cx, cy, w, h = output[0, 0, i], output[0, 1, i], output[0, 2, i], output[0, 3, i]
        score0, score1 = output[0, 4, i], output[0, 5, i]

        # 应用sigmoid
        conf0, conf1 = sigmoid(score0), sigmoid(score1)
        confidence = max(conf0, conf1)
        class_id = 0 if conf0 > conf1 else 1

        print(f"框{i:4d}: cx={cx:8.2f}, cy={cy:8.2f}, w={w:8.2f}, h={h:8.2f}, "
              f"score0={score0:10.6f}, score1={score1:10.6f}, "
              f"conf={confidence:.6f}, class={class_id}")

    # 检查中间的一些检测框
    print(f"\n中间10个检测框 (索引4000-4010):")
    for i in range(4000, min(4010, num_detections)):
        cx, cy, w, h = output[0, 0, i], output[0, 1, i], output[0, 2, i], output[0, 3, i]
        score0, score1 = output[0, 4, i], output[0, 5, i]

        conf0, conf1 = sigmoid(score0), sigmoid(score1)
        confidence = max(conf0, conf1)

        print(f"框{i:4d}: cx={cx:8.2f}, cy={cy:8.2f}, "
              f"conf={confidence:.6f}")

    # 检查最后10个检测框
    print(f"\n最后10个检测框:")
    for i in range(max(0, num_detections - 10), num_detections):
        cx, cy, w, h = output[0, 0, i], output[0, 1, i], output[0, 2, i], output[0, 3, i]
        score0, score1 = output[0, 4, i], output[0, 5, i]

        conf0, conf1 = sigmoid(score0), sigmoid(score1)
        confidence = max(conf0, conf1)

        print(f"框{i:4d}: cx={cx:8.2f}, cy={cy:8.2f}, "
              f"conf={confidence:.6f}")

    # 统计置信度分布
    confidence_levels = [0.7, 0.5, 0.3, 0.1, 0.01, 0.001, 0.0001]
    counts = [0] * len(confidence_levels)

    for i in range(num_detections):
        score0, score1 = output[0, 4, i], output[0, 5, i]
        conf0, conf1 = sigmoid(score0), sigmoid(score1)
        confidence = max(conf0, conf1)

        for j, threshold in enumerate(confidence_levels):
            if confidence > threshold:
                counts[j] += 1
                break
        else:
            # 低于最低阈值
            counts[-1] += 1

    print(f"\n=== 置信度分布 ===")
    for i, threshold in enumerate(confidence_levels):
        print(f"置信度 > {threshold}: {counts[i]} 个检测框")

    # 检查坐标统计
    all_cx = output[0, 0, :]
    all_cy = output[0, 1, :]
    all_w = output[0, 2, :]
    all_h = output[0, 3, :]

    print(f"\n=== 坐标统计 ===")
    print(f"cx - 最小值: {np.min(all_cx):.2f}, 最大值: {np.max(all_cx):.2f}, 平均值: {np.mean(all_cx):.2f}")
    print(f"cy - 最小值: {np.min(all_cy):.2f}, 最大值: {np.max(all_cy):.2f}, 平均值: {np.mean(all_cy):.2f}")
    print(f"w - 最小值: {np.min(all_w):.2f}, 最大值: {np.max(all_w):.2f}, 平均值: {np.mean(all_w):.2f}")
    print(f"h - 最小值: {np.min(all_h):.2f}, 最大值: {np.max(all_h):.2f}, 平均值: {np.mean(all_h):.2f}")

    # 检查是否有任何高置信度检测
    high_conf_indices = []
    for i in range(num_detections):
        score0, score1 = output[0, 4, i], output[0, 5, i]
        conf0, conf1 = sigmoid(score0), sigmoid(score1)
        confidence = max(conf0, conf1)

        if confidence > 0.25:  # 您的阈值
            high_conf_indices.append(i)

    print(f"\n=== 高置信度检测框 (>{0.25}) ===")
    print(f"数量: {len(high_conf_indices)}")

    if high_conf_indices:
        print("前5个高置信度检测框:")
        for i in high_conf_indices[:5]:
            cx, cy, w, h = output[0, 0, i], output[0, 1, i], output[0, 2, i], output[0, 3, i]
            score0, score1 = output[0, 4, i], output[0, 5, i]
            conf0, conf1 = sigmoid(score0), sigmoid(score1)
            confidence = max(conf0, conf1)
            class_id = 0 if conf0 > conf1 else 1

            print(f"框{i}: cx={cx:.2f}, cy={cy:.2f}, w={w:.2f}, h={h:.2f}, "
                  f"conf={confidence:.4f}, class={class_id}")


def test_with_different_images(onnx_path):
    """
    使用不同的测试图像进行测试
    """
    print("\n=== 使用不同图像测试 ===")

    net = cv2.dnn.readNetFromONNX(onnx_path)

    # 测试1: 纯黑图像
    print("\n1. 测试纯黑图像...")
    black_img = np.zeros((640, 640, 3), dtype=np.uint8)
    test_image(black_img, "纯黑图像", net)

    # 测试2: 纯白图像
    print("\n2. 测试纯白图像...")
    white_img = np.full((640, 640, 3), 255, dtype=np.uint8)
    test_image(white_img, "纯白图像", net)

    # 测试3: 灰色图像
    print("\n3. 测试灰色图像...")
    gray_img = np.full((640, 640, 3), 128, dtype=np.uint8)
    test_image(gray_img, "灰色图像", net)

    # 测试4: 带有简单形状的图像
    print("\n4. 测试带有形状的图像...")
    shape_img = np.full((640, 640, 3), 128, dtype=np.uint8)
    cv2.rectangle(shape_img, (100, 100), (200, 200), (0, 255, 0), -1)
    cv2.rectangle(shape_img, (400, 300), (500, 400), (255, 0, 0), -1)
    cv2.circle(shape_img, (320, 320), 50, (0, 0, 255), -1)
    test_image(shape_img, "形状图像", net)

    # 测试5: 实际图像（如果存在）
    real_img_path = r"C:\Users\30855\Desktop\frame1_00056.jpg"
    if os.path.exists(real_img_path):
        print("\n5. 测试实际图像...")
        real_img = cv2.imread(real_img_path)
        if real_img is not None:
            # 调整大小为640x640
            real_img = cv2.resize(real_img, (640, 640))
            test_image(real_img, "实际图像", net)
        else:
            print("无法读取实际图像")
    else:
        print(f"\n5. 跳过实际图像测试（未找到 {real_img_path}）")


def test_image(img, img_name, net):
    """
    测试单张图像
    """
    # 预处理
    blob = cv2.dnn.blobFromImage(img, 1.0 / 255.0, (640, 640), (0, 0, 0), True, False)

    # 推理
    net.setInput(blob)
    start_time = datetime.now()
    output = net.forward()
    end_time = datetime.now()

    inference_time = (end_time - start_time).total_seconds() * 1000

    # 分析输出
    batch_size, num_features, num_detections = output.shape

    # 计算平均置信度
    total_confidence = 0
    max_confidence = 0
    high_conf_count = 0

    for i in range(num_detections):
        score0, score1 = output[0, 4, i], output[0, 5, i]
        conf0, conf1 = sigmoid(score0), sigmoid(score1)
        confidence = max(conf0, conf1)

        total_confidence += confidence
        max_confidence = max(max_confidence, confidence)
        if confidence > 0.25:
            high_conf_count += 1

    avg_confidence = total_confidence / num_detections

    print(f"{img_name}:")
    print(f"  推理时间: {inference_time:.2f}ms")
    print(f"  平均置信度: {avg_confidence:.6f}")
    print(f"  最大置信度: {max_confidence:.6f}")
    print(f"  高置信度框数量(>0.25): {high_conf_count}")

    # 如果有高置信度检测，显示前3个
    if high_conf_count > 0:
        high_conf_indices = []
        for i in range(min(1000, num_detections)):  # 只检查前1000个以提高速度
            score0, score1 = output[0, 4, i], output[0, 5, i]
            conf0, conf1 = sigmoid(score0), sigmoid(score1)
            confidence = max(conf0, conf1)

            if confidence > 0.25:
                high_conf_indices.append((i, confidence))

        # 按置信度排序
        high_conf_indices.sort(key=lambda x: x[1], reverse=True)

        print("  前3个高置信度检测框:")
        for idx, (i, confidence) in enumerate(high_conf_indices[:3]):
            cx, cy = output[0, 0, i], output[0, 1, i]
            print(f"    框{i}: cx={cx:.2f}, cy={cy:.2f}, conf={confidence:.4f}")


def main():
    onnx_path = r"C:\Users\30855\Desktop\trainer\garlic_identify1_.onnx"

    print("=== 详细ONNX模型诊断工具 ===")

    # 检查ONNX文件是否存在
    if not os.path.exists(onnx_path):
        print(f"错误: ONNX文件不存在: {onnx_path}")
        return

    # 加载模型
    net = cv2.dnn.readNetFromONNX(onnx_path)
    print("成功加载ONNX模型")

    # 创建测试图像
    test_img = np.zeros((640, 640, 3), dtype=np.uint8)
    cv2.rectangle(test_img, (100, 100), (200, 200), (0, 255, 0), -1)
    cv2.rectangle(test_img, (400, 300), (500, 400), (255, 0, 0), -1)

    # 预处理
    blob = cv2.dnn.blobFromImage(test_img, 1.0 / 255.0, (640, 640), (0, 0, 0), True, False)
    print(f"输入blob形状: {blob.shape}")

    # 推理
    net.setInput(blob)
    start_time = datetime.now()
    output = net.forward()
    end_time = datetime.now()

    inference_time = (end_time - start_time).total_seconds() * 1000
    print(f"推理时间: {inference_time:.2f}ms")
    print(f"输出形状: {output.shape}")

    # 详细分析输出
    analyze_detailed_output(output)

    # 使用不同图像测试
    test_with_different_images(onnx_path)

    print("\n=== 诊断完成 ===")


if __name__ == "__main__":
    main()