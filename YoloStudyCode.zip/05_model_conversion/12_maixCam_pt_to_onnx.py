from ultralytics import YOLO
import torch

# 临时规避 PyTorch 2.4.0 Windows CPU 问题
torch.backends.cudnn.enabled = False

# 加载你的 YOLO 模型
model = YOLO(r"C:\Users\30855\Desktop\大蒜-抄论文方案\runs\detect\garlic_2026_2_202\weights\best.pt")

# 核心：只保留所有版本都支持的基础参数，确保不报错
# 无后处理的关键：YOLO 默认导出的 ONNX 若只保留基础参数，就是原始检测头输出（无 NMS）
model.export(
    format="onnx",        # 必须：导出 ONNX 格式
    imgsz=640,            # 必须：固定输入尺寸，适配 MaixCAM
    opset=12,             # 必须：MaixCAM 兼容的 opset 版本
    simplify=True,        # 推荐：简化模型，减少转换问题
    batch=1,              # 推荐：固定 batch=1，嵌入式平台专用
    dynamic=False         # 推荐：关闭动态尺寸，避免 MaixCAM 量化报错
)

print("✅ 导出完成！ONNX 文件在 best.pt 同目录下")
