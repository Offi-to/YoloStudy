import onnx
import onnx2pytorch
import torch

# 加载ONNX模型
onnx_model = onnx.load(r"C:\Users\30855\Desktop\buff.onnx")
onnx.checker.check_model(onnx_model) # 可选，检查模型是否有效

# 转换为PyTorch模型
pytorch_model = onnx2pytorch.ConvertModel(onnx_model)

# 现在你可以像使用普通PyTorch模型一样使用它
# 例如：保存为.pt文件
torch.save(pytorch_model.state_dict(), r"buff.pt")