import onnxruntime as ort

# 加载模型并创建推理会话
sess = ort.InferenceSession(r"C:\Users\30855\Desktop\dataset_split\garlicIdentify.onnx")

# 获取输出信息
outputs_info = sess.get_outputs()
for output_info in outputs_info:
    print(f"Output name: {output_info.name}")
    print(f"Shape: {output_info.shape}")
    print(f"Data type: {output_info.type}")