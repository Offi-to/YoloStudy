#!/usr/bin/env python3

# Copyright (C) 2018-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


if __name__ == "__main__":
    from openvino.tools.mo.subprocess_main import subprocess_main
    from openvino.tools.mo.utils.telemetry_utils import init_mo_telemetry
    init_mo_telemetry()
    subprocess_main(framework='onnx')


'''
python mo_onnx.py文件路径 --input_model(被转换的onnx模型路径) --output_dir(输出的模型文件夹路径)
python r'C:/Users/30855/Desktop/Offi_Data/Data1/7pt_zhuan_opennvino.py' --input_model r'C:/Users/30855/Desktop/Offi_Data/Data1/yolov8n.onnx' --output_dir r'E:/RM_DATAS/my_File/my_test'
'''