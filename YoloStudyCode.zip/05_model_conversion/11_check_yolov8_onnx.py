import onnxruntime as ort
import numpy as np
import cv2
import os
import matplotlib.pyplot as plt
from PIL import Image
import onnx


def sigmoid(x):
    """Sigmoid函数"""
    return 1 / (1 + np.exp(-x))


def load_yolov8_onnx_model(model_path):
    """
    加载YOLOv8 ONNX模型
    """
    try:
        print(f"尝试加载ONNX模型: {model_path}")

        # 首先用onnx检查模型结构
        onnx_model = onnx.load(model_path)
        onnx.checker.check_model(onnx_model)
        print("ONNX模型结构检查通过!")

        # 创建推理会话
        providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']  # 优先使用CUDA
        session = ort.InferenceSession(model_path, providers=providers)

        # 获取输入输出信息
        input_info = session.get_inputs()
        output_info = session.get_outputs()

        print("模型加载成功!")
        print(f"输入名称: {input_info[0].name}")
        print(f"输入形状: {input_info[0].shape}")
        print(f"输入数据类型: {input_info[0].type}")
        print(f"输出名称: {output_info[0].name}")
        print(f"输出形状: {output_info[0].shape}")
        print(f"输出数据类型: {output_info[0].type}")

        return session, input_info, output_info

    except Exception as e:
        print(f"加载模型失败: {e}")
        return None, None, None


def analyze_yolov8_output_structure(output_data, confidence_threshold=0.25):
    """
    分析YOLOv8输出数据结构
    """
    print("\n=== 分析YOLOv8输出结构 ===")

    if isinstance(output_data, list):
        output_tensor = output_data[0]  # YOLOv8 ONNX通常只有一个输出
    else:
        output_tensor = output_data

    print(f"输出张量形状: {output_tensor.shape}")

    # YOLOv8输出格式通常是 [1, 6, 8400] 或类似
    # 其中6表示: [cx, cy, w, h, confidence, class_score] 或类似格式
    batch_size, num_features, num_anchors = output_tensor.shape

    print(f"批次大小: {batch_size}")
    print(f"特征数量: {num_features}")
    print(f"锚点数量: {num_anchors}")

    # 取第一个批次
    output = output_tensor[0]  # 形状: [num_features, num_anchors]

    # 转置为 [num_anchors, num_features] 便于处理
    output = output.T
    print(f"转置后形状: {output.shape}")

    return output, num_features, num_anchors


def parse_yolov8_detections(output, num_features, confidence_threshold=0.25):
    """
    解析YOLOv8检测结果[1,6](@ref)
    """
    print("\n=== 解析YOLOv8检测结果 ===")

    detections = []

    # YOLOv8输出格式通常是 [cx, cy, w, h, obj_conf, class_conf...]
    # 对于2个类别，num_features应该是6: [cx, cy, w, h, obj_conf, class1_conf, class2_conf]
    # 但根据您的模型输出[1, 6, 8400]，可能是[cx, cy, w, h, obj_conf, best_class_conf]

    for i, detection in enumerate(output):
        if num_features >= 6:
            # 提取基础信息
            cx, cy, w, h = detection[0], detection[1], detection[2], detection[3]
            obj_conf = detection[4]

            # 处理类别分数
            if num_features == 6:  # 可能是二分类，只有一个类别分数
                class_scores = np.array([detection[5], 1 - detection[5]])  # 假设二分类
            else:  # 多分类
                class_scores = detection[5:num_features]

            # 应用sigmoid（YOLOv8输出通常需要sigmoid）
            cx_sigmoid = sigmoid(cx)
            cy_sigmoid = sigmoid(cy)
            w_sigmoid = sigmoid(w)
            h_sigmoid = sigmoid(h)
            obj_conf_sigmoid = sigmoid(obj_conf)
            class_scores_sigmoid = sigmoid(class_scores)

            # 找到最可能的类别
            class_id = np.argmax(class_scores_sigmoid)
            class_conf = class_scores_sigmoid[class_id]

            # 计算最终置信度
            final_conf = obj_conf_sigmoid * class_conf

            if final_conf > confidence_threshold:
                detections.append({
                    'index': i,
                    'cx': cx_sigmoid,
                    'cy': cy_sigmoid,
                    'w': w_sigmoid,
                    'h': h_sigmoid,
                    'obj_conf': obj_conf_sigmoid,
                    'class_conf': class_conf,
                    'final_conf': final_conf,
                    'class_id': class_id,
                    'raw_output': detection
                })

    print(f"找到 {len(detections)} 个高置信度检测框(>{confidence_threshold})")

    # 显示前5个检测框的详细信息
    for i, det in enumerate(detections[:5]):
        print(f"  检测框{i}: class={det['class_id']}, conf={det['final_conf']:.4f}, "
              f"cx={det['cx']:.4f}, cy={det['cy']:.4f}, w={det['w']:.4f}, h={det['h']:.4f}")

    return detections


def non_max_suppression(detections, iou_threshold=0.45):
    """
    非极大值抑制[1](@ref)
    """
    if len(detections) == 0:
        return []

    # 按置信度排序
    detections = sorted(detections, key=lambda x: x['final_conf'], reverse=True)

    keep = []

    while detections:
        # 取置信度最高的检测框
        current = detections.pop(0)
        keep.append(current)

        # 计算与剩余检测框的IoU
        to_remove = []
        for i, det in enumerate(detections):
            iou = calculate_iou(current, det)
            if iou > iou_threshold:
                to_remove.append(i)

        # 移除重叠的检测框（从后往前移除避免索引问题）
        for i in sorted(to_remove, reverse=True):
            detections.pop(i)

    print(f"NMS后保留 {len(keep)} 个检测框")
    return keep


def calculate_iou(box1, box2):
    """
    计算两个边界框的IoU
    """
    # 将中心坐标转换为角坐标
    x1_1 = box1['cx'] - box1['w'] / 2
    y1_1 = box1['cy'] - box1['h'] / 2
    x2_1 = box1['cx'] + box1['w'] / 2
    y2_1 = box1['cy'] + box1['h'] / 2

    x1_2 = box2['cx'] - box2['w'] / 2
    y1_2 = box2['cy'] - box2['h'] / 2
    x2_2 = box2['cx'] + box2['w'] / 2
    y2_2 = box2['cy'] + box2['h'] / 2

    # 计算交集区域
    xi1 = max(x1_1, x1_2)
    yi1 = max(y1_1, y1_2)
    xi2 = min(x2_1, x2_2)
    yi2 = min(y2_1, y2_2)

    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)

    # 计算并集区域
    box1_area = box1['w'] * box1['h']
    box2_area = box2['w'] * box2['h']
    union_area = box1_area + box2_area - inter_area

    return inter_area / union_area if union_area > 0 else 0


def test_onnx_with_image(session, input_info, image_path, class_names=None):
    """
    使用实际图像测试ONNX模型[3](@ref)
    """
    print(f"\n=== 使用实际图像测试: {image_path} ===")

    if not os.path.exists(image_path):
        print(f"图像文件不存在: {image_path}")
        return None, None

    # 加载和预处理图像
    img = cv2.imread(image_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    original_h, original_w = img_rgb.shape[:2]
    print(f"原始图像大小: {original_w}x{original_h}")

    # 调整大小为模型输入尺寸 (640x640)
    input_size = 640
    img_resized = cv2.resize(img_rgb, (input_size, input_size))

    # 归一化并转换为CHW格式
    img_normalized = img_resized.astype(np.float32) / 255.0
    img_chw = np.transpose(img_normalized, (2, 0, 1))
    img_batch = np.expand_dims(img_chw, axis=0)

    print(f"预处理后输入形状: {img_batch.shape}")

    # 推理
    input_name = input_info[0].name
    outputs = session.run(None, {input_name: img_batch})

    # 分析输出
    output_tensor, num_features, num_anchors = analyze_yolov8_output_structure(outputs)
    detections = parse_yolov8_detections(output_tensor, num_features)

    # 应用NMS
    final_detections = non_max_suppression(detections)

    # 可视化结果
    visualize_yolov8_detections(final_detections, img_rgb, class_names, input_size)

    return final_detections, outputs


def visualize_yolov8_detections(detections, original_img, class_names=None, input_size=640):
    """
    可视化YOLOv8检测结果[6,8](@ref)
    """
    print("\n=== 可视化检测结果 ===")

    if class_names is None:
        class_names = {0: 'garlic', 1: 'head'}  # 根据您的模型类别设置

    img_draw = original_img.copy()
    original_h, original_w = original_img.shape[:2]

    # 计算缩放比例
    scale_x = original_w / input_size
    scale_y = original_h / input_size

    print(f"检测到 {len(detections)} 个目标")

    # 绘制每个检测框
    for i, det in enumerate(detections):
        # 将归一化坐标转换为像素坐标
        cx = det['cx'] * original_w
        cy = det['cy'] * original_h
        w = det['w'] * original_w
        h = det['h'] * original_h

        # 计算角坐标
        x1 = int(cx - w / 2)
        y1 = int(cy - h / 2)
        x2 = int(cx + w / 2)
        y2 = int(cy + h / 2)

        # 确保坐标在图像范围内
        x1 = max(0, min(x1, original_w - 1))
        y1 = max(0, min(y1, original_h - 1))
        x2 = max(0, min(x2, original_w - 1))
        y2 = max(0, min(y2, original_h - 1))

        # 选择颜色
        colors = [(0, 255, 0), (255, 0, 0), (0, 0, 255)]  # 绿色, 红色, 蓝色
        color = colors[det['class_id'] % len(colors)]

        # 绘制边界框
        cv2.rectangle(img_draw, (x1, y1), (x2, y2), color, 2)

        # 绘制标签
        class_name = class_names.get(det['class_id'], f'class_{det["class_id"]}')
        label = f"{class_name}: {det['final_conf']:.2f}"

        # 计算文本背景
        (text_width, text_height), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)
        cv2.rectangle(img_draw, (x1, y1 - text_height - baseline),
                      (x1 + text_width, y1), color, -1)

        cv2.putText(img_draw, label, (x1, y1 - baseline),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

    # 显示结果对比
    plt.figure(figsize=(15, 5))

    plt.subplot(1, 3, 1)
    plt.imshow(original_img)
    plt.title("原始图像")
    plt.axis('off')

    plt.subplot(1, 3, 2)
    plt.imshow(img_draw)
    plt.title(f"检测结果 ({len(detections)} 个目标)")
    plt.axis('off')

    # 统计信息
    plt.subplot(1, 3, 3)
    plt.axis('off')

    stats_text = "检测统计:\n\n"
    class_counts = {}
    for det in detections:
        class_id = det['class_id']
        class_counts[class_id] = class_counts.get(class_id, 0) + 1

    for class_id, count in class_counts.items():
        class_name = class_names.get(class_id, f'class_{class_id}')
        stats_text += f"{class_name}: {count} 个\n"

    stats_text += f"\n总检测数: {len(detections)}"

    plt.text(0.1, 0.9, stats_text, fontsize=12, fontweight='bold',
             verticalalignment='top', transform=plt.gca().transAxes)

    plt.tight_layout()
    plt.savefig('yolov8_onnx_detection_result.jpg', dpi=150, bbox_inches='tight')
    plt.show()

    print("检测结果已保存为: yolov8_onnx_detection_result.jpg")


def test_with_random_input(session, input_info):
    """
    使用随机输入测试模型
    """
    print("\n=== 使用随机输入测试 ===")

    # 创建随机输入 (1, 3, 640, 640)
    random_input = np.random.random((1, 3, 640, 640)).astype(np.float32)
    print(f"随机输入形状: {random_input.shape}")
    print(f"随机输入范围: [{random_input.min():.4f}, {random_input.max():.4f}]")

    # 推理
    input_name = input_info[0].name
    outputs = session.run(None, {input_name: random_input})

    # 分析输出
    output_tensor, num_features, num_anchors = analyze_yolov8_output_structure(outputs)
    detections = parse_yolov8_detections(output_tensor, num_features)

    return outputs, detections


def main():
    """主函数"""
    onnx_model_path = r"C:\Users\30855\Desktop\trainer\garlic_identify3.onnx"  # 修改为您的模型路径
    test_image_path = r"C:\Users\30855\Desktop\frame1_00113.jpg"  # 修改为测试图像路径

    # 类别名称（根据您的模型调整）
    class_names = {0: 'garlic', 1: 'head'}

    print("=== YOLOv8 ONNX模型详细检查 ===")

    if not os.path.exists(onnx_model_path):
        print(f"ONNX模型文件不存在: {onnx_model_path}")
        print("请修改 onnx_model_path 变量为正确的模型路径")
        return

    # 加载模型
    session, input_info, output_info = load_yolov8_onnx_model(onnx_model_path)
    if session is None:
        return

    print(f"\n类别信息: {class_names}")

    # 测试1: 使用随机输入
    print("\n" + "=" * 50)
    outputs, detections = test_with_random_input(session, input_info)

    # 测试2: 使用实际图像
    print("\n" + "=" * 50)
    if os.path.exists(test_image_path):
        final_detections, outputs = test_onnx_with_image(
            session, input_info, test_image_path, class_names
        )
    else:
        print(f"测试图像不存在: {test_image_path}")
        print("请准备测试图像或修改 test_image_path 变量")

    # 性能测试
    print("\n" + "=" * 50)
    print("=== 性能测试 ===")

    # 预热
    warmup_input = np.random.random((1, 3, 640, 640)).astype(np.float32)
    input_name = input_info[0].name
    for _ in range(5):
        session.run(None, {input_name: warmup_input})

    # 正式测试
    import time
    start_time = time.time()
    for _ in range(10):
        session.run(None, {input_name: warmup_input})
    end_time = time.time()

    avg_inference_time = (end_time - start_time) / 10 * 1000  # 毫秒
    print(f"平均推理时间: {avg_inference_time:.2f} ms")
    print(f"推理速度: {1000 / avg_inference_time:.2f} FPS")

    print("\n=== YOLOv8 ONNX模型检查完成 ===")


if __name__ == "__main__":
    main()