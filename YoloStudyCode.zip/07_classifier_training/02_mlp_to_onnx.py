import torch
import torch.nn as nn
import torchvision.transforms as transforms
from PIL import Image
import numpy as np

# 定义设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# 定义与训练时相同的数据预处理
transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=1),
    transforms.Resize((20, 28)),
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])


# 定义MLP模型（与训练时相同的结构）
class MLP(nn.Module):
    def __init__(self, input_size=20 * 28, hidden_size=512, num_classes=9):
        super(MLP, self).__init__()
        self.flatten = nn.Flatten()
        self.classifier = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_size // 2, num_classes)
        )

    def forward(self, x):
        x = self.flatten(x)
        x = self.classifier(x)
        return x


# 加载训练好的模型
model = MLP(num_classes=9)
model.load_state_dict(torch.load(r"E:\RM_DATAS\my_File\my_test\mlp.pth", map_location=device))
model.to(device)  # 将模型移动到设备上
model.eval()  # 设置为评估模式

# 创建一个示例输入（用于确定输入形状）- 确保与模型在同一设备上
dummy_input = torch.randn(1, 1, 20, 28).to(device)  # 添加.to(device)

# 导出模型为ONNX格式
input_names = ["input"]
output_names = ["output"]
dynamic_axes = {'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}}

torch.onnx.export(
    model,
    dummy_input,
    "mlp.onnx",
    verbose=True,
    input_names=input_names,
    output_names=output_names,
    dynamic_axes=dynamic_axes,
    opset_version=11  # 使用ONNX操作集版本11
)

print("Model converted to ONNX format successfully!")
print("ONNX model saved as: mlp.onnx")

# 可选：验证ONNX模型
try:
    import onnx

    onnx_model = onnx.load("mlp.onnx")
    onnx.checker.check_model(onnx_model)
    print("ONNX model is valid!")
except ImportError:
    print("ONNX package is not installed. Skipping validation.")


# 可选：创建一个简单的测试函数来验证转换后的模型
def test_onnx_model():
    # 创建一个随机测试图像
    test_image = torch.randn(1, 1, 20, 28).to(device)  # 确保测试图像也在正确设备上

    # 使用原始PyTorch模型进行预测
    with torch.no_grad():
        pytorch_output = model(test_image).cpu().numpy()  # 将结果移回CPU以进行numpy操作

    # 使用ONNX运行时进行预测（需要安装onnxruntime）
    try:
        import onnxruntime as ort

        # 为ONNX运行时提供适当的provider
        providers = ['CUDAExecutionProvider', 'CPUExecutionProvider'] if device.type == 'cuda' else [
            'CPUExecutionProvider']
        ort_session = ort.InferenceSession("mlp.onnx", providers=providers)

        # 准备输入 - 注意ONNX运行时需要CPU上的numpy数组
        ort_inputs = {ort_session.get_inputs()[0].name: test_image.cpu().numpy()}

        # 运行推理
        ort_output = ort_session.run(None, ort_inputs)[0]

        # 比较结果
        print("PyTorch和ONNX输出差异:", np.max(np.abs(pytorch_output - ort_output)))
        print("转换验证完成!")
    except ImportError:
        print("ONNX运行时未安装，跳过验证")


# 运行测试
test_onnx_model()