import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import os
from torch.utils.data import DataLoader

# 定义设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# 定义数据预处理
transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=1),  # 确保是灰度图，1通道
    transforms.Resize((20, 28)),  # 调整大小到20x28
    transforms.ToTensor(),  # 转换为Tensor，并归一化到[0,1]
    transforms.Normalize((0.5,), (0.5,))  # 将值标准化到[-1,1]
])

# 定义MLP模型
class MLP(nn.Module):
    def __init__(self, input_size=20*28, hidden_size=512, num_classes=9):  # 修改输入尺寸为20*28
        super(MLP, self).__init__()
        self.flatten = nn.Flatten()
        self.classifier = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.5),  # 添加Dropout防止过拟合
            nn.Linear(hidden_size, hidden_size//2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_size//2, num_classes)
        )

    def forward(self, x):
        x = self.flatten(x)
        x = self.classifier(x)
        return x

if __name__ == '__main__':
    # 加载数据集
    train_dataset = torchvision.datasets.ImageFolder(
        root=r"E:\RM_DATAS\RM_datas\num_datasets",
        transform=transform
    )

    # 增加batch_size以更好地利用GPU显存
    batch_size = 128
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=4,
        pin_memory=True
    )

    model = MLP(num_classes=9).to(device)

    # 使用混合精度训练
    scaler = torch.cuda.amp.GradScaler()

    # 定义损失函数和优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    # 添加学习率调度器
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.7)

    # 训练模型
    num_epochs = 15
    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for i, data in enumerate(train_loader, 0):
            inputs, labels = data
            inputs, labels = inputs.to(device, non_blocking=True), labels.to(device, non_blocking=True)

            optimizer.zero_grad()

            # 使用混合精度训练
            with torch.cuda.amp.autocast():
                outputs = model(inputs)
                loss = criterion(outputs, labels)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()

            if i % 10 == 9:
                print('[%d, %5d] loss: %.3f' %
                      (epoch + 1, i + 1, running_loss / 10))
                running_loss = 0.0

        # 更新学习率
        scheduler.step()

        # 每个epoch结束后保存检查点
        torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'loss': loss,
        }, f'checkpoint_epoch_{epoch}.pth')

    print('Finished Training')

    # 保存最终模型
    torch.save(model.state_dict(), 'mlp.pth')
    print("Current working directory:", os.getcwd())
    print("Model is saved at:", os.path.abspath('mlp.pth'))