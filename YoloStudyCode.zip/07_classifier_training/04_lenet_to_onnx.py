import torch
import torch.nn as nn
import onnx
import onnxruntime as ort
import numpy as np
import os


# 定义LeNet模型结构（必须与训练时完全一致）
class LeNet(nn.Module):
    def __init__(self, num_classes=9):  # 输出9类
        super(LeNet, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 6, kernel_size=5),  # 输入1通道，输出6通道
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(6, 16, kernel_size=5),  # 输入6通道，输出16通道
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.classifier = nn.Sequential(
            nn.Linear(16 * 4 * 4, 120),  # 注意特征图大小计算
            nn.ReLU(),
            nn.Linear(120, 84),
            nn.ReLU(),
            nn.Linear(84, num_classes)
        )

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


# 转换函数
def convert_to_onnx(pth_path, onnx_path):
    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # 实例化模型并加载训练好的权重
    model = LeNet(num_classes=9).to(device)

    # 检查文件是否存在
    if not os.path.exists(pth_path):
        raise FileNotFoundError(f"模型文件不存在: {pth_path}")

    # 加载模型权重
    try:
        # 尝试加载完整检查点
        checkpoint = torch.load(pth_path, map_location=device)
        if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
            print("从检查点加载模型权重")
        else:
            # 直接加载状态字典
            model.load_state_dict(checkpoint)
            print("直接加载模型权重")
    except Exception as e:
        raise RuntimeError(f"加载模型权重失败: {str(e)}")

    model.eval()  # 设置模型为评估模式

    # 创建虚拟输入（示例张量）
    # 根据预处理，输入是1x28x28的灰度图，值范围[-1,1]
    dummy_input = torch.randn(1, 1, 28, 28).to(device)  # 输入维度为 [batch, channel, height, width]

    # 导出模型为ONNX格式
    torch.onnx.export(
        model,  # 要转换的模型
        dummy_input,  # 模型输入（示例张量）
        onnx_path,  # 输出ONNX文件路径
        export_params=True,  # 将训练好的参数与模型一同导出
        opset_version=12,  # ONNX运算集版本
        do_constant_folding=True,  # 执行常量折叠优化
        input_names=['input'],  # 输入张量的名称
        output_names=['output'],  # 输出张量的名称
        dynamic_axes={  # 指定动态维度（如允许批次大小变化）
            'input': {0: 'batch_size'},
            'output': {0: 'batch_size'}
        }
    )

    print(f"模型已成功转换为ONNX格式并保存至: {os.path.abspath(onnx_path)}")

    # 验证ONNX模型
    onnx_model = onnx.load(onnx_path)
    try:
        onnx.checker.check_model(onnx_model)  # 检查模型有效性
        print("ONNX模型验证成功！")
    except onnx.checker.ValidationError as e:
        print(f"ONNX模型验证失败: {str(e)}")
        return

    # 验证PyTorch和ONNX模型的输出是否一致
    with torch.no_grad():
        torch_output = model(dummy_input).cpu().numpy()

    # 使用ONNX Runtime进行推理
    ort_session = ort.InferenceSession(onnx_path)
    ort_inputs = {ort_session.get_inputs()[0].name: dummy_input.cpu().numpy()}
    ort_outputs = ort_session.run(None, ort_inputs)

    # 比较输出结果
    if np.allclose(torch_output, ort_outputs[0], rtol=1e-03, atol=1e-05):
        print("PyTorch和ONNX模型输出一致！")
    else:
        print("警告：PyTorch和ONNX模型输出存在差异！")
        print(f"PyTorch输出: {torch_output}")
        print(f"ONNX输出: {ort_outputs[0]}")
        print(f"最大差异: {np.max(np.abs(torch_output - ort_outputs[0]))}")


# 使用示例
if __name__ == "__main__":
    # 支持两种类型的模型文件：
    # 1. 完整检查点（包含model_state_dict, optimizer_state_dict等）
    # 2. 仅模型权重
    pth_path = r"E:\RM_DATAS\my_File\my_test\checkpoint_epoch_13.pth"
    onnx_path = 'lenet_model_MeBest.onnx'

    # 也可以尝试加载最终模型
    # pth_path = 'lenet.pth'

    convert_to_onnx(pth_path, onnx_path)