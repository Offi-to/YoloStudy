# import os
# import glob
# import codecs
# import re
# root_path = 'F:/RM__/_buff_image/buff_pose_data/label_pose_kit/train'
# save_path = 'F:/RM__/_buff_image/buff_pose_data/label/val'
#
# if not os.path.exists(save_path):
#     os.makedirs(save_path)
# txt=os.listdir(root_path)
# for i in txt:
#     # f = open(i)
#     f = codecs.open(os.path.join(root_path,i), mode='r', encoding='utf-8')
#     res = ''
#     data = f.read()
#     data = data.replace('  ',' ')
#     for j in data.split('\n'):
#
#         k = j.split(' ')
#
#         # if(k[:1]== ['1']):                 # 筛选出类为1的数据  行数
#         res += ' '.join(k[:5]) + '\n'  # 拿出一定列数的数据  [:5]：前5行
#     # res += ' '.join(k[:5]) + '\n'
#
#
#     resf = open(os.path.join(save_path,i[:-4]+'.txt'), mode='wt')
#     resf.write(res)
#     f.close()
#     resf.close()

'''
- 目标：处理YOLO格式的标签文件，提取特定关键点坐标
- 主要流程
  ├─ 路径设置
  │   ├─ 输入路径：label_pose_kit/val
  │   └─ 输出路径：label/val
  │
  ├─ 文件处理
  │   ├─ 遍历所有输入文件
  │   ├─ 读取文件内容（使用codecs处理编码）
  │   ├─ 数据清洗（替换双空格为单空格）
  │   └─ 按行分割处理
  │
  ├─ 关键点提取
  │   ├─ 保留前5列（类别+基础坐标）
  │   ├─ 提取第5-6列（关键点1）
  │   ├─ 提取第8-9列（关键点2）
  │   ├─ 提取第11-12列（关键点3）
  │   └─ 提取第14-15列（关键点4）
  │
  └─ 结果输出
      ├─ 创建同名txt文件
      ├─ 写入处理后的内容
      └─ 确保文件关闭
'''

import os
import glob
import codecs
import re


root_path = 'F:/RM__/_buff_image/buff_pose_data/label_pose_kit/val'
save_path = 'F:/RM__/_buff_image/buff_pose_data/label/val'

if not os.path.exists(save_path):
    os.makedirs(save_path)
txt = os.listdir(root_path)
for i in txt:
    # f = open(i)
    f = codecs.open(os.path.join(root_path, i), mode='r', encoding='utf-8')
    res = ''
    data = f.read()
    data = data.replace('  ', ' ')
    for j in data.split('\n'):
        k = j.split(' ')

        # if(k[:1]== ['1']):                 # 筛选出类为1的数据  行数
        res += ' '.join(k[:5]) + ' ' + ' '.join(k[5:7]) + ' ' + ' '.join(k[8:10]) + ' ' + ' '.join(
            k[11:13]) + ' ' + ' '.join(k[14:16])

    # res += ' '.join(k[:5]) + '\n'

    resf = open(os.path.join(save_path, i[:-4] + '.txt'), mode='wt')
    resf.write(res)
    f.close()
    resf.close()
