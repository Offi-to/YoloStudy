import onnxruntime as ort

# 加载第一个模型
sess1 = ort.InferenceSession(r"H:\pose\pose\energy_pose_train\weights\Fu_Me3.onnx")
inputs1 = {input.name: {'shape': input.shape, 'type': input.type} for input in sess1.get_inputs()}
outputs1 = {output.name: {'shape': output.shape, 'type': output.type} for output in sess1.get_outputs()}

# 加载第二个模型
sess2 = ort.InferenceSession(r"H:\pose\pose\energy_pose_train\weights\buff_3.onnx")
inputs2 = {input.name: {'shape': input.shape, 'type': input.type} for input in sess2.get_inputs()}
outputs2 = {output.name: {'shape': output.shape, 'type': output.type} for output in sess2.get_outputs()}

# 比较输入输出是否一致
print("Inputs match:", inputs1 == inputs2)
print("Outputs match:", outputs1 == outputs2)