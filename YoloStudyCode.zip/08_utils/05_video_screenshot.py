import cv2
import os


def extract_frames_basic(video_path, output_folder="output_frames"):
    """
    基础版本：提取视频每一帧为PNG图片

    参数:
        video_path: 视频文件路径
        output_folder: 输出图片的文件夹
    """
    # 创建输出文件夹
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 读取视频文件
    cap = cv2.VideoCapture(video_path)

    # 检查视频是否成功打开
    if not cap.isOpened():
        print(f"错误：无法打开视频文件 {video_path}")
        return False

    # 获取视频信息
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = total_frames / fps

    print(f"视频信息：")
    print(f"  - 帧率: {fps:.2f} FPS")
    print(f"  - 总帧数: {total_frames}")
    print(f"  - 时长: {duration:.2f} 秒")

    frame_count = 0
    success = True

    # 逐帧读取视频
    while success:
        # 读取一帧
        success, frame = cap.read()

        if success:
            # 构建输出文件名
            frame_filename = f"frame_{frame_count:06d}.png"
            output_path = os.path.join(output_folder, frame_filename)

            # 保存帧为PNG图片
            cv2.imwrite(output_path, frame)
            frame_count += 1

            # 显示进度
            if frame_count % 30 == 0:  # 每30帧显示一次进度
                progress = (frame_count / total_frames) * 100
                print(f"处理进度: {progress:.1f}% ({frame_count}/{total_frames})")

    # 释放资源
    cap.release()
    print(f"完成！共提取 {frame_count} 帧图片到文件夹 '{output_folder}'")
    return True


# 使用示例
if __name__ == "__main__":
    video_file = r"C:\Users\30855\Desktop\修图\1\P1600552.MP4"  # 替换为你的视频路径
    extract_frames_basic(video_file)