from openvino.runtime import Core
from openvino.runtime import serialize

ie = Core()
# onnx_model_path = r"F:\complete_model\buff_75_4_3\buff_3.onnx"
onnx_model_path = r"E:\best.onnx"
model_onnx = ie.read_model(model=onnx_model_path)
# compiled_model_onnx = ie.compile_model(model=model_onnx, device_name="CPU")
serialize(model=model_onnx, xml_path="model/exported_onnx_model.xml", bin_path="model/exported_onnx_model.bin",
          version="UNSPECIFIED")

# coding:UTF-8
# import os
# from openvino.tools.ovc import convert_model
#
# # 定义 ONNX 模型路径
# onnx_model_path = "E:\\Desktop\\targetClassify\\ir_classifier.onnx"
#
# # 定义输出目录路径
# output_dir = "E:\\Desktop\\targetClassify\\weight"
#
# # 检查输出目录是否存在，如果不存在则创建
# if not os.path.exists(output_dir):
#     os.makedirs(output_dir)
#     print(f"Created output directory at: {output_dir}")
# else:
#     print(f"Output directory already exists at: {output_dir}")
#
# # 设置模型转换参数
# try:
#     convert_model(
#         model_path=onnx_model_path,  # 指定 ONNX 模型路径
#         output_dir=output_dir  # 指定输出目录，模型文件将保存到这个目录中
#     )
#     print(f"Model successfully converted and saved to: {output_dir}")
# except Exception as e:
#     print(f"Error during model conversion: {e}")