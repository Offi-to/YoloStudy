import random

'''用于点名，随机抽取小可爱来标数据集，姓名.txt的内容格式为每行一个姓名'''

# 读取姓名数据
name_file = r'C:\Users\30855\Desktop\ss.txt'
with open(name_file, 'r', encoding='utf-8') as f:

    names = [line.strip() for line in f.readlines()]
# 点名
while True:
    input_str = input('输入回车开始点名，输入 q 退出程序：')
    if input_str.lower() == 'q':
        break
    selected_name = random.choice(names)
    print(f'选中的名字是：{selected_name}')
    names.remove(selected_name)

'''
说明：
1. 首先使用`with open()`打开`names.txt`文件，读取其中的姓名数据，存储为一个列表`names`；
2. 在`while`循环中，等待用户输入；
3. 如果用户输入了`q`，则退出程序；
4. 如果用户输入回车，则从`names`列表中随机选择一个姓名，使用`random.choice()`函数实现；
5. 将选中的姓名打印出来，并在`names`列表中移除该姓名，以保证不会重复点名。
'''