import cv2

# 读取图片
image = cv2.imread("5.jpg", cv2.IMREAD_GRAYSCALE)
new_width = 30
scale = new_width / image.shape[1]  # 计算缩放比例
new_height = int(image.shape[0] * scale)
# 转换为灰度图
gray_image = cv2.resize(image, (new_width, new_height),interpolation=cv2.INTER_AREA)

# 保存灰度图
cv2.imwrite("52.jpg", gray_image)

print("灰度图已保存为 gray_image.jpg")