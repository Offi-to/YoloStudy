import os
import argparse
from pathlib import Path


def batch_rename_images(folder_path, prefix="image", start_number=1, sort_by=None):
    """
    批量重命名文件夹中的图片文件，可指定起始编号

    参数:
    folder_path (str): 图片文件夹的路径
    prefix (str): 新文件名的前缀，默认为"image"
    start_number (int): 起始编号，默认为1
    sort_by (str): 排序方式，可选"name"（按文件名）、"modified"（按修改时间）
    """
    try:
        folder = Path(folder_path)
        if not folder.exists():
            print(f"错误：找不到文件夹 '{folder_path}'")
            return False
    except Exception as e:
        print(f"路径错误: {e}")
        return False

    # 支持的图片格式
    image_extensions = ('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.tif', '.webp')

    # 获取所有图片文件
    image_files = []
    for ext in image_extensions:
        image_files.extend(folder.glob(f"*{ext}"))
        image_files.extend(folder.glob(f"*{ext.upper()}"))

    if not image_files:
        print("在指定文件夹中未找到任何图片文件")
        return False

    # 排序处理
    if sort_by == "modified":
        image_files.sort(key=lambda x: x.stat().st_mtime)
    else:  # 默认按文件名排序
        image_files.sort()

    print(f"找到 {len(image_files)} 个图片文件")
    print("文件列表（按此顺序重命名）:")
    for i, file_path in enumerate(image_files, 1):
        print(f"{i}. {file_path.name}")

    # 确认操作
    response = input(f"\n将从 {start_number} 开始重命名，是否继续? (y/n): ")
    if response.lower() != 'y':
        print("操作已取消")
        return False

    # 重命名文件
    success_count = 0
    for index, file_path in enumerate(image_files):
        # 获取文件扩展名
        file_extension = file_path.suffix

        # 构建新文件名（从start_number开始）
        new_filename = f"{prefix}_{start_number + index:04d}{file_extension}"
        new_path = folder / new_filename

        try:
            # 如果目标文件已存在，先处理冲突
            if new_path.exists():
                # 为新文件生成唯一名称
                counter = 1
                while new_path.exists():
                    new_filename = f"{prefix}_{start_number + index:04d}_{counter}{file_extension}"
                    new_path = folder / new_filename
                    counter += 1

            file_path.rename(new_path)
            print(f"✓ 重命名: {file_path.name} -> {new_filename}")
            success_count += 1
        except Exception as e:
            print(f"✗ 重命名失败 {file_path.name}: {e}")

    print(f"\n重命名完成! 成功处理 {success_count}/{len(image_files)} 个文件")
    return True


def main():
    """主函数：提供两种使用方式"""
    print("=== 图片批量重命名工具 ===\n")

    # 方式1：命令行参数
    if len(os.sys.argv) > 1:
        parser = argparse.ArgumentParser(description='批量重命名图片工具')
        parser.add_argument('folder', help='图片文件夹路径')
        parser.add_argument('--prefix', default='image', help='文件名前缀（默认: image）')
        parser.add_argument('--start', type=int, default=1, help='起始编号（默认: 1）')
        parser.add_argument('--sort', choices=['name', 'modified'], default='name',
                            help='排序方式: name(按文件名), modified(按修改时间)')

        args = parser.parse_args()
        batch_rename_images(args.folder, args.prefix, args.start, args.sort)

    # 方式2：交互式输入
    else:
        folder_path = input("请输入图片文件夹路径: ").strip().strip('"')

        # 处理空路径
        if not folder_path:
            folder_path = os.getcwd()

        prefix = input("请输入新文件名前缀 (默认为 'image'): ").strip()
        if not prefix:
            prefix = "image"

        start_input = input("请输入起始编号 (默认为 1): ").strip()
        try:
            start_number = int(start_input) if start_input else 1
        except ValueError:
            print("输入无效，使用默认起始编号 1")
            start_number = 1

        sort_option = input("排序方式 - 按文件名(n) 还是按修改时间(m)? (n/m, 默认为 n): ").strip().lower()
        sort_by = "modified" if sort_option == "m" else "name"

        batch_rename_images(folder_path, prefix, start_number, sort_by)


if __name__ == "__main__":
    main()