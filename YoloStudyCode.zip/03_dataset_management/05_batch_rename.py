import os


def editor_name_jpg_num(source_folder, source_info, your_new_info):
    path = source_folder  # 文件所在路径
    files = os.listdir(path)  # 获取所有文件名

    i = 1
    j = 0
    target_info = source_info
    name_len = len(target_info)  # 要更改的字符长度
    new_info = your_new_info
    for file in files:
        if file.endswith(".jpg"):  # 只处理图片文件
            old_name = file
            new1_info = str(0)+str(0)+str(0)+str(0)+str(0)+str(0)+str(0)+str(0)+str(0)

            new_name = new1_info + ".jpg"
            if i < 10 and j == 0:
                new1_info += str(0)+str(0)+str(i)
                new_name = new1_info + ".jpg"
                j = 1
            if i < 100 and j == 0:
                new1_info += str(0) + str(i)
                new_name = new1_info + ".jpg"
                j = 1
            if i < 1000 and j == 0:
                new1_info = new1_info + str(i)
                new_name = new1_info + ".jpg"
                j = 1

            os.rename(os.path.join(path, old_name), os.path.join(path, new_name))  # 对文件进行重命名
            j = 0
            i += 1




def editor_name_jpg(source_folder, source_info, your_new_info):
    path = source_folder  # 文件所在路径
    files = os.listdir(path)  # 获取所有文件名
    i = 420
    target_info = source_info
    name_len = len(target_info)  # 要更改的字符长度
    new_info = your_new_info
    for file in files:
        if file.endswith(".jpg"):  # 只处理图片文件
            old_name = file
            new_name = new_info + str(i) + ".jpg"
            if len(old_name) >= name_len:
                new_name = new_info + old_name[name_len:]  # 截取要更改的字符长度后面的子串拼接新名称
            os.rename(os.path.join(path, old_name), os.path.join(path, new_name))  # 对文件进行重命名
            i += 1


def editor_name_txt(source_folder, source_info, your_new_info):
    path = source_folder  # 文件所在路径
    files = os.listdir(path)  # 获取所有文件名
    i = 1

    target_info = source_info
    name_len = len(target_info)  # 要更改的字符长度
    new_info = your_new_info
    for file in files:
        if file.endswith(".txt"):  # 只处理txt文件
            old_name = file
            new_name = new_info + str(i) + ".txt"
            if len(old_name) >= name_len:
                new_name = new_info + old_name[name_len:]  # 截取要更改的字符长度后面的子串拼接新名称
            os.rename(os.path.join(path, old_name), os.path.join(path, new_name))  # 对文件进行重命名
            i += 1
def editor_name_txt_num(source_folder, source_info, your_new_info):
    path = source_folder  # 文件所在路径
    files = os.listdir(path)  # 获取所有文件名
    i = 420
    j=0
    target_info = source_info
    name_len = len(target_info)  # 要更改的字符长度
    new_info = your_new_info
    for file in files:
        if file.endswith(".txt"):  # 只处理txt文件
            old_name = file
            new1_info = str(0) + str(0) + str(0) + str(0) + str(0) + str(0) + str(0) + str(0) + str(0)

            new_name = new1_info + ".txt"
            if i < 10 and j == 0:
                new1_info += str(0) + str(0) + str(i)
                new_name = new1_info + ".txt"
                j = 1
            if i < 100 and j == 0:
                new1_info += str(0) + str(i)
                new_name = new1_info + ".txt"
                j = 1
            if i < 1000 and j == 0:
                new1_info = new1_info + str(i)
                new_name = new1_info + ".txt"
                j = 1

            os.rename(os.path.join(path, old_name), os.path.join(path, new_name))  # 对文件进行重命名
            i += 1
            j=0

def editor_name_json(source_folder, source_info, your_new_info):
    path = source_folder  # 文件所在路径
    files = os.listdir(path)  # 获取所有文件名
    i = 1
    target_info = source_info
    name_len = len(target_info)  # 要更改的字符长度
    new_info = your_new_info
    for file in files:
        if file.endswith(".json"):  # 只处理txt文件
            old_name = file
            new_name = new_info + str(i) + ".json"
            if len(old_name) >= name_len:
                new_name = new_info + old_name[name_len:]  # 截取要更改的字符长度后面的子串拼接新名称
            os.rename(os.path.join(path, old_name), os.path.join(path, new_name))  # 对文件进行重命名
            i += 1


img_path = r"F:\RM__\_buff_image\buff_pose_data\t_b"
txt_path = r"F:\RM__\_buff_image\buff_pose_data\anno.txt"
target_info = "base_r"
new_info = "000000000000"
#editor_name_jpg_num(img_path, target_info, new_info)
editor_name_txt_num(txt_path, target_info, new_info)
#editor_name_json(txt_path, target_info, new_info)
