import os
import argparse
from pathlib import Path
import signal
import sys


class DelayedKeyboardInterrupt:
    """延迟键盘中断的上下文管理器[7,8](@ref)"""

    def __enter__(self):
        self.signal_received = False
        self.old_handler = signal.signal(signal.SIGINT, self.handler)

    def handler(self, sig, frame):
        self.signal_received = (sig, frame)
        print("\n收到中断信号，将在当前操作完成后退出...")

    def __exit__(self, type, value, traceback):
        signal.signal(signal.SIGINT, self.old_handler)
        if self.signal_received:
            self.old_handler(*self.signal_received)


def batch_rename_images(folder_path, prefix="image", start_number=1, sort_by=None):
    """
    批量重命名文件夹中的图片文件，可指定起始编号
    """
    try:
        folder = Path(folder_path)
        if not folder.exists():
            print(f"错误：找不到文件夹 '{folder_path}'")
            return False
    except Exception as e:
        print(f"路径错误: {e}")
        return False

    # 支持的图片格式
    image_extensions = ('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.tif', '.webp')

    # 获取所有图片文件
    image_files = []
    for ext in image_extensions:
        image_files.extend(folder.glob(f"*{ext}"))
        image_files.extend(folder.glob(f"*{ext.upper()}"))

    if not image_files:
        print("在指定文件夹中未找到任何图片文件")
        return False

    # 排序处理
    if sort_by == "modified":
        image_files.sort(key=lambda x: x.stat().st_mtime)
    else:  # 默认按文件名排序
        image_files.sort()

    print(f"找到 {len(image_files)} 个图片文件")
    print("文件列表（按此顺序重命名）:")
    for i, file_path in enumerate(image_files, 1):
        print(f"{i}. {file_path.name}")

    # 用户确认环节，添加键盘中断保护[5](@ref)
    try:
        response = input(f"\n将从 {start_number} 开始重命名，是否继续? (y/n): ").strip().lower()
    except KeyboardInterrupt:
        print("\n\n操作已被用户取消。")
        return False

    if response != 'y':
        print("操作已取消")
        return False

    # 重命名操作使用延迟中断保护[7,8](@ref)
    try:
        success_count = 0
        print("\n开始重命名... (按 Ctrl+C 可安全中断)")

        for index, file_path in enumerate(image_files):
            try:
                # 使用延迟中断保护关键的重命名操作
                with DelayedKeyboardInterrupt():
                    # 获取文件扩展名
                    file_extension = file_path.suffix

                    # 构建新文件名
                    new_filename = f"{prefix}_{start_number + index:04d}{file_extension}"
                    new_path = folder / new_filename

                    # 处理文件名冲突
                    if new_path.exists():
                        counter = 1
                        while new_path.exists():
                            new_filename = f"{prefix}_{start_number + index:04d}_{counter}{file_extension}"
                            new_path = folder / new_filename
                            counter += 1

                    file_path.rename(new_path)
                    print(f"✓ 已重命名: {file_path.name} -> {new_filename}")
                    success_count += 1

            except KeyboardInterrupt:
                print(f"\n重命名过程在 '{file_path.name}' 处被用户中断")
                print(f"已完成 {success_count} 个文件的重命名")
                # 询问用户是否继续剩余文件
                try:
                    continue_response = input("是否继续重命名剩余文件? (y/n): ").strip().lower()
                    if continue_response != 'y':
                        print(f"已安全退出。成功重命名 {success_count}/{len(image_files)} 个文件")
                        return True
                    else:
                        print("继续重命名剩余文件...")
                        continue
                except KeyboardInterrupt:
                    print(f"最终完成 {success_count} 个文件的重命名")
                    return True

    except Exception as e:
        print(f"重命名过程中发生错误: {e}")
        return False

    print(f"\n重命名完成! 成功处理 {success_count}/{len(image_files)} 个文件")
    return True


def signal_handler(signum, frame):
    """全局信号处理函数[3](@ref)"""
    print(f"\n收到中断信号 (Ctrl+C)，程序将安全退出...")
    sys.exit(0)


def main():
    """主函数"""
    # 注册全局信号处理[6](@ref)
    signal.signal(signal.SIGINT, signal_handler)

    print("=== 图片批量重命名工具 ===\n")
    print("提示: 在任何输入阶段按 Ctrl+C 可以安全取消操作")

    try:
        # 方式1：命令行参数
        if len(sys.argv) > 1:
            parser = argparse.ArgumentParser(description='批量重命名图片工具')
            parser.add_argument('folder', help='图片文件夹路径')
            parser.add_argument('--prefix', default='image', help='文件名前缀（默认: image）')
            parser.add_argument('--start', type=int, default=1, help='起始编号（默认: 1）')
            parser.add_argument('--sort', choices=['name', 'modified'], default='name',
                                help='排序方式: name(按文件名), modified(按修改时间)')

            args = parser.parse_args()
            batch_rename_images(args.folder, args.prefix, args.start, args.sort)

        # 方式2：交互式输入
        else:
            folder_path = input("请输入图片文件夹路径: ").strip().strip('"')

            if not folder_path:
                folder_path = os.getcwd()

            prefix = input("请输入新文件名前缀 (默认为 'image'): ").strip()
            if not prefix:
                prefix = "image"

            start_input = input("请输入起始编号 (默认为 1): ").strip()
            try:
                start_number = int(start_input) if start_input else 1
            except ValueError:
                print("输入无效，使用默认起始编号 1")
                start_number = 1

            sort_option = input("排序方式 - 按文件名(n) 还是按修改时间(m)? (n/m, 默认为 n): ").strip().lower()
            sort_by = "modified" if sort_option == "m" else "name"

            batch_rename_images(folder_path, prefix, start_number, sort_by)

    except KeyboardInterrupt:
        print("\n\n程序已被用户终止。")
    except Exception as e:
        print(f"程序执行过程中发生错误: {e}")


if __name__ == "__main__":
    main()