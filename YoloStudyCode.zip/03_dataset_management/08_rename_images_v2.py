import os
import sys


def batch_rename_images(folder_path, start_index=0, filename_prefix="frame_"):
    """
    批量重命名文件夹中的图片文件

    Args:
        folder_path (str): 图片文件夹路径
        start_index (int): 图片名称的起始编号，默认为0
        filename_prefix (str): 图片名称前缀，默认为"frame_"
    """
    # 检查文件夹路径是否存在
    if not os.path.exists(folder_path):
        print(f"错误: 文件夹不存在 - {folder_path}")
        return False

    # 支持的图片格式
    supported_formats = [".jpg", ".jpeg", ".png", ".bmp",
                         ".tiff", ".gif", ".webp", ".ppm"]

    # 获取文件夹中所有文件
    try:
        all_files = os.listdir(folder_path)
    except PermissionError:
        print(f"错误: 没有权限访问文件夹 - {folder_path}")
        return False

    # 过滤出图片文件
    image_files = [f for f in all_files
                   if os.path.isfile(os.path.join(folder_path, f)) and
                   os.path.splitext(f)[1].lower() in supported_formats]

    if not image_files:
        print("在指定文件夹中没有找到支持的图片文件")
        print(f"支持的格式: {', '.join(supported_formats)}")
        return False

    # 按文件名排序，确保顺序一致
    image_files.sort()

    print(f"找到 {len(image_files)} 个图片文件")
    print("开始重命名...")

    renamed_count = 0

    for index, filename in enumerate(image_files):
        # 获取文件扩展名
        file_extension = os.path.splitext(filename)[1]

        # 生成新文件名
        new_filename = f"{filename_prefix}{start_index + index:05d}{file_extension}"

        # 完整的旧文件路径和新文件路径
        old_file_path = os.path.join(folder_path, filename)
        new_file_path = os.path.join(folder_path, new_filename)

        # 检查新文件名是否已存在（避免覆盖）
        if os.path.exists(new_file_path) and old_file_path != new_file_path:
            print(f"警告: 文件名 {new_filename} 已存在，跳过重命名 {filename}")
            continue

        try:
            # 重命名文件
            os.rename(old_file_path, new_file_path)
            renamed_count += 1
            print(f"已重命名: {filename} -> {new_filename}")
        except Exception as e:
            print(f"重命名失败 {filename}: {str(e)}")

    print(f"重命名完成! 成功重命名 {renamed_count} 个文件")
    return True


if __name__ == "__main__":
    # 设置默认参数
    folder_path = r"C:\Users\30855\Desktop\buff2026.3.2\red2026.2.24\images"  # 图片文件夹路径

    # 通过命令行参数覆盖默认值
    if len(sys.argv) >= 2:
        folder_path = sys.argv[1]
        start_index = int(sys.argv[2]) if len(sys.argv) > 2 else 697
        filename_prefix = sys.argv[3] if len(sys.argv) > 3 else "frame_"
    else:
        start_index = 2221  # 默认起始索引
        filename_prefix = "base_r"  # 默认文件名前缀

    # 执行批量重命名
    success = batch_rename_images(folder_path, start_index, filename_prefix)

    if not success:
        sys.exit(1)

    print("图片批量重命名任务完成!")