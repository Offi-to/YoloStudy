"""
将JSON格式的标注文件转换为YOLOv8-pose训练所需的TXT格式
JSON文件格式基于LabelMe
"""

import json
import os
import argparse
from pathlib import Path

def json_to_yolov8_pose(json_file, output_dir, image_width=None, image_height=None, class_mapping=None):
    """
    将单个JSON文件转换为YOLOv8-pose格式的TXT文件

    Args:
        json_file: 输入的JSON文件路径
        output_dir: 输出目录
        image_width: 图片宽度（可选，如果在JSON中没有指定）
        image_height: 图片高度（可选，如果在JSON中没有指定）
        class_mapping: 类别映射字典 (label -> class_id)
    """
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error reading {json_file}: {e}")
        return False

    # 获取图片尺寸
    if image_width is None or image_height is None:
        # 尝试从JSON中获取图片尺寸
        if 'imageWidth' in data and 'imageHeight' in data:
            image_width = data['imageWidth']
            image_height = data['imageHeight']
        else:
            print(f"警告: {json_file} 中没有图片尺寸信息，且未提供默认尺寸")
            return False

    # 准备输出文件路径
    base_name = Path(json_file).stem
    output_file = os.path.join(output_dir, f"{base_name}.txt")

    # 解析标注形状
    shapes = data.get('shapes', [])
    yolo_annotations = []

    for shape in shapes:
        label = shape['label']
        points = shape['points']
        shape_type = shape['shape_type']

        # 尝试将类别标签转换为数字
        class_id = 0
        if class_mapping and label in class_mapping:
            class_id = class_mapping[label]
        else:
            try:
                class_id = int(label) - 1  # 默认假设标签是数字，且YOLO格式类别从0开始
            except ValueError:
                # 如果没有映射且不是数字，默认归为0类，或者跳过
                # 这里为了兼容性，打印警告并设为0，或者您可以选择 continue 跳过
                print(f"警告: 无法解析类别标签 '{label}'，默认设为0")
                class_id = 0

        if shape_type == 'rectangle':
            # 矩形标注转换为YOLO格式 (x_center, y_center, width, height)
            if len(points) != 2:
                continue
                
            x1, y1 = points[0]
            x2, y2 = points[1]
            
            x_min, x_max = min(x1, x2), max(x1, x2)
            y_min, y_max = min(y1, y2), max(y1, y2)

            # 计算中心点和宽高
            x_center = (x_min + x_max) / 2.0
            y_center = (y_min + y_max) / 2.0
            width = x_max - x_min
            height = y_max - y_min

            # 归一化坐标
            x_center_norm = x_center / image_width
            y_center_norm = y_center / image_height
            width_norm = width / image_width
            height_norm = height / image_height
            
            # 限制在0-1之间
            x_center_norm = max(0, min(1, x_center_norm))
            y_center_norm = max(0, min(1, y_center_norm))
            width_norm = max(0, min(1, width_norm))
            height_norm = max(0, min(1, height_norm))

            # YOLOv8-pose格式: class_id center_x center_y width height 关键点...
            # 对于矩形标注，关键点暂时设为0（不可见）
            # 假设5个关键点，每个关键点3个值(x, y, visibility)
            keypoints_str = " ".join(["0 0 0"] * 5)
            annotation = f"{class_id} {x_center_norm:.6f} {y_center_norm:.6f} {width_norm:.6f} {height_norm:.6f} {keypoints_str}"
            yolo_annotations.append(annotation)

        elif shape_type == 'point':
            # 点标注，可以作为关键点处理
            x, y = points[0]

            # 归一化坐标
            x_norm = x / image_width
            y_norm = y / image_height

            # 为点标注创建一个边界框（可以是小的固定尺寸）
            bbox_width = 0.02
            bbox_height = 0.02
            bbox_x = x_norm
            bbox_y = y_norm

            # YOLOv8-pose格式: class_id center_x center_y width height 关键点...
            keypoints = ["0 0 0"] * 5

            # 根据标签确定关键点索引（假设标签表示关键点类型）
            kp_idx = 0
            try:
                if class_mapping and label in class_mapping:
                     # 如果有mapping，可能需要特殊的逻辑来决定是第几个关键点
                     # 这里简化处理，假设label数字对应关键点index
                     kp_idx = int(label) - 1
                else:
                    kp_idx = int(label) - 1
                
                if 0 <= kp_idx < 5:
                    keypoints[kp_idx] = f"{x_norm:.6f} {y_norm:.6f} 2" # 2表示可见
            except ValueError:
                keypoints[0] = f"{x_norm:.6f} {y_norm:.6f} 2"

            keypoints_str = " ".join(keypoints)
            annotation = f"{class_id} {bbox_x:.6f} {bbox_y:.6f} {bbox_width:.6f} {bbox_height:.6f} {keypoints_str}"
            yolo_annotations.append(annotation)

    # 写入TXT文件
    with open(output_file, 'w', encoding='utf-8') as f:
        for annotation in yolo_annotations:
            f.write(annotation + '\n')

    print(f"已转换 {json_file} -> {output_file}")
    return True


def batch_convert_json_to_yolov8_pose(json_dir, output_dir, image_width=None, image_height=None, class_mapping=None):
    """
    批量转换JSON文件到YOLOv8-pose格式
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    json_files = [f for f in os.listdir(json_dir) if f.lower().endswith('.json')]

    if not json_files:
        print(f"在 {json_dir} 中未找到JSON文件")
        return

    success_count = 0
    for json_file in json_files:
        json_path = os.path.join(json_dir, json_file)
        try:
            if json_to_yolov8_pose(json_path, output_dir, image_width, image_height, class_mapping):
                success_count += 1
        except Exception as e:
            print(f"处理文件 {json_path} 时出错: {e}")

    print(f"批量转换完成: {success_count}/{len(json_files)} 个文件转换成功")


def main():
    parser = argparse.ArgumentParser(description="Convert LabelMe JSON to YOLOv8-Pose TXT")
    parser.add_argument("--json_dir", type=str, help="Input directory containing JSON files")
    parser.add_argument("--output_dir", type=str, help="Output directory for TXT files")
    parser.add_argument("--width", type=int, default=1280, help="Image width (default: 1280)")
    parser.add_argument("--height", type=int, default=1024, help="Image height (default: 1024)")
    
    args = parser.parse_args()

    # 如果没有提供参数，使用默认路径（方便调试或直接运行）
    json_dir = args.json_dir if args.json_dir else r"C:\Users\30855\Desktop\image_00002.json"
    output_dir = args.output_dir if args.output_dir else r"C:\Users\30855\Desktop\my_File\output_txt"
    
    # 示例类别映射
    class_mapping = {
        "garlic": 0,
        "1": 0,
        "2": 1
    }

    if os.path.isfile(json_dir):
        # 确保输出目录存在
        if output_dir and not os.path.exists(output_dir):
             os.makedirs(output_dir)
        # 如果 output_dir 是文件名
        if output_dir and output_dir.endswith('.txt'):
             # 单文件对单文件
             pass # 需要调整 json_to_yolov8_pose 接口以支持直接输出文件路径，这里简化为只支持目录输出
             print("Output path should be a directory.")
             return

        json_to_yolov8_pose(json_dir, output_dir, args.width, args.height, class_mapping)
    elif os.path.isdir(json_dir):
        batch_convert_json_to_yolov8_pose(json_dir, output_dir, args.width, args.height, class_mapping)
    else:
        print(f"路径不存在: {json_dir}")

if __name__ == "__main__":
    main()
