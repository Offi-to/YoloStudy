import json
import os
from pathlib import Path
from PIL import Image

# 类别映射
CLASS_MAP = {
    # "red": 0,
    # "blue": 1
    "R": 0
}


def convert_rectangle_to_yolo(points, img_w, img_h):
    """
    将矩形的两个对角点转为 YOLO 格式 (中心x, 中心y, 宽, 高) 归一化
    points: [[x1, y1], [x2, y2]]
    """
    x1, y1 = points[0]
    x2, y2 = points[1]
    xmin, xmax = min(x1, x2), max(x1, x2)
    ymin, ymax = min(y1, y2), max(y1, y2)

    w = xmax - xmin
    h = ymax - ymin
    cx = xmin + w / 2
    cy = ymin + h / 2

    # 归一化
    cx /= img_w
    cy /= img_h
    w  /= img_w
    h  /= img_h
    return cx, cy, w, h

def process_json_file(json_path, img_dir, label_dir):
    with open(json_path, 'r') as f:
        data = json.load(f)

    image_filename = data['imagePath']          # 例如 "r_blue0.jpg"
    img_path = os.path.join(img_dir, image_filename)
    if not os.path.exists(img_path):
        print(f"警告: 找不到图片 {img_path}，跳过")
        return

    # 读取图片尺寸
    with Image.open(img_path) as img:
        img_w, img_h = img.size

    # 收集所有标注
    labels = []
    for shape in data['shapes']:
        if shape['shape_type'] != 'rectangle':
            continue   # 只处理矩形
        label_name = shape['label']
        if label_name not in CLASS_MAP:
            print(f"警告: 未知类别 '{label_name}'，跳过")
            continue
        class_id = CLASS_MAP[label_name]
        points = shape['points']
        cx, cy, w, h = convert_rectangle_to_yolo(points, img_w, img_h)
        labels.append(f"{class_id} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}")

    # 写入同名 txt
    txt_filename = os.path.splitext(image_filename)[0] + '.txt'
    txt_path = os.path.join(label_dir, txt_filename)
    os.makedirs(label_dir, exist_ok=True)
    with open(txt_path, 'w') as f:
        f.write('\n'.join(labels))

    print(f"已转换: {json_path} -> {txt_path}")

def main():
    # ---- 根据你的实际目录修改 ----
    json_dir = r"D:\robomaster\RM_DATAS\R_datas_2026_5_2\all"
    img_dir  = r"D:\robomaster\RM_DATAS\R_datas_2026_5_2\all"
    label_dir = r"D:\robomaster\RM_DATAS\R_datas_2026_5_2\all"
    # ----------------------------

    json_files = list(Path(json_dir).glob('*.json'))
    print(f"找到 {len(json_files)} 个 JSON 文件")
    for json_file in json_files:
        process_json_file(json_file, img_dir, label_dir)

if __name__ == '__main__':
    main()