"""
批量将LabelMe格式的JSON标注文件转换为YOLOv8检测训练所需的TXT格式
"""

import json
import os
import argparse
from pathlib import Path

def json_to_yolo_txt(json_file, output_dir, image_width=None, image_height=None, class_mapping=None):
    """
    将单个JSON文件转换为YOLO检测格式的TXT文件

    Args:
        json_file: 输入的JSON文件路径
        output_dir: 输出目录
        image_width: 图片宽度
        image_height: 图片高度
        class_mapping: 类别映射字典 (label -> class_id)
    """
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error reading {json_file}: {e}")
        return False

    # 获取图片尺寸
    if image_width is None or image_height is None:
        if 'imageWidth' in data and 'imageHeight' in data:
            image_width = data['imageWidth']
            image_height = data['imageHeight']
        else:
            print(f"警告: {json_file} 中没有图片尺寸信息")
            return False

    base_name = Path(json_file).stem
    output_file = os.path.join(output_dir, f"{base_name}.txt")

    shapes = data.get('shapes', [])
    yolo_annotations = []

    for shape in shapes:
        label = shape['label']
        points = shape['points']
        shape_type = shape['shape_type']

        # 获取类别ID
        class_id = 0
        if class_mapping and label in class_mapping:
            class_id = class_mapping[label]
        else:
            try:
                class_id = int(label) - 1
            except ValueError:
                # print(f"警告: 无法解析类别标签 '{label}'，跳过")
                continue

        if shape_type == 'rectangle':
            if len(points) < 2:
                continue
                
            x1, y1 = points[0]
            x2, y2 = points[1]
            
            x_min, x_max = min(x1, x2), max(x1, x2)
            y_min, y_max = min(y1, y2), max(y1, y2)

            x_center = (x_min + x_max) / 2.0
            y_center = (y_min + y_max) / 2.0
            width = x_max - x_min
            height = y_max - y_min

            x_center_norm = x_center / image_width
            y_center_norm = y_center / image_height
            width_norm = width / image_width
            height_norm = height / image_height

            x_center_norm = max(0, min(1, x_center_norm))
            y_center_norm = max(0, min(1, y_center_norm))
            width_norm = max(0, min(1, width_norm))
            height_norm = max(0, min(1, height_norm))

            annotation = f"{class_id} {x_center_norm:.6f} {y_center_norm:.6f} {width_norm:.6f} {height_norm:.6f}"
            yolo_annotations.append(annotation)

    with open(output_file, 'w', encoding='utf-8') as f:
        for annotation in yolo_annotations:
            f.write(annotation + '\n')

    print(f"已转换 {json_file} -> {output_file}")
    return True

def batch_convert(json_dir, output_dir, image_width=None, image_height=None, class_mapping=None):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    json_files = [f for f in os.listdir(json_dir) if f.lower().endswith('.json')]
    
    if not json_files:
        print(f"在 {json_dir} 中未找到JSON文件")
        return

    print(f"找到 {len(json_files)} 个JSON文件")
    
    success_count = 0
    for json_file in json_files:
        json_path = os.path.join(json_dir, json_file)
        if json_to_yolo_txt(json_path, output_dir, image_width, image_height, class_mapping):
            success_count += 1
            
    print(f"批量转换完成: {success_count}/{len(json_files)}")

def main():
    parser = argparse.ArgumentParser(description="Convert LabelMe JSON to YOLO Detection TXT")
    parser.add_argument("--json_dir", type=str, help="Directory containing JSON files")
    parser.add_argument("--output_dir", type=str, help="Output directory")
    
    args = parser.parse_args()
    
    json_dir = args.json_dir
    output_dir = args.output_dir
    
    # 交互式输入（如果没有提供命令行参数）
    if not json_dir:
        json_dir = input("请输入包含JSON文件的文件夹路径: ").strip('"')
    
    if not output_dir:
        output_dir = os.path.join(os.path.dirname(json_dir), "output_txt")
        print(f"未指定输出目录，默认使用: {output_dir}")

    # 默认类别映射，按需修改
    class_mapping = {
        "garlic": 0,
        "1": 0,
        "2": 1
    }

    if os.path.exists(json_dir):
        batch_convert(json_dir, output_dir, class_mapping=class_mapping)
    else:
        print("输入路径不存在")

if __name__ == "__main__":
    main()
