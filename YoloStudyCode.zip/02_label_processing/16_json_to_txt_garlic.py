import json
import base64
import os
from io import BytesIO
from PIL import Image


def convert_json_to_yolo_txt(json_data, output_txt_path):
    """
    将单个LabelMe JSON格式的标注数据转换为YOLO格式的TXT文件[1,9](@ref)

    Args:
        json_data (dict): 包含标注信息的JSON字典
        output_txt_path (str): 输出的TXT文件路径
    """
    # 从base64 imageData解码获取图像尺寸[2](@ref)
    image_data = base64.b64decode(json_data['imageData'])
    image = Image.open(BytesIO(image_data))
    img_width, img_height = image.size

    # 准备写入TXT文件
    with open(output_txt_path, 'w') as txt_file:
        for shape in json_data['shapes']:
            # 获取类别ID（直接使用label中的数字）
            class_id = int(shape['label'])

            # 获取边界框的两个点并计算最小/最大坐标[1](@ref)
            points = shape['points']
            x_coords = [p[0] for p in points]
            y_coords = [p[1] for p in points]
            x_min = min(x_coords)
            x_max = max(x_coords)
            y_min = min(y_coords)
            y_max = max(y_coords)

            # 计算边界框中心坐标和宽高[1,3](@ref)
            box_width = x_max - x_min
            box_height = y_max - y_min
            x_center = x_min + box_width / 2
            y_center = y_min + box_height / 2

            # 坐标归一化（除以图像尺寸）[1](@ref)
            x_center_norm = x_center / img_width
            y_center_norm = y_center / img_height
            width_norm = box_width / img_width
            height_norm = box_height / img_height

            # 写入TXT文件（YOLO格式）[3](@ref)
            txt_file.write(f"{class_id} {x_center_norm:.6f} {y_center_norm:.6f} {width_norm:.6f} {height_norm:.6f}\n")


def batch_convert_json_to_yolo(json_folder, output_folder):
    """
    批量将文件夹中的所有JSON文件转换为YOLO格式的TXT文件[1,9](@ref)

    Args:
        json_folder (str): 包含JSON文件的文件夹路径
        output_folder (str): 输出TXT文件的文件夹路径
    """
    # 确保输出文件夹存在[1](@ref)
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"创建输出文件夹: {output_folder}")

    # 获取所有JSON文件[7,8](@ref)
    json_files = [f for f in os.listdir(json_folder) if f.lower().endswith('.json')]

    if not json_files:
        print(f"在文件夹 {json_folder} 中未找到JSON文件")
        return

    print(f"开始批量转换: 共找到 {len(json_files)} 个JSON文件")

    success_count = 0
    error_count = 0

    for json_file in json_files:
        try:
            # 构建完整的文件路径
            json_path = os.path.join(json_folder, json_file)

            # 读取JSON文件[7](@ref)
            with open(json_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)

            # 生成对应的TXT文件名[1](@ref)
            txt_filename = os.path.splitext(json_file)[0] + '.txt'
            txt_path = os.path.join(output_folder, txt_filename)

            # 转换JSON到YOLO TXT格式
            convert_json_to_yolo_txt(json_data, txt_path)

            success_count += 1
            print(f"✓ 成功转换: {json_file} -> {txt_filename}")

        except Exception as e:
            error_count += 1
            print(f"✗ 转换失败: {json_file} - 错误: {str(e)}")

    print(f"\n转换完成!")
    print(f"成功: {success_count} 个文件")
    print(f"失败: {error_count} 个文件")
    print(f"输出目录: {output_folder}")


def batch_convert_with_class_mapping(json_folder, output_folder, class_mapping):
    """
    批量转换并支持类别名称映射[1,9](@ref)

    Args:
        json_folder (str): 包含JSON文件的文件夹路径
        output_folder (str): 输出TXT文件的文件夹路径
        class_mapping (dict): 类别映射字典，如 {"garlic": 0, "head": 1, "tail": 2}
    """
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    json_files = [f for f in os.listdir(json_folder) if f.lower().endswith('.json')]

    if not json_files:
        print(f"在文件夹 {json_folder} 中未找到JSON文件")
        return

    print(f"开始批量转换（使用类别映射）: 共找到 {len(json_files)} 个JSON文件")

    for json_file in json_files:
        try:
            json_path = os.path.join(json_folder, json_file)

            with open(json_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)

            # 从base64 imageData解码获取图像尺寸
            image_data = base64.b64decode(json_data['imageData'])
            image = Image.open(BytesIO(image_data))
            img_width, img_height = image.size

            txt_filename = os.path.splitext(json_file)[0] + '.txt'
            txt_path = os.path.join(output_folder, txt_filename)

            with open(txt_path, 'w') as txt_file:
                for shape in json_data['shapes']:
                    # 使用类别映射[1](@ref)
                    label_name = shape['label']
                    if label_name in class_mapping:
                        class_id = class_mapping[label_name]
                    else:
                        # 如果label是数字，直接使用
                        try:
                            class_id = int(label_name)
                        except ValueError:
                            print(f"警告: 未定义的类别 '{label_name}'，跳过此对象")
                            continue

                    points = shape['points']
                    x_coords = [p[0] for p in points]
                    y_coords = [p[1] for p in points]
                    x_min = min(x_coords)
                    x_max = max(x_coords)
                    y_min = min(y_coords)
                    y_max = max(y_coords)

                    box_width = x_max - x_min
                    box_height = y_max - y_min
                    x_center = x_min + box_width / 2
                    y_center = y_min + box_height / 2

                    x_center_norm = x_center / img_width
                    y_center_norm = y_center / img_height
                    width_norm = box_width / img_width
                    height_norm = box_height / img_height

                    txt_file.write(
                        f"{class_id} {x_center_norm:.6f} {y_center_norm:.6f} {width_norm:.6f} {height_norm:.6f}\n")

            print(f"✓ 成功转换: {json_file} -> {txt_filename}")

        except Exception as e:
            print(f"✗ 转换失败: {json_file} - 错误: {str(e)}")


# 使用示例
if __name__ == "__main__":
    # 方法1: 基本批量转换（使用label中的数字作为类别ID）
    json_folder = r"D:\大蒜数据集\garlic300"  # 替换为你的JSON文件夹路径
    output_folder = r"D:\大蒜数据集\garlic300"  # 替换为你的输出文件夹路径

    batch_convert_json_to_yolo(json_folder, output_folder)

    # 方法2: 使用类别名称映射的批量转换
    class_mapping = {
        "garlic": 0,  # 大蒜对应类别0
        "head": 1,  # 头对应类别1
        "tail": 2  # 尾巴对应类别2
    }

    # 如果你的JSON中label是类别名称而不是数字，使用这个方法
    # batch_convert_with_class_mapping(json_folder, output_folder, class_mapping)