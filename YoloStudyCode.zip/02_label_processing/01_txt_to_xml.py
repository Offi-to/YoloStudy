import os
import cv2
import xml.etree.ElementTree as ET
from xml.dom import minidom

# 配置路径（需要用户修改）
txt_dir = r'E:\datasets\labels'  # TXT标签目录
img_dir = r'E:\datasets\images'  # 图像文件目录
output_dir = r'E:\datasets\xml_labels'  # XML输出目录
classes_file = r'E:\datasets\classes.txt'  # 类别文件路径

# 检查路径有效性
if not os.path.exists(txt_dir):
    raise Exception("TXT标签路径不存在！")
if not os.path.exists(img_dir):
    raise Exception("图像路径不存在！")
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 读取类别列表
with open(classes_file, 'r') as f:
    classes = [line.strip() for line in f.readlines()]


def parse_txt(txt_path):
    """解析YOLO格式TXT文件"""
    objects = []
    with open(txt_path, 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) != 5:
                continue
            class_id = int(parts[0])
            x_center = float(parts[1])
            y_center = float(parts[2])
            width = float(parts[3])
            height = float(parts[4])
            objects.append((class_id, x_center, y_center, width, height))
    return objects


def create_xml(filename, img_size, objects):
    """创建VOC格式XML结构"""
    (h, w, _) = img_size
    root = ET.Element('annotation')

    # 添加文件信息
    ET.SubElement(root, 'folder').text = 'images'
    ET.SubElement(root, 'filename').text = filename
    ET.SubElement(root, 'path').text = os.path.join(img_dir, filename)

    # 添加图像尺寸
    size = ET.SubElement(root, 'size')
    ET.SubElement(size, 'width').text = str(w)
    ET.SubElement(size, 'height').text = str(h)
    ET.SubElement(size, 'depth').text = '3'  # 假设为RGB图像

    # 添加目标对象
    for obj in objects:
        class_id, x_center, y_center, width, height = obj
        obj_elem = ET.SubElement(root, 'object')
        ET.SubElement(obj_elem, 'name').text = classes[class_id]
        ET.SubElement(obj_elem, 'pose').text = 'Unspecified'
        ET.SubElement(obj_elem, 'truncated').text = '0'
        ET.SubElement(obj_elem, 'difficult').text = '0'

        # 计算实际坐标
        x = x_center * w
        y = y_center * h
        w_obj = width * w
        h_obj = height * h
        xmin = max(0, int(x - w_obj / 2))
        xmax = min(w, int(x + w_obj / 2))
        ymin = max(0, int(y - h_obj / 2))
        ymax = min(h, int(y + h_obj / 2))

        # 添加边界框
        bndbox = ET.SubElement(obj_elem, 'bndbox')
        ET.SubElement(bndbox, 'xmin').text = str(xmin)
        ET.SubElement(bndbox, 'xmax').text = str(xmax)
        ET.SubElement(bndbox, 'ymin').text = str(ymin)
        ET.SubElement(bndbox, 'ymax').text = str(ymax)

    # 美化XML格式
    xml_str = ET.tostring(root, 'utf-8')
    dom = minidom.parseString(xml_str)
    return dom.toprettyxml(indent='  ')


# 遍历所有TXT文件
for txt_name in os.listdir(txt_dir):
    if not txt_name.endswith('.txt'):
        continue

    # 获取对应图像文件
    base_name = os.path.splitext(txt_name)[0]
    img_path = os.path.join(img_dir, base_name + '.jpg')  # 根据实际图像格式修改

    # 读取图像尺寸
    if not os.path.exists(img_path):
        print(f"警告：{base_name} 对应的图像文件不存在，已跳过")
        continue

    img = cv2.imread(img_path)
    if img is None:
        print(f"警告：无法读取 {img_path}，已跳过")
        continue

    # 解析TXT标签
    txt_path = os.path.join(txt_dir, txt_name)
    objects = parse_txt(txt_path)

    # 生成XML内容
    xml_content = create_xml(os.path.basename(img_path), img.shape, objects)

    # 保存XML文件
    xml_path = os.path.join(output_dir, base_name + '.xml')
    with open(xml_path, 'w') as f:
        f.write(xml_content)

print(f"转换完成！共处理 {len(os.listdir(txt_dir))} 个TXT文件")
