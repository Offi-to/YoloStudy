import os
import json
import math


def map_label_to_class(label):
    """将标签映射为数字类别"""
    label_mapping = {
        "RR": 0,  # 红色可击打
        "BR": 2,  # 蓝色可击打
        "RW": 1,  # 红色不可击打
        "BW": 3  # 蓝色不可击打
    }
    return label_mapping.get(label.upper(), 0)


def calculate_distance(point1, point2):
    """计算两点之间的欧几里得距离"""
    return math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)


def is_point_in_rectangle(point, rect):
    """判断点是否在矩形内（包括边界）"""
    x, y = point
    x1, y1 = rect['points'][0]
    x2, y2 = rect['points'][1]

    # 确保x1<x2, y1<y2
    x_min = min(x1, x2)
    x_max = max(x1, x2)
    y_min = min(y1, y2)
    y_max = max(y1, y2)

    return x_min <= x <= x_max and y_min <= y <= y_max


def assign_keypoints_to_rectangles(rectangles, keypoints):
    """
    将关键点分配给最匹配的矩形框
    返回字典：矩形索引 -> 关键点字典
    """
    assignments = {}

    # 先尝试将关键点分配给完全包含它的矩形
    for rect_idx, rect in enumerate(rectangles):
        assignments[rect_idx] = {}

    # 为每个关键点找到最适合的矩形
    for kp_label, kp_coord in keypoints.items():
        best_rect_idx = None
        min_distance = float('inf')

        for rect_idx, rect in enumerate(rectangles):
            rect_class = map_label_to_class(rect['label'])

            # 只考虑可击打的矩形框（RR或BR）可以有关键点
            if rect_class in [0, 2]:  # RR或BR
                if is_point_in_rectangle(kp_coord, rect):
                    # 如果点在矩形内，直接分配
                    assignments[rect_idx][kp_label] = kp_coord
                    break
                else:
                    # 计算点到矩形中心的距离
                    x1, y1 = rect['points'][0]
                    x2, y2 = rect['points'][1]
                    rect_center = [(x1 + x2) / 2, (y1 + y2) / 2]
                    distance = calculate_distance(kp_coord, rect_center)

                    if distance < min_distance:
                        min_distance = distance
                        best_rect_idx = rect_idx

        else:  # 没有矩形包含该点，分配给最近的矩形
            if best_rect_idx is not None:
                assignments[best_rect_idx][kp_label] = kp_coord

    return assignments


def process_single_json(json_path, image_width=1280, image_height=1024):
    """处理单个JSON文件，处理多个矩形框的情况"""
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # 分离矩形框和关键点
        rectangles = []
        keypoints = {}

        for shape in data['shapes']:
            if shape['shape_type'] == 'rectangle':
                rectangles.append(shape)
            elif shape['shape_type'] == 'point':
                keypoints[shape['label']] = shape['points'][0]

        if not rectangles:
            print(f"警告: {json_path} 中没有找到矩形框")
            return []

        # 将关键点分配给矩形框
        kp_assignments = assign_keypoints_to_rectangles(rectangles, keypoints)

        output_lines = []

        # 为每个矩形框生成一行
        for rect_idx, rect in enumerate(rectangles):
            # 计算整体框的归一化坐标
            x1, y1 = rect['points'][0]
            x2, y2 = rect['points'][1]

            # 确保x1<x2, y1<y2
            x_min = min(x1, x2)
            x_max = max(x1, x2)
            y_min = min(y1, y2)
            y_max = max(y1, y2)

            # 计算中心点、宽度、高度
            x_center = (x_min + x_max) / 2
            y_center = (y_min + y_max) / 2
            width = x_max - x_min
            height = y_max - y_min

            # 归一化
            nx_center = x_center / image_width
            ny_center = y_center / image_height
            nwidth = width / image_width
            nheight = height / image_height

            # 获取矩形类别
            rect_class = map_label_to_class(rect['label'])

            # 定义关键点顺序: lt, tt, tb, tl, ct
            point_order = ['lt', 'tt', 'tb', 'tl', 'ct']

            # 获取该矩形框的关键点
            rect_keypoints = kp_assignments.get(rect_idx, {})

            # 准备输出行
            output_parts = []

            # 添加整体框信息
            output_parts.append(f"{rect_class} {nx_center:.5f} {ny_center:.5f} {nwidth:.5f} {nheight:.5f}")

            # 添加关键点信息（每个点后跟可见性标志）
            for point_label in point_order:
                if point_label in rect_keypoints:
                    x, y = rect_keypoints[point_label]
                    nx = x / image_width
                    ny = y / image_height
                    # 关键点存在且可见，使用2
                    output_parts.append(f"{nx:.5f} {ny:.5f} 2")
                else:
                    # 关键点不存在，使用0 0 0
                    output_parts.append("0.00000 0.00000 0")

            output_lines.append(" ".join(output_parts))

        return output_lines

    except Exception as e:
        print(f"处理 {json_path} 时出错: {e}")
        import traceback
        traceback.print_exc()
        return []


def batch_process_folder(input_folder, output_folder, image_width=1280, image_height=1024):
    """批量处理整个文件夹"""
    # 创建输出文件夹
    os.makedirs(output_folder, exist_ok=True)

    # 统计处理结果
    success_count = 0
    failed_count = 0
    total_objects = 0

    # 遍历输入文件夹中的所有json文件
    for filename in os.listdir(input_folder):
        if not filename.endswith('.json'):
            continue

        input_path = os.path.join(input_folder, filename)

        # 处理JSON文件
        output_lines = process_single_json(input_path, image_width, image_height)

        if output_lines:
            # 生成输出文件名（将.json替换为.txt）
            output_filename = filename.replace('.json', '.txt')
            output_path = os.path.join(output_folder, output_filename)

            # 写入输出文件（每个矩形框一行）
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write("\n".join(output_lines))

            success_count += 1
            total_objects += len(output_lines)
            print(f"成功处理: {filename} -> {len(output_lines)} 个对象")
        else:
            failed_count += 1
            print(f"处理失败: {filename}")

    # 输出统计信息
    print(f"\n处理完成!")
    print(f"成功: {success_count} 个文件，{total_objects} 个对象")
    print(f"失败: {failed_count} 个文件")

    # 生成示例文件
    generate_example(output_folder)


def generate_example(output_folder):
    """生成示例文件说明"""
    example_file = os.path.join(output_folder, "format_example.txt")
    with open(example_file, 'w', encoding='utf-8') as f:
        f.write("""# YOLOv8-Pose 数据格式说明
# 每行对应一个对象，格式: <class> <x_center> <y_center> <width> <height> <x_lt> <y_lt> <conf> <x_tt> <y_tt> <conf> <x_tb> <y_tb> <conf> <x_tl> <y_tl> <conf> <x_ct> <y_ct> <conf>

# 类别映射:
# 0: 红色可击打 (RR)
# 1: 红色不可击打 (RW)
# 2: 蓝色可击打 (BR)
# 3: 蓝色不可击打 (BW)

# 关键点顺序:
# 1. lt (左上)
# 2. tt (右上)
# 3. tb (右下)
# 4. tl (左下)
# 5. ct (中心)

# 关键点置信度说明:
# 2: 关键点存在且可见
# 0: 关键点不存在或不可见（坐标设为0）

# 所有坐标已归一化到 [0, 1] 范围
# 图像尺寸: 1280x1024

# 示例行（RR对象有关键点）:
0 0.51151 0.12353 0.05407 0.06855 0.63944 0.32757 2 0.66582 0.34438 2 0.65211 0.37834 2 0.62572 0.36217 2 0.64616 0.35344 2

# 示例行（RW对象无关键点）:
1 0.45781 0.23594 0.04531 0.05313 0.00000 0.00000 0 0.00000 0.00000 0 0.00000 0.00000 0 0.00000 0.00000 0 0.00000 0.00000 0
""")


if __name__ == "__main__":
    # 配置参数
    input_folder = r"C:\Users\30855\Desktop\buff2026.3.2\red2026.2.24\labels"  # 修改为您的JSON文件夹路径
    output_folder = r"C:\Users\30855\Desktop\buff2026.3.2\red2026.2.24\labels"  # 修改为输出文件夹路径
    image_width = 1280
    image_height = 1024

    # 运行批量处理
    print(f"开始转换...")
    print(f"输入文件夹: {input_folder}")
    print(f"输出文件夹: {output_folder}")
    print(f"图像尺寸: {image_width}x{image_height}")

    batch_process_folder(input_folder, output_folder, image_width, image_height)