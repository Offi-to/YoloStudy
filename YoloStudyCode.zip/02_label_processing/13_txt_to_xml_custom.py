import os
import xml.etree.ElementTree as ET
from xml.dom import minidom


def yolo_to_voc(txt_path, img_width, img_height, class_names):
    """将YOLO格式转换为VOC XML格式"""

    # 读取txt文件
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # 创建XML结构
    annotation = ET.Element("annotation")

    # 添加基本信息
    folder = ET.SubElement(annotation, "folder")
    folder.text = "images"

    filename_elem = ET.SubElement(annotation, "filename")
    filename_elem.text = os.path.basename(txt_path).replace('.txt', '.jpg')

    # 图片尺寸（固定为1280×1024）
    size = ET.SubElement(annotation, "size")
    ET.SubElement(size, "width").text = str(img_width)
    ET.SubElement(size, "height").text = str(img_height)
    ET.SubElement(size, "depth").text = "3"

    # 添加source信息
    source = ET.SubElement(annotation, "source")
    ET.SubElement(source, "database").text = "Unknown"

    # 添加segmented信息
    ET.SubElement(annotation, "segmented").text = "0"

    # 处理每个检测框
    for line in lines:
        data = line.strip().split()
        if len(data) == 5:
            class_id, x_center, y_center, width, height = map(float, data)

            # 转换为绝对坐标
            x_center_abs = x_center * img_width
            y_center_abs = y_center * img_height
            width_abs = width * img_width
            height_abs = height * img_height

            # 计算边界框坐标
            xmin = max(0, int(x_center_abs - width_abs / 2))
            ymin = max(0, int(y_center_abs - height_abs / 2))
            xmax = min(img_width, int(x_center_abs + width_abs / 2))
            ymax = min(img_height, int(y_center_abs + height_abs / 2))

            # 确保边界框有效
            if xmin >= xmax or ymin >= ymax:
                print(f"警告: 跳过无效的边界框 {xmin},{ymin},{xmax},{ymax} 在文件 {txt_path}")
                continue

            # 创建object节点
            obj = ET.SubElement(annotation, "object")
            ET.SubElement(obj, "name").text = class_names[int(class_id)]
            ET.SubElement(obj, "pose").text = "Unspecified"
            ET.SubElement(obj, "truncated").text = "0"
            ET.SubElement(obj, "difficult").text = "0"

            # 边界框
            bbox = ET.SubElement(obj, "bndbox")
            ET.SubElement(bbox, "xmin").text = str(xmin)
            ET.SubElement(bbox, "ymin").text = str(ymin)
            ET.SubElement(bbox, "xmax").text = str(xmax)
            ET.SubElement(bbox, "ymax").text = str(ymax)

    return annotation


def batch_convert(txt_folder, output_xml_folder, img_width=1280, img_height=1024):
    """批量转换函数 - 简化版，不需要图片文件"""

    # 类别映射
    class_names = {0: "garlic", 1: "head", 2: "tail"}

    # 创建输出文件夹
    if not os.path.exists(output_xml_folder):
        os.makedirs(output_xml_folder)

    # 统计信息
    success_count = 0
    error_count = 0

    # 遍历所有txt文件
    for txt_file in os.listdir(txt_folder):
        if txt_file.endswith('.txt'):
            txt_path = os.path.join(txt_folder, txt_file)
            base_name = os.path.splitext(txt_file)[0]

            try:
                # 转换标注格式
                xml_annotation = yolo_to_voc(txt_path, img_width, img_height, class_names)

                # 保存XML文件
                xml_str = minidom.parseString(ET.tostring(xml_annotation)).toprettyxml(indent="  ")
                # 移除多余的XML声明
                xml_str = os.linesep.join([s for s in xml_str.splitlines() if s.strip()])

                xml_output_path = os.path.join(output_xml_folder, base_name + '.xml')

                with open(xml_output_path, 'w', encoding='utf-8') as f:
                    f.write(xml_str)

                success_count += 1
                print(f"成功转换: {txt_file} -> {base_name}.xml")

            except Exception as e:
                print(f"错误: 转换文件 {txt_file} 时出错: {e}")
                error_count += 1

    # 输出统计信息
    print(f"\n转换完成!")
    print(f"成功: {success_count} 个文件")
    print(f"失败: {error_count} 个文件")
    print(f"图片尺寸: {img_width}×{img_height}")


def main():
    # 文件夹路径配置
    txt_folder = r"D:\大蒜数据集\garlic300\labels"  # 存放txt标注文件的文件夹
    output_xml_folder = r"D:\大蒜数据集\garlic300\labels"  # 输出XML文件的文件夹

    # 检查输入文件夹是否存在
    if not os.path.exists(txt_folder):
        print(f"错误: 标注文件夹 {txt_folder} 不存在")
        return

    print("开始转换YOLO格式到VOC XML格式...")
    print(f"图片尺寸: 1280×1024 (固定)")

    # 执行批量转换
    batch_convert(txt_folder, output_xml_folder)


if __name__ == "__main__":
    main()