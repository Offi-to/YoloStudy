import os
import shutil


def modify_first_value_to_zero(folder_path):
    """
    批量修改指定文件夹中所有txt文件，将每行第一个数值改为0
    会自动创建备份文件夹，存放修改前的原文件
    """
    # 创建备份文件夹
    backup_folder = os.path.join(folder_path, "backup_before_modify")
    if not os.path.exists(backup_folder):
        os.makedirs(backup_folder)
        print(f"已创建备份文件夹: {backup_folder}")

    # 统计修改的文件和行数
    modified_files_count = 0
    modified_lines_count = 0

    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        if filename.endswith(".txt") and filename != "backup_before_modify":
            file_path = os.path.join(folder_path, filename)

            # 跳过文件夹
            if os.path.isdir(file_path):
                continue

            # 备份原文件
            backup_path = os.path.join(backup_folder, filename)
            shutil.copy2(file_path, backup_path)

            # 读取并修改文件内容
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()

                new_lines = []
                file_modified = False

                for line in lines:
                    # 去除首尾空白字符
                    stripped_line = line.strip()

                    # 跳过空行
                    if not stripped_line:
                        new_lines.append(line)
                        continue

                    # 按空格分割数值
                    values = stripped_line.split()

                    # 确保至少有一个数值
                    if len(values) >= 1:
                        # 将第一个值改为0
                        values[0] = "0"
                        # 重新拼接成一行，保持原有的空格分隔
                        new_line = ' '.join(values) + '\n'
                        new_lines.append(new_line)
                        modified_lines_count += 1
                        file_modified = True
                    else:
                        new_lines.append(line)

                # 如果文件有修改，写回文件
                if file_modified:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.writelines(new_lines)
                    modified_files_count += 1
                    print(f"已修改: {filename}")

            except Exception as e:
                print(f"处理文件 {filename} 时出错: {str(e)}")

    # 输出统计结果
    print("\n" + "=" * 50)
    print(f"处理完成！")
    print(f"共修改了 {modified_files_count} 个文件")
    print(f"共修改了 {modified_lines_count} 行数据")
    print(f"原文件已备份到: {backup_folder}")
    print("=" * 50)


# ------------------- 使用方法 -------------------
# 1. 将下面的路径改为你的txt文件所在的文件夹路径
# 2. 运行脚本即可
if __name__ == "__main__":
    # 示例：Windows路径
    # folder_path = r"C:\Users\YourName\Desktop\your_txt_files"

    # 示例：Linux/Mac路径
    # folder_path = "/home/yourname/your_txt_files"

    # 请在这里修改为你的实际文件夹路径
    folder_path = r"D:\robomaster\RM_DATAS\R_datas_2026_5_2\all"

    # 检查路径是否存在
    if os.path.exists(folder_path) and os.path.isdir(folder_path):
        modify_first_value_to_zero(folder_path)
    else:
        print(f"错误：文件夹路径不存在或不是一个有效的文件夹")
        print(f"你输入的路径是: {folder_path}")
