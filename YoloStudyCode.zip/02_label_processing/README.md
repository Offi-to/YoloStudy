# JSON to YOLOv8-pose 转换工具

此脚本用于将LabelMe格式的JSON标注文件转换为YOLOv8-pose训练所需的TXT格式。

## 功能特点

- 支持矩形标注（转换为边界框）
- 支持点标注（作为姿态关键点）
- 批量处理整个目录中的JSON文件
- 输出符合YOLOv8-pose格式要求的TXT文件

## YOLOv8-pose格式说明

输出的TXT文件格式为：
```
class_id center_x center_y width height keypoint1_x keypoint1_y keypoint1_visibility keypoint2_x keypoint2_y keypoint2_visibility ...
```

所有坐标均为归一化值（相对于图片宽度和高度）。

## 使用方法

1. **准备数据**：
   - 将JSON文件放在指定的输入目录中
   - 确定图片的宽度和高度

2. **修改脚本参数**：
   编辑 `07_json_to_yolov8_pose.py` 文件中的以下参数：
   ```python
   json_input_path = r"your_json_directory_path"  # JSON文件目录路径
   output_path = r"your_output_directory_path"    # 输出TXT文件目录路径
   image_width = your_image_width                 # 图片宽度
   image_height = your_image_height               # 图片高度
   ```

3. **运行脚本**：
   ```
   python 07_json_to_yolov8_pose.py
   ```

## 示例

根据您提供的JSON格式：
- 标签为"1"和"2"的矩形标注将转换为边界框
- 标签为"3"的点标注将作为关键点处理

## 注意事项

- 确保图片尺寸参数正确，否则坐标归一化会出错
- 类别标签将从1开始的数字转换为YOLO格式的0开始索引
- 关键点的可见性值：0=不可见，1=遮挡，2=可见