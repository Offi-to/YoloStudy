import os
import sys
import json


def batch_rename_json_files(folder_path, start_index=0, filename_prefix="data_", dry_run=False):
    """
    批量重命名文件夹中的JSON文件

    Args:
        folder_path (str): JSON文件夹路径
        start_index (int): 文件名称的起始编号，默认为0
        filename_prefix (str): 文件名称前缀，默认为"data_"
        dry_run (bool): 试运行模式，只显示将要进行的更改而不实际执行
    """
    # 检查文件夹路径是否存在
    if not os.path.exists(folder_path):
        print(f"错误: 文件夹不存在 - {folder_path}")
        return False

    # 支持的JSON文件格式
    supported_formats = [".json", ".jsonl"]

    # 获取文件夹中所有文件
    try:
        all_files = os.listdir(folder_path)
    except PermissionError:
        print(f"错误: 没有权限访问文件夹 - {folder_path}")
        return False

    # 过滤出JSON文件
    json_files = [f for f in all_files
                  if os.path.isfile(os.path.join(folder_path, f)) and
                  os.path.splitext(f)[1].lower() in supported_formats]

    if not json_files:
        print("在指定文件夹中没有找到支持的JSON文件")
        print(f"支持的格式: {', '.join(supported_formats)}")
        return False

    # 按文件名排序，确保顺序一致
    json_files.sort()

    print(f"找到 {len(json_files)} 个JSON文件")

    if dry_run:
        print("=== 试运行模式（不会实际重命名）===")
    else:
        print("开始重命名...")

    renamed_count = 0
    rename_plan = []

    for index, filename in enumerate(json_files):
        # 获取文件扩展名
        file_extension = os.path.splitext(filename)[1]

        # 生成新文件名
        new_filename = f"{filename_prefix}{start_index + index:05d}{file_extension}"

        # 完整的旧文件路径和新文件路径
        old_file_path = os.path.join(folder_path, filename)
        new_file_path = os.path.join(folder_path, new_filename)

        # 检查新文件名是否已存在（避免覆盖）
        if os.path.exists(new_file_path) and old_file_path != new_file_path:
            print(f"警告: 文件名 {new_filename} 已存在，跳过重命名 {filename}")
            continue

        rename_plan.append((old_file_path, new_file_path, filename, new_filename))

    # 执行重命名操作
    for old_file_path, new_file_path, filename, new_filename in rename_plan:
        if dry_run:
            print(f"[试运行] 将重命名: {filename} -> {new_filename}")
            renamed_count += 1
        else:
            try:
                # 重命名文件
                os.rename(old_file_path, new_file_path)
                renamed_count += 1
                print(f"已重命名: {filename} -> {new_filename}")

                # 可选：验证JSON文件有效性
                if file_extension.lower() == '.json':
                    try:
                        with open(new_file_path, 'r', encoding='utf-8') as f:
                            json.load(f)  # 尝试解析JSON验证格式
                    except json.JSONDecodeError as e:
                        print(f"警告: 文件 {new_filename} 可能不是有效的JSON格式: {e}")

            except Exception as e:
                print(f"重命名失败 {filename}: {str(e)}")

    if dry_run:
        print(f"试运行完成! 将重命名 {renamed_count} 个文件")
    else:
        print(f"重命名完成! 成功重命名 {renamed_count} 个文件")

    return True


def validate_json_files(folder_path):
    """
    验证文件夹中所有JSON文件的有效性
    """
    print("开始验证JSON文件格式...")

    try:
        all_files = os.listdir(folder_path)
    except Exception as e:
        print(f"访问文件夹失败: {e}")
        return False

    json_files = [f for f in all_files if f.lower().endswith('.json')]
    valid_count = 0

    for json_file in json_files:
        file_path = os.path.join(folder_path, json_file)
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json.load(f)
            valid_count += 1
        except Exception as e:
            print(f"无效的JSON文件: {json_file} - {e}")

    print(f"JSON文件验证完成: {valid_count}/{len(json_files)} 个文件有效")
    return valid_count == len(json_files)


if __name__ == "__main__":
    # 设置默认参数
    folder_path = r"C:\Users\30855\Desktop\2026.3.7大蒜数据"  # JSON文件夹路径
    start_index = 838
    filename_prefix = "garlic_"
    dry_run = False

    # 解析命令行参数
    if len(sys.argv) >= 2:
        folder_path = sys.argv[1]

    if len(sys.argv) >= 3:
        try:
            start_index = int(sys.argv[2])
        except ValueError:
            print("错误: 起始索引必须是数字")
            sys.exit(1)

    if len(sys.argv) >= 4:
        filename_prefix = sys.argv[3]

    if len(sys.argv) >= 5:
        dry_run = sys.argv[4].lower() in ['true', '1', 'yes', 'y']

    # 显示重命名计划
    print("=== JSON文件批量重命名工具 ===")
    print(f"目标文件夹: {folder_path}")
    print(f"起始索引: {start_index}")
    print(f"文件前缀: {filename_prefix}")
    print(f"试运行模式: {dry_run}")
    print("-" * 50)

    # 执行批量重命名
    success = batch_rename_json_files(folder_path, start_index, filename_prefix, dry_run)

    if not dry_run and success:
        # 验证重命名后的文件
        validate_json_files(folder_path)

    if not success:
        sys.exit(1)

    print("JSON文件批量重命名任务完成!")