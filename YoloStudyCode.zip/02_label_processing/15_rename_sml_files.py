import os
import sys
import xml.etree.ElementTree as ET


def batch_rename_xml_files(folder_path, start_index=0, filename_prefix="data_", dry_run=False):
    """
    批量重命名文件夹中的XML文件

    Args:
        folder_path (str): XML文件夹路径
        start_index (int): 文件名称的起始编号，默认为0
        filename_prefix (str): 文件名称前缀，默认为"data_"
        dry_run (bool): 试运行模式，只显示将要进行的更改而不实际执行
    """
    # 检查文件夹路径是否存在
    if not os.path.exists(folder_path):
        print(f"错误: 文件夹不存在 - {folder_path}")
        return False

    # 支持的XML文件格式
    supported_formats = [".xml"]

    # 获取文件夹中所有文件
    try:
        all_files = os.listdir(folder_path)
    except PermissionError:
        print(f"错误: 没有权限访问文件夹 - {folder_path}")
        return False

    # 过滤出XML文件[3,5](@ref)
    xml_files = [f for f in all_files
                 if os.path.isfile(os.path.join(folder_path, f)) and
                 os.path.splitext(f)[1].lower() in supported_formats]

    if not xml_files:
        print("在指定文件夹中没有找到支持的XML文件")
        print(f"支持的格式: {', '.join(supported_formats)}")
        return False

    # 按文件名排序，确保顺序一致[1](@ref)
    xml_files.sort()

    print(f"找到 {len(xml_files)} 个XML文件")

    if dry_run:
        print("=== 试运行模式（不会实际重命名）===")
    else:
        print("开始重命名...")

    renamed_count = 0
    rename_plan = []

    for index, filename in enumerate(xml_files):
        # 获取文件扩展名
        file_extension = os.path.splitext(filename)[1]

        # 生成新文件名[4](@ref)
        new_filename = f"{filename_prefix}{start_index + index:05d}{file_extension}"

        # 完整的旧文件路径和新文件路径
        old_file_path = os.path.join(folder_path, filename)
        new_file_path = os.path.join(folder_path, new_filename)

        # 检查新文件名是否已存在（避免覆盖）[6](@ref)
        if os.path.exists(new_file_path) and old_file_path != new_file_path:
            print(f"警告: 文件名 {new_filename} 已存在，跳过重命名 {filename}")
            continue

        rename_plan.append((old_file_path, new_file_path, filename, new_filename))

    # 执行重命名操作[1,7](@ref)
    for old_file_path, new_file_path, filename, new_filename in rename_plan:
        if dry_run:
            print(f"[试运行] 将重命名: {filename} -> {new_filename}")
            renamed_count += 1
        else:
            try:
                # 重命名文件
                os.rename(old_file_path, new_file_path)
                renamed_count += 1
                print(f"已重命名: {filename} -> {new_filename}")

                # 可选：验证XML文件有效性并更新内部引用[5,8](@ref)
                try:
                    tree = ET.parse(new_file_path)
                    root = tree.getroot()

                    # 查找并更新filename节点（如果存在）[5](@ref)
                    filename_elem = root.find('filename')
                    if filename_elem is not None:
                        filename_elem.text = new_filename
                        tree.write(new_file_path, encoding='utf-8', xml_declaration=True)
                        print(f"已更新XML内部filename引用: {new_filename}")

                except ET.ParseError as e:
                    print(f"警告: 文件 {new_filename} 可能不是有效的XML格式: {e}")
                except Exception as e:
                    print(f"警告: 更新XML内部引用时出错: {e}")

            except Exception as e:
                print(f"重命名失败 {filename}: {str(e)}")

    if dry_run:
        print(f"试运行完成! 将重命名 {renamed_count} 个文件")
    else:
        print(f"重命名完成! 成功重命名 {renamed_count} 个文件")

    return True


def validate_xml_files(folder_path):
    """
    验证文件夹中所有XML文件的有效性[2,8](@ref)
    """
    print("开始验证XML文件格式...")

    try:
        all_files = os.listdir(folder_path)
    except Exception as e:
        print(f"访问文件夹失败: {e}")
        return False

    xml_files = [f for f in all_files if f.lower().endswith('.xml')]
    valid_count = 0

    for xml_file in xml_files:
        file_path = os.path.join(folder_path, xml_file)
        try:
            # 尝试解析XML验证格式有效性[2](@ref)
            tree = ET.parse(file_path)
            valid_count += 1
        except Exception as e:
            print(f"无效的XML文件: {xml_file} - {e}")

    print(f"XML文件验证完成: {valid_count}/{len(xml_files)} 个文件有效")
    return valid_count == len(xml_files)


def main():
    """
    直接在这里修改路径和参数，然后运行脚本即可
    """
    # ====== 在这里直接修改你的路径和参数 ======

    # XML文件夹路径（直接修改这里）
    folder_path = r"D:\that_is_saving_something\2026.1.20临时存储\模型训练4\train\xml"

    # 起始编号（默认从0开始）
    start_index = 1

    # 文件名前缀（默认"data_"）
    filename_prefix = "frame_"

    # 试运行模式（True只显示将要进行的更改，False实际执行）
    dry_run = False

    # ======================================

    print("=" * 50)
    print("XML文件批量重命名工具")
    print("=" * 50)
    print(f"目标文件夹: {folder_path}")
    print(f"起始编号: {start_index}")
    print(f"文件前缀: {filename_prefix}")
    print(f"试运行模式: {dry_run}")
    print("=" * 50)

    # 确认操作（仅在非试运行模式下询问）
    if not dry_run:
        confirm = input("确认开始重命名？(y/n): ")
        if confirm.lower() != 'y':
            print("操作已取消")
            return

    # 执行重命名
    success = batch_rename_xml_files(folder_path, start_index, filename_prefix, dry_run)

    if not dry_run and success:
        # 验证重命名后的文件
        validate_xml_files(folder_path)

    if not success:
        print("处理完成，但存在一些问题")
        sys.exit(1)
    else:
        print("所有文件处理成功!")


if __name__ == "__main__":
    main()