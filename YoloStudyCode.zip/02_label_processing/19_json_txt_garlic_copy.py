import os
import json
from pathlib import Path


def convert_json_to_yolo(json_dir, output_dir, img_width=1280, img_height=1024):
    """
    将指定文件夹内的所有 JSON 标注文件批量转换为 YOLO 格式的 TXT 文件。

    参数:
        json_dir (str): 存放 JSON 文件的文件夹路径。
        output_dir (str): 输出 TXT 文件的文件夹路径。
        img_width (int): 图像宽度，用于坐标归一化。
        img_height (int): 图像高度，用于坐标归一化。
    """
    # 创建输出目录（如果不存在）
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # 定义标签到索引的映射 (根据您的标签顺序: U -> 0, D -> 1)
    label_map = {"U": 0, "D": 1}
    # 或者，如果标签名是动态的，可以使用以下方法自动构建（但顺序不固定）：
    # labels = sorted(set([shape["label"] for json_file in json_files for shape in json_data.get("shapes", [])]))
    # label_map = {label: idx for idx, label in enumerate(labels)}

    # 获取所有 JSON 文件
    json_files = [f for f in os.listdir(json_dir) if f.lower().endswith('.json')]
    print(f"找到 {len(json_files)} 个 JSON 文件。")

    for json_filename in json_files:
        json_path = os.path.join(json_dir, json_filename)

        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            print(f"错误：无法读取文件 {json_path}。错误信息: {e}")
            continue

        # 准备 YOLO 格式内容
        yolo_lines = []
        shapes = data.get("shapes", [])

        for shape in shapes:
            label_name = shape.get("label", "")
            # 检查标签是否在映射中
            if label_name not in label_map:
                print(f"警告：在文件 {json_filename} 中发现未知标签 '{label_name}'，已跳过。")
                continue

            class_id = label_map[label_name]
            points = shape.get("points", [])
            shape_type = shape.get("shape_type", "")

            # 目前只处理矩形框（rectangle）
            if shape_type == "rectangle" and len(points) == 2:
                # 获取矩形框的左上角 (x1, y1) 和右下角 (x2, y2)
                x1, y1 = points[0]
                x2, y2 = points[1]

                # 确保坐标顺序（x1 <= x2, y1 <= y2）
                x1, x2 = min(x1, x2), max(x1, x2)
                y1, y2 = min(y1, y2), max(y1, y2)

                # 计算中心点、宽度和高度（像素值）
                x_center = (x1 + x2) / 2.0
                y_center = (y1 + y2) / 2.0
                width = x2 - x1
                height = y2 - y1

                # 归一化到 [0, 1]
                x_center_norm = x_center / img_width
                y_center_norm = y_center / img_height
                width_norm = width / img_width
                height_norm = height / img_height

                # 确保归一化坐标在有效范围内（可选的裁剪）
                x_center_norm = max(0.0, min(1.0, x_center_norm))
                y_center_norm = max(0.0, min(1.0, y_center_norm))
                width_norm = max(0.0, min(1.0, width_norm))
                height_norm = max(0.0, min(1.0, height_norm))

                # 写入行: class_id x_center y_center width height
                yolo_lines.append(
                    f"{class_id} {x_center_norm:.6f} {y_center_norm:.6f} {width_norm:.6f} {height_norm:.6f}")
            else:
                print(f"警告：在文件 {json_filename} 中跳过非矩形或点无效的形状（类型: {shape_type}）。")

        # 写入 TXT 文件（与 JSON 同名）
        txt_filename = os.path.splitext(json_filename)[0] + ".txt"
        txt_path = os.path.join(output_dir, txt_filename)

        try:
            with open(txt_path, 'w', encoding='utf-8') as f:
                f.write("\n".join(yolo_lines))
            # print(f"已创建: {txt_path}") # 如果不需要每个文件的确认，可以注释掉
        except Exception as e:
            print(f"错误：无法写入文件 {txt_path}。错误信息: {e}")

    print("转换完成！")


if __name__ == "__main__":
    # ******************** 配置参数 ********************
    # 请修改以下路径和参数以匹配您的数据集
    JSON_FOLDER = r"C:\Users\30855\Desktop\2026.3.7大蒜数据"  # 您的 JSON 文件所在文件夹路径
    OUTPUT_FOLDER = r"C:\Users\30855\Desktop\2026.3.7大蒜数据"  # 希望输出 YOLO TXT 文件的文件夹路径
    IMAGE_WIDTH = 1280  # 图像宽度（像素）
    IMAGE_HEIGHT = 1024  # 图像高度（像素）
    # ************************************************

    # 执行转换
    convert_json_to_yolo(JSON_FOLDER, OUTPUT_FOLDER, IMAGE_WIDTH, IMAGE_HEIGHT)