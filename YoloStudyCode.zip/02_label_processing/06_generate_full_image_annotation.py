import os
from PIL import Image


def generate_yolo_annotations(image_folder, class_id=0):
    """
    为指定文件夹中的每张图片生成YOLO格式的标注文件（.txt）

    参数:
        image_folder: 包含图片的文件夹路径
        class_id: 目标物体的类别ID（根据你的data.yaml中的顺序，'1'基地可能是0）
    """
    # 支持常见的图片格式
    image_extensions = ('.jpg', '.jpeg', '.png', '.bmp', '.tiff')

    # 遍历文件夹中的所有文件
    for filename in os.listdir(image_folder):
        if filename.lower().endswith(image_extensions):
            image_path = os.path.join(image_folder, filename)

            try:
                # 打开图片获取尺寸
                with Image.open(image_path) as img:
                    img_width, img_height = img.size

                # 由于目标物体在正中央且没有其他内容，边界框就是整个图片
                x_center = 0.5  # 归一化后的中心点x坐标
                y_center = 0.5  # 归一化后的中心点y坐标
                width = 1.0  # 归一化后的边界框宽度
                height = 1.0  # 归一化后的边界框高度

                #输入你想识别的目标物体的类别ID
                class_id = 9

                # 生成对应的TXT标注文件名
                txt_filename = os.path.splitext(filename)[0] + '.txt'
                txt_path = os.path.join(image_folder, txt_filename)

                # 将标注写入TXT文件
                with open(txt_path, 'w') as f:
                    f.write(f"{class_id} {x_center} {y_center} {width} {height}")

                print(f"已生成: {txt_filename}")

            except Exception as e:
                print(f"处理图片 {filename} 时出错: {e}")


# 使用示例
if __name__ == "__main__":
    # 替换为你的“1”类别图片所在文件夹的实际路径
    image_folder_path = r"C:\Users\30855\Desktop\数字识别训练\num_datasets\9背景"
    generate_yolo_annotations(image_folder_path, class_id=0)  # 假设'1'的类别ID是0