import json
import os
import base64
from io import BytesIO
from PIL import Image


def convert_json_to_yolo_txt(json_data, output_txt_path, json_filepath=None):
    """
    将单个LabelMe JSON格式的标注数据转换为YOLO格式的TXT文件

    Args:
        json_data (dict): 包含标注信息的JSON字典
        output_txt_path (str): 输出的TXT文件路径
        json_filepath (str, optional): JSON文件的完整路径，用于查找图像文件
    """
    # 方法1: 尝试从JSON的imageData字段获取图像数据
    if json_data.get('imageData') is not None:
        try:
            image_data = base64.b64decode(json_data['imageData'])
            image = Image.open(BytesIO(image_data))
            img_width, img_height = image.size
        except:
            # 如果base64解码失败，使用方法2
            img_width = json_data.get('imageWidth')
            img_height = json_data.get('imageHeight')
    else:
        # 方法2: 直接从JSON中获取图像尺寸
        img_width = json_data.get('imageWidth')
        img_height = json_data.get('imageHeight')

    # 如果以上方法都失败，使用方法3: 从图像文件获取尺寸
    if img_width is None or img_height is None:
        if json_filepath and os.path.exists(json_filepath):
            # 尝试找到对应的图像文件
            image_path_in_json = json_data.get('imagePath', '')

            # 构建可能的图像文件路径
            json_dir = os.path.dirname(json_filepath)
            possible_image_paths = [
                os.path.join(json_dir, image_path_in_json),
                os.path.join(json_dir, os.path.basename(image_path_in_json)),
                json_filepath.replace('.json', '.jpg'),
                json_filepath.replace('.json', '.png'),
                json_filepath.replace('.json', '.jpeg')
            ]

            for img_path in possible_image_paths:
                if os.path.exists(img_path):
                    try:
                        with Image.open(img_path) as img:
                            img_width, img_height = img.size
                        break
                    except:
                        continue

    # 如果仍然无法获取图像尺寸，使用默认值或报错
    if img_width is None or img_height is None:
        print(f"警告: 无法获取图像尺寸，使用默认值 1280x1024")
        img_width = 1280
        img_height = 1024

    # 准备写入TXT文件
    with open(output_txt_path, 'w') as txt_file:
        for shape in json_data.get('shapes', []):
            # 获取类别ID（尝试转换label为整数）
            try:
                class_id = int(shape['label'])
            except ValueError:
                # 如果label不是数字，可以根据需要添加映射逻辑
                print(f"警告: 类别标签 '{shape['label']}' 不是数字，跳过此标注")
                continue

            # 获取边界框的两个点并计算最小/最大坐标
            points = shape.get('points', [])
            if len(points) < 2:
                print(f"警告: 标注点数量不足，跳过此标注")
                continue

            # 对于矩形标注（两个点）
            if shape.get('shape_type', '') == 'rectangle' and len(points) == 2:
                x_coords = [p[0] for p in points]
                y_coords = [p[1] for p in points]
                x_min = min(x_coords)
                x_max = max(x_coords)
                y_min = min(y_coords)
                y_max = max(y_coords)
            else:
                # 对于多边形或其他类型的标注，计算边界框
                x_coords = [p[0] for p in points]
                y_coords = [p[1] for p in points]
                x_min = min(x_coords)
                x_max = max(x_coords)
                y_min = min(y_coords)
                y_max = max(y_coords)

            # 确保坐标在图像范围内
            x_min = max(0, min(x_min, img_width))
            x_max = max(0, min(x_max, img_width))
            y_min = max(0, min(y_min, img_height))
            y_max = max(0, min(y_max, img_height))

            # 计算边界框中心坐标和宽高
            box_width = x_max - x_min
            box_height = y_max - y_min

            # 防止宽度或高度为0
            if box_width <= 0 or box_height <= 0:
                print(f"警告: 无效的边界框尺寸，跳过此标注")
                continue

            x_center = x_min + box_width / 2
            y_center = y_min + box_height / 2

            # 坐标归一化（除以图像尺寸）
            x_center_norm = x_center / img_width
            y_center_norm = y_center / img_height
            width_norm = box_width / img_width
            height_norm = box_height / img_height

            # 确保归一化后的坐标在0-1范围内
            x_center_norm = max(0, min(1, x_center_norm))
            y_center_norm = max(0, min(1, y_center_norm))
            width_norm = max(0, min(1, width_norm))
            height_norm = max(0, min(1, height_norm))

            # 写入TXT文件（YOLO格式）
            txt_file.write(f"{class_id} {x_center_norm:.6f} {y_center_norm:.6f} {width_norm:.6f} {height_norm:.6f}\n")


def batch_convert_json_to_yolo(json_folder, output_folder):
    """
    批量将文件夹中的所有JSON文件转换为YOLO格式的TXT文件

    Args:
        json_folder (str): 包含JSON文件的文件夹路径
        output_folder (str): 输出TXT文件的文件夹路径
    """
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"创建输出文件夹: {output_folder}")

    # 获取所有JSON文件
    json_files = [f for f in os.listdir(json_folder) if f.lower().endswith('.json')]

    if not json_files:
        print(f"在文件夹 {json_folder} 中未找到JSON文件")
        return

    print(f"开始批量转换: 共找到 {len(json_files)} 个JSON文件")

    success_count = 0
    error_count = 0

    for json_file in json_files:
        try:
            # 构建完整的文件路径
            json_path = os.path.join(json_folder, json_file)

            # 读取JSON文件
            with open(json_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)

            # 生成对应的TXT文件名
            txt_filename = os.path.splitext(json_file)[0] + '.txt'
            txt_path = os.path.join(output_folder, txt_filename)

            # 转换JSON到YOLO TXT格式
            convert_json_to_yolo_txt(json_data, txt_path, json_path)

            success_count += 1
            print(f"✓ 成功转换: {json_file} -> {txt_filename}")

        except Exception as e:
            error_count += 1
            print(f"✗ 转换失败: {json_file} - 错误: {str(e)}")
            import traceback
            traceback.print_exc()

    print(f"\n转换完成!")
    print(f"成功: {success_count} 个文件")
    print(f"失败: {error_count} 个文件")
    print(f"输出目录: {output_folder}")


def batch_convert_with_class_mapping(json_folder, output_folder, class_mapping):
    """
    批量转换并支持类别名称映射

    Args:
        json_folder (str): 包含JSON文件的文件夹路径
        output_folder (str): 输出TXT文件的文件夹路径
        class_mapping (dict): 类别映射字典，如 {"garlic": 0, "head": 1, "tail": 2}
    """
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    json_files = [f for f in os.listdir(json_folder) if f.lower().endswith('.json')]

    if not json_files:
        print(f"在文件夹 {json_folder} 中未找到JSON文件")
        return

    print(f"开始批量转换（使用类别映射）: 共找到 {len(json_files)} 个JSON文件")

    success_count = 0
    error_count = 0

    for json_file in json_files:
        try:
            json_path = os.path.join(json_folder, json_file)

            with open(json_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)

            # 获取图像尺寸
            img_width = json_data.get('imageWidth')
            img_height = json_data.get('imageHeight')

            # 如果JSON中没有图像尺寸，尝试从图像文件获取
            if img_width is None or img_height is None:
                image_path_in_json = json_data.get('imagePath', '')
                json_dir = os.path.dirname(json_path)
                possible_image_paths = [
                    os.path.join(json_dir, image_path_in_json),
                    os.path.join(json_dir, os.path.basename(image_path_in_json)),
                    json_path.replace('.json', '.jpg'),
                    json_path.replace('.json', '.png'),
                    json_path.replace('.json', '.jpeg')
                ]

                for img_path in possible_image_paths:
                    if os.path.exists(img_path):
                        try:
                            with Image.open(img_path) as img:
                                img_width, img_height = img.size
                            break
                        except:
                            continue

            if img_width is None or img_height is None:
                print(f"警告: 无法获取图像尺寸，使用默认值 1280x1024")
                img_width = 1280
                img_height = 1024

            txt_filename = os.path.splitext(json_file)[0] + '.txt'
            txt_path = os.path.join(output_folder, txt_filename)

            with open(txt_path, 'w') as txt_file:
                for shape in json_data.get('shapes', []):
                    # 使用类别映射
                    label_name = shape['label']
                    if label_name in class_mapping:
                        class_id = class_mapping[label_name]
                    else:
                        # 如果label是数字，尝试直接使用
                        try:
                            class_id = int(label_name)
                        except ValueError:
                            print(f"警告: 未定义的类别 '{label_name}'，跳过此对象")
                            continue

                    points = shape.get('points', [])
                    if len(points) < 2:
                        continue

                    # 计算边界框
                    x_coords = [p[0] for p in points]
                    y_coords = [p[1] for p in points]
                    x_min = min(x_coords)
                    x_max = max(x_coords)
                    y_min = min(y_coords)
                    y_max = max(y_coords)

                    # 确保坐标在图像范围内
                    x_min = max(0, min(x_min, img_width))
                    x_max = max(0, min(x_max, img_width))
                    y_min = max(0, min(y_min, img_height))
                    y_max = max(0, min(y_max, img_height))

                    box_width = x_max - x_min
                    box_height = y_max - y_min

                    if box_width <= 0 or box_height <= 0:
                        continue

                    x_center = x_min + box_width / 2
                    y_center = y_min + box_height / 2

                    x_center_norm = x_center / img_width
                    y_center_norm = y_center / img_height
                    width_norm = box_width / img_width
                    height_norm = box_height / img_height

                    # 确保归一化后的坐标在0-1范围内
                    x_center_norm = max(0, min(1, x_center_norm))
                    y_center_norm = max(0, min(1, y_center_norm))
                    width_norm = max(0, min(1, width_norm))
                    height_norm = max(0, min(1, height_norm))

                    txt_file.write(
                        f"{class_id} {x_center_norm:.6f} {y_center_norm:.6f} {width_norm:.6f} {height_norm:.6f}\n")

            success_count += 1
            print(f"✓ 成功转换: {json_file} -> {txt_filename}")

        except Exception as e:
            error_count += 1
            print(f"✗ 转换失败: {json_file} - 错误: {str(e)}")

    print(f"\n转换完成!")
    print(f"成功: {success_count} 个文件")
    print(f"失败: {error_count} 个文件")
    print(f"输出目录: {output_folder}")


def create_yaml_file(output_path, class_names):
    """
    创建YOLO训练所需的YAML配置文件

    Args:
        output_path (str): YAML文件输出路径
        class_names (list): 类别名称列表
    """
    content = f"""# YOLO数据集配置文件
path: ../datasets/garlic  # 数据集根目录
train: images/train  # 训练集图像相对路径
val: images/val      # 验证集图像相对路径
test: images/test    # 测试集图像相对路径

# 类别数量
nc: {len(class_names)}

# 类别名称
names: {class_names}
"""

    with open(output_path, 'w') as f:
        f.write(content)

    print(f"已创建YAML配置文件: {output_path}")


# 使用示例
if __name__ == "__main__":
    # 方法1: 基本批量转换（使用label中的数字作为类别ID）
    json_folder = r"D:\大蒜数据集\garlic300"  # 替换为你的JSON文件夹路径
    output_folder = r"D:\大蒜数据集\garlic300\labels"  # 输出到labels文件夹

    # 确保图像文件存在
    print("检查图像文件...")
    image_extensions = ['.jpg', '.jpeg', '.png', '.bmp']
    json_files = [f for f in os.listdir(json_folder) if f.lower().endswith('.json')]

    for json_file in json_files:
        base_name = os.path.splitext(json_file)[0]
        image_found = False

        for ext in image_extensions:
            image_path = os.path.join(json_folder, base_name + ext)
            if os.path.exists(image_path):
                image_found = True
                break

        if not image_found:
            print(f"警告: 未找到 {base_name} 对应的图像文件")

    # 执行转换
    batch_convert_json_to_yolo(json_folder, output_folder)

    # 方法2: 使用类别名称映射的批量转换
    class_mapping = {
        "garlic": 0,  # 大蒜对应类别0
        "head": 1,  # 头对应类别1
        "tail": 2  # 尾巴对应类别2
    }

    # 如果你的JSON中label是类别名称而不是数字，使用这个方法
    # batch_convert_with_class_mapping(json_folder, output_folder, class_mapping)

    # 创建YAML配置文件
    class_names = ['garlic', 'head', 'tail']  # 根据你的实际类别修改
    yaml_path = os.path.join(json_folder, 'data.yaml')
    create_yaml_file(yaml_path, class_names)