import os
import xml.etree.cElementTree as ET
from xml.dom import minidom


def txt_to_xml(txt_folder, xml_folder, image_width=1280, image_height=1024, class_names=None):
    """
    将YOLO格式的txt标注批量转换为VOC格式的xml标注
    :param txt_folder: 存放txt标注的文件夹路径
    :param xml_folder: 保存xml标注的文件夹路径
    :param image_width: 图片宽度（固定1280）
    :param image_height: 图片高度（固定1024）
    :param class_names: 类别名称映射（键为类别ID，值为类别名），默认用数字作为类别名
    """
    # 默认类别名称（如果没指定，用类别ID作为名称）
    if class_names is None:
        class_names = {0: "U", 1: "D"}

    # 创建xml保存文件夹（如果不存在）
    if not os.path.exists(xml_folder):
        os.makedirs(xml_folder)

    # 遍历所有txt文件
    for txt_file in os.listdir(txt_folder):
        if not txt_file.endswith(".txt"):
            continue

        # 获取文件名（不含后缀）
        file_name = os.path.splitext(txt_file)[0]
        txt_path = os.path.join(txt_folder, txt_file)

        # 创建XML根节点
        root = ET.Element("annotation")

        # 添加基础信息
        ET.SubElement(root, "folder").text = "images"  # 可根据实际修改
        ET.SubElement(root, "filename").text = f"{file_name}.jpg"  # 假设图片是jpg格式，可修改
        ET.SubElement(root, "path").text = os.path.join("images", f"{file_name}.jpg")  # 可根据实际修改

        # 添加图片尺寸信息
        size = ET.SubElement(root, "size")
        ET.SubElement(size, "width").text = str(image_width)
        ET.SubElement(size, "height").text = str(image_height)
        ET.SubElement(size, "depth").text = "3"  # 彩色图片为3通道

        ET.SubElement(root, "segmented").text = "0"  # 非分割标注

        # 读取txt标注内容并转换
        with open(txt_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # 解析YOLO格式：类别ID 中心点x 中心点y 宽度 高度（均为归一化值）
            parts = line.split()
            if len(parts) != 5:
                print(f"警告：{txt_file} 中该行格式错误，跳过：{line}")
                continue

            class_id = int(parts[0])
            cx = float(parts[1])
            cy = float(parts[2])
            w = float(parts[3])
            h = float(parts[4])

            # 转换为VOC格式（像素坐标，左上角xmin/ymin，右下角xmax/ymax）
            xmin = int((cx - w / 2) * image_width)
            ymin = int((cy - h / 2) * image_height)
            xmax = int((cx + w / 2) * image_width)
            ymax = int((cy + h / 2) * image_height)

            # 防止坐标超出图片范围
            xmin = max(0, xmin)
            ymin = max(0, ymin)
            xmax = min(image_width - 1, xmax)
            ymax = min(image_height - 1, ymax)

            # 添加目标标注
            obj = ET.SubElement(root, "object")
            ET.SubElement(obj, "name").text = class_names.get(class_id, f"class_{class_id}")
            ET.SubElement(obj, "pose").text = "Unspecified"
            ET.SubElement(obj, "truncated").text = "0"
            ET.SubElement(obj, "difficult").text = "0"

            # 添加边界框
            bndbox = ET.SubElement(obj, "bndbox")
            ET.SubElement(bndbox, "xmin").text = str(xmin)
            ET.SubElement(bndbox, "ymin").text = str(ymin)
            ET.SubElement(bndbox, "xmax").text = str(xmax)
            ET.SubElement(bndbox, "ymax").text = str(ymax)

        # 格式化XML（缩进4个空格，更易读）
        xml_str = minidom.parseString(ET.tostring(root)).toprettyxml(indent="    ")
        # 去除多余的空行
        xml_str = "\n".join([line for line in xml_str.split("\n") if line.strip()])

        # 保存XML文件
        xml_path = os.path.join(xml_folder, f"{file_name}.xml")
        with open(xml_path, "w", encoding="utf-8") as f:
            f.write(xml_str)

        print(f"已转换：{txt_file} -> {file_name}.xml")

    print(f"\n转换完成！共处理 {len([f for f in os.listdir(txt_folder) if f.endswith('.txt')])} 个文件")


# ==================== 配置参数（修改这里！）====================
if __name__ == "__main__":
    # 1. 你的txt标注文件夹路径
    TXT_FOLDER = r"C:\Users\30855\Desktop\大蒜-抄论文方案\maixhub\train\xml"
    # 2. 生成的xml保存路径
    XML_FOLDER = r"C:\Users\30855\Desktop\大蒜-抄论文方案\maixhub\train\xml"
    # 3. 类别名称映射（根据你的实际类别修改！）
    # 例如：{0: "大蒜", 1: "蒜瓣"}
    CLASS_NAMES = {
        0: "U",
        1: "D"
    }

    # 执行转换
    txt_to_xml(
        txt_folder=TXT_FOLDER,
        xml_folder=XML_FOLDER,
        image_width=1280,
        image_height=1024,
        class_names=CLASS_NAMES
    )
