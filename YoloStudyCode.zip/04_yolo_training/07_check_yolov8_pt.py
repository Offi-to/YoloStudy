import cv2
import numpy as np
import matplotlib.pyplot as plt
from ultralytics import YOLO
import os
import glob
import time
import torch
from PIL import Image
import json


class YOLOv8ModelHealthChecker:
    """YOLOv8 PT模型健康检查工具"""

    def __init__(self, model_path, test_images_dir=None):
        self.model_path = model_path
        self.test_images_dir = test_images_dir
        self.model = None
        self.health_report = {
            'model_info': {},
            'performance_metrics': {},
            'detection_quality': {},
            'issues_found': [],
            'recommendations': []
        }

    def load_and_validate_model(self):
        """加载并验证模型基础信息"""
        print("🔍 步骤1: 加载并验证模型基础信息")
        print("-" * 50)

        # 检查模型文件是否存在
        if not os.path.exists(self.model_path):
            error_msg = f"❌ 模型文件不存在: {self.model_path}"
            self.health_report['issues_found'].append(error_msg)
            print(error_msg)
            return False

        print(f"✅ 模型文件存在: {os.path.basename(self.model_path)}")
        print(f"📁 文件大小: {os.path.getsize(self.model_path) / (1024 * 1024):.2f} MB")

        try:
            # 加载模型
            self.model = YOLO(self.model_path)
            print("✅ 模型加载成功!")

            # 获取模型信息
            self.health_report['model_info'] = {
                'model_path': self.model_path,
                'class_names': self.model.names if hasattr(self.model, 'names') else {},
                'num_classes': len(self.model.names) if hasattr(self.model, 'names') else 0,
                'device': next(self.model.parameters()).device if hasattr(self.model, 'parameters') else 'unknown'
            }

            print(f"📊 类别数量: {self.health_report['model_info']['num_classes']}")
            print(f"🏷️ 类别名称: {self.health_report['model_info']['class_names']}")
            print(f"⚙️ 运行设备: {self.health_report['model_info']['device']}")

            return True

        except Exception as e:
            error_msg = f"❌ 模型加载失败: {e}"
            self.health_report['issues_found'].append(error_msg)
            print(error_msg)
            return False

    def test_model_structure(self):
        """测试模型结构完整性"""
        print("\n🔍 步骤2: 测试模型结构完整性")
        print("-" * 50)

        try:
            # 创建测试输入
            test_input = torch.randn(1, 3, 640, 640).to(self.health_report['model_info']['device'])
            print(f"✅ 测试输入形状: {test_input.shape}")

            # 前向传播测试
            with torch.no_grad():
                results = self.model(test_input)

            # 检查输出结构
            if hasattr(results, 'boxes') or (isinstance(results, list) and len(results) > 0):
                print("✅ 模型前向传播测试通过")

                # 分析输出形状
                if hasattr(results[0], 'boxes'):
                    num_detections = len(results[0].boxes)
                    print(f"✅ 检测框数量: {num_detections}")

                    if num_detections > 0:
                        # 检查第一个检测框的完整性
                        box = results[0].boxes[0]
                        required_attrs = ['xyxy', 'conf', 'cls']
                        missing_attrs = [attr for attr in required_attrs if not hasattr(box, attr)]

                        if not missing_attrs:
                            print("✅ 检测框属性完整")
                        else:
                            warning_msg = f"⚠️ 缺失检测框属性: {missing_attrs}"
                            self.health_report['issues_found'].append(warning_msg)
                            print(warning_msg)

                return True
            else:
                warning_msg = "⚠️ 模型输出结构异常"
                self.health_report['issues_found'].append(warning_msg)
                print(warning_msg)
                return False

        except Exception as e:
            error_msg = f"❌ 模型结构测试失败: {e}"
            self.health_report['issues_found'].append(error_msg)
            print(error_msg)
            return False

    def performance_benchmark(self, num_iterations=10):
        """性能基准测试"""
        print("\n🔍 步骤3: 性能基准测试")
        print("-" * 50)

        try:
            # 准备测试数据
            test_data = torch.randn(num_iterations, 3, 640, 640).to(
                self.health_report['model_info']['device']
            )

            # 预热
            print("🔥 预热运行...")
            with torch.no_grad():
                _ = self.model(test_data[0:1])

            # 正式测试
            print("⏱️ 开始性能测试...")
            start_time = time.time()

            with torch.no_grad():
                for i in range(num_iterations):
                    _ = self.model(test_data[i:i + 1])

            end_time = time.time()

            # 计算指标
            total_time = end_time - start_time
            avg_inference_time = total_time / num_iterations * 1000  # 转换为毫秒
            fps = 1000 / avg_inference_time

            self.health_report['performance_metrics'] = {
                'avg_inference_time_ms': avg_inference_time,
                'fps': fps,
                'total_test_time': total_time,
                'num_iterations': num_iterations
            }

            print(f"✅ 平均推理时间: {avg_inference_time:.2f} ms")
            print(f"✅ 推理速度: {fps:.2f} FPS")
            print(f"✅ 总测试时间: {total_time:.2f} 秒")

            # 性能评估
            if avg_inference_time < 50:
                print("🎯 性能表现: 优秀")
            elif avg_inference_time < 100:
                print("✅ 性能表现: 良好")
            else:
                print("⚠️ 性能表现: 待优化")

            return True

        except Exception as e:
            error_msg = f"❌ 性能测试失败: {e}"
            self.health_report['issues_found'].append(error_msg)
            print(error_msg)
            return False

    def detection_quality_analysis(self, test_image_path=None):
        """检测质量分析"""
        print("\n🔍 步骤4: 检测质量分析")
        print("-" * 50)

        if not test_image_path and self.test_images_dir:
            # 查找测试目录中的图像
            image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp']
            test_images = []

            for ext in image_extensions:
                test_images.extend(glob.glob(os.path.join(self.test_images_dir, ext)))

            if test_images:
                test_image_path = test_images[0]

        if not test_image_path or not os.path.exists(test_image_path):
            print("⚠️ 未找到测试图像，跳过检测质量分析")
            return False

        print(f"🖼️ 使用测试图像: {os.path.basename(test_image_path)}")

        try:
            # 进行检测
            results = self.model(test_image_path, conf=0.25)

            if len(results) == 0:
                print("❌ 未检测到任何目标")
                self.health_report['issues_found'].append("在测试图像上未检测到任何目标")
                return False

            result = results[0]

            # 分析检测结果
            num_detections = len(result.boxes)
            confidences = []
            class_distribution = {}

            if num_detections > 0:
                for box in result.boxes:
                    conf = box.conf.item()
                    cls_id = int(box.cls.item())
                    class_name = self.health_report['model_info']['class_names'].get(cls_id, f'class_{cls_id}')

                    confidences.append(conf)
                    class_distribution[class_name] = class_distribution.get(class_name, 0) + 1

                # 计算统计指标
                avg_confidence = np.mean(confidences)
                max_confidence = np.max(confidences)
                min_confidence = np.min(confidences)

                self.health_report['detection_quality'] = {
                    'num_detections': num_detections,
                    'avg_confidence': avg_confidence,
                    'max_confidence': max_confidence,
                    'min_confidence': min_confidence,
                    'class_distribution': class_distribution
                }

                print(f"✅ 检测到目标数量: {num_detections}")
                print(f"📊 平均置信度: {avg_confidence:.3f}")
                print(f"📈 最高置信度: {max_confidence:.3f}")
                print(f"📉 最低置信度: {min_confidence:.3f}")
                print(f"📋 类别分布: {class_distribution}")

                # 质量评估
                if avg_confidence > 0.7:
                    print("🎯 检测质量: 优秀")
                elif avg_confidence > 0.5:
                    print("✅ 检测质量: 良好")
                elif avg_confidence > 0.3:
                    print("⚠️ 检测质量: 一般")
                else:
                    print("❌ 检测质量: 较差")
                    self.health_report['issues_found'].append("检测置信度过低")

                # 可视化结果
                self.visualize_detection_results(result, test_image_path)
                return True
            else:
                print("❌ 未检测到有效目标")
                self.health_report['issues_found'].append("未检测到有效目标")
                return False

        except Exception as e:
            error_msg = f"❌ 检测质量分析失败: {e}"
            self.health_report['issues_found'].append(error_msg)
            print(error_msg)
            return False

    def visualize_detection_results(self, result, image_path):
        """可视化检测结果"""
        try:
            # 创建可视化图像
            plotted_image = result.plot()

            # 显示结果
            plt.figure(figsize=(15, 6))

            # 原始图像
            original_image = cv2.imread(image_path)
            original_image_rgb = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)

            plt.subplot(1, 2, 1)
            plt.imshow(original_image_rgb)
            plt.title('原始图像', fontsize=12, fontweight='bold')
            plt.axis('off')

            # 检测结果
            plt.subplot(1, 2, 2)
            plotted_image_rgb = cv2.cvtColor(plotted_image, cv2.COLOR_BGR2RGB)
            plt.imshow(plotted_image_rgb)
            plt.title('检测结果', fontsize=12, fontweight='bold')
            plt.axis('off')

            plt.tight_layout()
            plt.savefig('health_check_detection.jpg', dpi=150, bbox_inches='tight')
            plt.show()

            print("✅ 检测结果可视化已保存为: health_check_detection.jpg")

        except Exception as e:
            print(f"⚠️ 可视化失败: {e}")

    def check_for_common_issues(self):
        """检查常见问题"""
        print("\n🔍 步骤5: 常见问题检查")
        print("-" * 50)

        issues_found = []

        # 检查类别数量
        if self.health_report['model_info']['num_classes'] == 0:
            issues_found.append("模型类别数量为0，可能训练有问题")

        # 检查设备
        device = self.health_report['model_info']['device']
        if 'cuda' not in str(device):
            issues_found.append("模型未使用GPU，可能影响推理速度")

        # 检查性能
        perf_metrics = self.health_report.get('performance_metrics', {})
        if perf_metrics.get('avg_inference_time_ms', 1000) > 200:
            issues_found.append("推理速度较慢，建议优化")

        # 检查检测质量
        det_quality = self.health_report.get('detection_quality', {})
        if det_quality.get('avg_confidence', 0) < 0.3:
            issues_found.append("检测置信度过低，可能需要重新训练")

        if issues_found:
            self.health_report['issues_found'].extend(issues_found)
            for issue in issues_found:
                print(f"❌ {issue}")
        else:
            print("✅ 未发现常见问题")

    def generate_recommendations(self):
        """生成改进建议"""
        print("\n💡 改进建议")
        print("-" * 50)

        recommendations = []

        # 基于性能的建议
        perf_metrics = self.health_report.get('performance_metrics', {})
        if perf_metrics.get('avg_inference_time_ms', 1000) > 100:
            recommendations.append("考虑使用更小的YOLOv8模型版本（如yolov8n）")
            recommendations.append("启用半精度（FP16）推理以加速")

        # 基于检测质量的建议
        det_quality = self.health_report.get('detection_quality', {})
        if det_quality.get('avg_confidence', 0) < 0.5:
            recommendations.append("考虑增加训练数据或数据增强")
            recommendations.append("调整训练超参数，如学习率")

        # 通用建议
        if not recommendations:
            recommendations.append("模型状态良好，继续保持当前配置")

        self.health_report['recommendations'] = recommendations

        for i, rec in enumerate(recommendations, 1):
            print(f"{i}. {rec}")

    def save_health_report(self):
        """保存健康检查报告"""
        report_file = 'yolov8_model_health_report.json'

        # 转换为可JSON序列化的格式
        serializable_report = {}
        for key, value in self.health_report.items():
            if isinstance(value, (np.integer, np.floating)):
                serializable_report[key] = float(value)
            elif isinstance(value, (np.ndarray, torch.device)):
                serializable_report[key] = str(value)
            else:
                serializable_report[key] = value

        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(serializable_report, f, indent=2, ensure_ascii=False)

        print(f"\n📊 健康检查报告已保存为: {report_file}")

    def run_comprehensive_check(self, test_image_path=None):
        """运行全面健康检查"""
        print("=" * 60)
        print("🧠 YOLOv8 PT模型全面健康检查")
        print("=" * 60)

        # 执行所有检查步骤
        checks = [
            self.load_and_validate_model,
            self.test_model_structure,
            lambda: self.performance_benchmark(10),
            lambda: self.detection_quality_analysis(test_image_path),
            self.check_for_common_issues,
            self.generate_recommendations
        ]

        passed_checks = 0
        total_checks = len(checks)

        for check_func in checks:
            try:
                if check_func():
                    passed_checks += 1
            except Exception as e:
                print(f"❌ 检查过程中出错: {e}")

        # 生成总体评估
        print("\n" + "=" * 60)
        print("📈 总体评估结果")
        print("=" * 60)

        success_rate = (passed_checks / total_checks) * 100
        print(f"✅ 通过检查: {passed_checks}/{total_checks} ({success_rate:.1f}%)")

        if success_rate >= 80:
            print("🎉 模型健康状况: 优秀")
        elif success_rate >= 60:
            print("✅ 模型健康状况: 良好")
        elif success_rate >= 40:
            print("⚠️ 模型健康状况: 一般")
        else:
            print("❌ 模型健康状况: 较差")

        # 保存报告
        self.save_health_report()

        return self.health_report


def main():
    """主函数"""
    # 配置参数 - 请根据您的实际情况修改
    MODEL_PATH = r"C:\Users\30855\Desktop\trainer\runs\detect\train3\weights\best.pt"  # 您的模型路径
    TEST_IMAGE_PATH = r"C:\Users\30855\Desktop\frame1_00113.jpg"  # 测试图像路径
    TEST_IMAGES_DIR = r"C:\Users\30855\Desktop\trainer\images\test"  # 测试图像目录（可选）

    # 创建健康检查器
    health_checker = YOLOv8ModelHealthChecker(MODEL_PATH, TEST_IMAGES_DIR)

    # 运行全面检查
    health_report = health_checker.run_comprehensive_check(TEST_IMAGE_PATH)

    print("\n" + "=" * 60)
    print("健康检查完成！详细报告已保存为JSON文件。")
    print("=" * 60)


if __name__ == "__main__":
    main()