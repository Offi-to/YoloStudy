import torch
import numpy as np
import cv2
import os
import matplotlib.pyplot as plt


def sigmoid(x):
    """Sigmoid函数"""
    return 1 / (1 + np.exp(-x))


def load_yolov5_model(model_path):
    """加载YOLOv5模型"""
    try:
        model = torch.load(model_path, map_location='cpu')
        print("模型加载成功!")
        return model
    except Exception as e:
        print(f"加载模型失败: {e}")
        return None


def diagnose_model_health(model):
    """诊断模型健康状况"""
    print("\n=== 模型健康诊断 ===")

    # 提取模型部分
    if hasattr(model, 'model'):
        yolov5_model = model.model
    elif isinstance(model, dict) and 'model' in model:
        yolov5_model = model['model']
    else:
        yolov5_model = model

    # 转换为float32
    first_param = next(yolov5_model.parameters())
    if first_param.dtype == torch.float16:
        yolov5_model = yolov5_model.float()

    yolov5_model.eval()

    # 检查模型权重统计
    print("模型权重统计:")
    all_weights = []
    for name, param in yolov5_model.named_parameters():
        if param.requires_grad:
            param_data = param.data.cpu().numpy()
            all_weights.extend(param_data.flatten())

    all_weights = np.array(all_weights)
    print(f"权重数量: {len(all_weights):,}")
    print(f"权重范围: [{all_weights.min():.6f}, {all_weights.max():.6f}]")
    print(f"权重平均值: {all_weights.mean():.6f}")
    print(f"权重标准差: {all_weights.std():.6f}")

    # 检查异常权重
    large_weights = all_weights[np.abs(all_weights) > 10]
    if len(large_weights) > 0:
        print(f"⚠️ 发现 {len(large_weights)} 个异常大权重(>10)")
        print(f"最大权重值: {large_weights.max():.6f}")

    return yolov5_model


def test_model_with_simple_input(model):
    """使用简单输入测试模型"""
    print("\n=== 简单输入测试 ===")

    # 测试1: 全零输入
    print("测试1: 全零输入")
    zeros_input = torch.zeros(1, 3, 640, 640).float()
    with torch.no_grad():
        output = model(zeros_input)

    analyze_output_values(output, "全零输入")

    # 测试2: 全一输入
    print("\n测试2: 全一输入")
    ones_input = torch.ones(1, 3, 640, 640).float()
    with torch.no_grad():
        output = model(ones_input)

    analyze_output_values(output, "全一输入")

    # 测试3: 随机输入
    print("\n测试3: 随机输入")
    random_input = torch.randn(1, 3, 640, 640).float()
    with torch.no_grad():
        output = model(random_input)

    analyze_output_values(output, "随机输入")


def analyze_output_values(output, test_name):
    """分析输出值"""
    print(f"{test_name}输出分析:")

    if isinstance(output, (list, tuple)):
        for i, scale_out in enumerate(output):
            if scale_out is not None:
                out_np = scale_out.detach().cpu().numpy()
                print(f"  尺度{i}: 形状{out_np.shape}, 范围[{out_np.min():.6f}, {out_np.max():.6f}]")

                # 检查前几个检测框
                if len(out_np.shape) == 3:
                    batch_out = out_np[0]
                    if batch_out.shape[0] > 0:
                        print("    前3个检测框的原始值:")
                        for j in range(min(3, batch_out.shape[0])):
                            features = batch_out[j]
                            print(f"      框{j}: {features[:6]}")

                            # 检查是否数值过大
                            if np.any(np.abs(features[:4]) > 10):  # 检查坐标
                                print("      ⚠️ 坐标值异常大!")
                            if np.any(np.abs(features[4:]) > 10):  # 检查置信度
                                print("      ⚠️ 置信度值异常大!")


def check_training_artifacts(model_path):
    """检查训练过程文件"""
    print("\n=== 检查训练过程 ===")

    model_dir = os.path.dirname(model_path)

    # 检查训练日志
    log_files = []
    for file in os.listdir(model_dir):
        if file.endswith('.log') or 'train' in file.lower():
            log_files.append(os.path.join(model_dir, file))

    if log_files:
        print("找到训练日志文件:")
        for log_file in log_files:
            print(f"  {log_file}")
    else:
        print("未找到训练日志文件")

    # 检查是否有其他模型文件
    model_files = []
    for file in os.listdir(model_dir):
        if file.endswith('.pt'):
            model_files.append(os.path.join(model_dir, file))

    if len(model_files) > 1:
        print(f"找到 {len(model_files)} 个模型文件:")
        for model_file in model_files:
            file_size = os.path.getsize(model_file) / 1024 / 1024  # MB
            print(f"  {model_file} ({file_size:.2f} MB)")


def test_model_with_actual_detection(model, image_path):
    """使用实际图像测试检测能力"""
    print("\n=== 实际图像检测测试 ===")

    if not os.path.exists(image_path):
        print(f"图像文件不存在: {image_path}")
        return

    # 加载图像
    img = cv2.imread(image_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # 预处理
    img_resized = cv2.resize(img_rgb, (640, 640))
    img_normalized = img_resized.astype(np.float32) / 255.0
    img_chw = np.transpose(img_normalized, (2, 0, 1))
    img_batch = np.expand_dims(img_chw, axis=0)
    img_tensor = torch.from_numpy(img_batch).float()

    # 推理
    with torch.no_grad():
        output = model(img_tensor)

    # 分析输出
    print("实际图像检测结果:")
    if isinstance(output, (list, tuple)):
        total_detections = 0
        for i, scale_out in enumerate(output):
            if scale_out is not None:
                out_np = scale_out.detach().cpu().numpy()
                if len(out_np.shape) == 3:
                    batch_out = out_np[0]

                    # 统计高置信度检测
                    high_conf_count = 0
                    for j in range(batch_out.shape[0]):
                        features = batch_out[j]
                        if len(features) >= 6:
                            # 应用sigmoid
                            cx = sigmoid(features[0])
                            cy = sigmoid(features[1])
                            conf = sigmoid(features[4])

                            # 检查是否在合理范围内
                            if 0 <= cx <= 1 and 0 <= cy <= 1 and conf > 0.25:
                                high_conf_count += 1

                    print(f"  尺度{i}: {batch_out.shape[0]} 个检测框, {high_conf_count} 个高置信度检测")
                    total_detections += high_conf_count

        if total_detections == 0:
            print("❌ 没有检测到任何对象")
        else:
            print(f"✅ 检测到 {total_detections} 个对象")


def main():
    pt_model_path = r"C:\Users\30855\Desktop\buff2026.2.15\runs\pose\Offi_energy_pose_v1\weights\best.pt"
    test_image_path = r"C:\Users\30855\Desktop"

    print("=== YOLOv5模型深度诊断 ===")

    if not os.path.exists(pt_model_path):
        print(f"模型文件不存在: {pt_model_path}")
        return

    # 加载模型
    model = load_yolov5_model(pt_model_path)
    if model is None:
        return

    # 1. 诊断模型健康状态
    yolov5_model = diagnose_model_health(model)

    # 2. 使用简单输入测试
    test_model_with_simple_input(yolov5_model)

    # 3. 检查训练过程
    check_training_artifacts(pt_model_path)

    # 4. 实际图像测试
    if os.path.exists(test_image_path):
        test_model_with_actual_detection(yolov5_model, test_image_path)

    # 5. 给出结论和建议
    print("\n" + "=" * 50)
    print("诊断结论:")
    print("❌ 模型存在问题！")
    print("\n问题分析:")
    print("1. 模型权重值异常大，可能是训练过程中梯度爆炸")
    print("2. 输出值过大，导致sigmoid函数输出为1.0")
    print("3. 模型没有正确学习检测任务")

    print("\n建议解决方案:")
    print("1. 重新训练模型，使用更小的学习率")
    print("2. 添加梯度裁剪(gradient clipping)")
    print("3. 检查训练数据和标注质量")
    print("4. 验证模型配置是否正确")
    print("5. 尝试使用预训练权重进行微调")


if __name__ == "__main__":
    main()