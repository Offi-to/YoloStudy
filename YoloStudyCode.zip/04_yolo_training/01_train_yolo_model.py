from ultralytics import YOLO

'''
# Load a model
model = YOLO('yolov8n.yaml')  # 从YAML中构建一个新模型
model = YOLO('yolov8n.pt')  #加载预训练的模型(推荐用于训练)
model = YOLO('yolov8n.yaml').load('yolov8n.pt')  # 从YAML构建并传递权重

# Train the model
model.train(data='coco128.yaml', epochs=100, imgsz=640)


统一格式
yolo TASK MODE ARGS


# 2. 指定训练参数
# 使用你的 YAML 文件进行训练
model.train(
    data='E:\RM_DATAS\Offi_Data\Data1\data.yaml',  # 数据集配置文件路径
    epochs=100,                                    # 训练轮数
    imgsz=640,                                     # 图像大小
    device=0                                       # 使用 GPU（若设备编号为0）
)
'''


if __name__ == '__main__':
    # 加载预训练模型(推荐方式)
    model = YOLO('yolov8n.pt')

    # 训练模型
    model.train(
        data='E:/RM_DATAS/Offi_Data/Data1/test.yaml',
        epochs=100,
        imgsz=640,
        workers=0 #作为临时解决方案
        # workers=0
    )
