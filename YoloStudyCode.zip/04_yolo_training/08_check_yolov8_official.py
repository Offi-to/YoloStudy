from ultralytics import YOLO
import cv2

# 直接使用YOLO加载ONNX模型
model = YOLO(r"C:\Users\30855\Desktop\trainer\garlic_identify3.onnx")

# 进行推理
results = model(r"C:\\Users\\30855\\Desktop\\frame1_00113.jpg")

# 显示结果
for r in results:
    print(f"检测到 {len(r.boxes)} 个目标")
    if len(r.boxes) > 0:
        for box in r.boxes:
            print(f"类别: {model.names[int(box.cls)]}, 置信度: {box.conf.item():.3f}")