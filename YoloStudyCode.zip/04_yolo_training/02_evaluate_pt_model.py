from ultralytics.yolo.utils.benchmarks import benchmark

# Benchmark
benchmark(model='yolov8n.pt', imgsz=640, half=False, device=0)
