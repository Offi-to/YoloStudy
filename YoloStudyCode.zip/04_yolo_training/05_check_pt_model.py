import torch
import numpy as np
import cv2
import os
import matplotlib.pyplot as plt


def sigmoid(x):
    """Sigmoid函数"""
    return 1 / (1 + np.exp(-x))


def load_yolov5_model(model_path):
    """
    加载YOLOv5 PyTorch模型
    """
    try:
        print(f"尝试加载模型: {model_path}")
        model = torch.load(model_path, map_location='cpu')
        print("模型加载成功!")
        return model
    except Exception as e:
        print(f"加载模型失败: {e}")
        return None


def fix_model_dtype(model):
    """
    修复模型数据类型问题
    """
    print("\n=== 修复模型数据类型 ===")

    # 提取模型部分
    if hasattr(model, 'model'):
        yolov5_model = model.model
    elif isinstance(model, dict) and 'model' in model:
        yolov5_model = model['model']
    else:
        yolov5_model = model

    # 检查模型参数的数据类型
    first_param = next(yolov5_model.parameters())
    print(f"模型参数数据类型: {first_param.dtype}")

    # 将模型转换为float32
    if first_param.dtype == torch.float16:
        print("将模型从float16转换为float32")
        yolov5_model = yolov5_model.float()
    else:
        print("模型已经是float32格式")

    # 设置模型为评估模式
    yolov5_model.eval()

    return yolov5_model


def correct_yolov5_output_parsing(output):
    """
    正确解析YOLOv5输出
    """
    print("\n=== 正确解析YOLOv5输出 ===")

    # YOLOv5输出通常是包含多个检测尺度的元组
    if isinstance(output, (list, tuple)):
        print(f"输出包含 {len(output)} 个检测尺度")

        all_detections = []

        for i, scale_output in enumerate(output):
            if scale_output is not None:
                # 处理张量或列表
                if isinstance(scale_output, torch.Tensor):
                    scale_data = scale_output.detach().cpu().numpy()
                elif isinstance(scale_output, list):
                    # 如果是列表，转换为numpy数组
                    scale_data = np.array(scale_output)
                else:
                    print(f"尺度 {i} 的未知类型: {type(scale_output)}")
                    continue

                print(f"尺度 {i} 形状: {scale_data.shape}")

                # 处理不同形状的输出
                if len(scale_data.shape) == 3:  # [batch, num_detections, features]
                    batch_data = scale_data[0]  # 取第一个批次
                    print(f"  检测框数量: {batch_data.shape[0]}")
                    print(f"  特征数量: {batch_data.shape[1]}")

                    # 解析每个检测框
                    for j in range(min(5, batch_data.shape[0])):  # 只显示前5个
                        features = batch_data[j]
                        print(f"    框{j} 原始特征: {features[:6]}")  # 显示前6个特征

                        # 应用sigmoid到坐标和置信度
                        if len(features) >= 6:
                            # 假设格式: [cx, cy, w, h, obj_conf, class_conf...]
                            cx, cy, w, h = features[0], features[1], features[2], features[3]
                            obj_conf = features[4]
                            class_conf = features[5] if len(features) > 5 else 0

                            # 应用sigmoid
                            cx_sigmoid = sigmoid(cx)
                            cy_sigmoid = sigmoid(cy)
                            w_sigmoid = sigmoid(w)
                            h_sigmoid = sigmoid(h)
                            obj_conf_sigmoid = sigmoid(obj_conf)
                            class_conf_sigmoid = sigmoid(class_conf)

                            # 计算最终置信度
                            final_conf = obj_conf_sigmoid * class_conf_sigmoid

                            print(f"      处理后 - cx:{cx_sigmoid:.4f}, cy:{cy_sigmoid:.4f}, "
                                  f"w:{w_sigmoid:.4f}, h:{h_sigmoid:.4f}, "
                                  f"obj_conf:{obj_conf_sigmoid:.4f}, "
                                  f"class_conf:{class_conf_sigmoid:.4f}, "
                                  f"final_conf:{final_conf:.4f}")

                    all_detections.append(batch_data)

        return all_detections
    else:
        print(f"未知输出类型: {type(output)}")
        return []


def analyze_detailed_output(output):
    """
    详细分析模型输出
    """
    print("\n=== 详细输出分析 ===")

    # 正确解析输出
    detections = correct_yolov5_output_parsing(output)

    if not detections:
        print("没有有效的检测结果")
        return

    # 统计所有检测框
    all_boxes = []
    for i, detection in enumerate(detections):
        all_boxes.extend(detection)

    print(f"\n总共检测框数量: {len(all_boxes)}")

    # 统计高置信度检测框
    high_conf_boxes = []
    for box in all_boxes:
        if len(box) >= 6:
            # 应用sigmoid到置信度
            obj_conf = sigmoid(box[4])
            class_conf = sigmoid(box[5]) if len(box) > 5 else 0
            final_conf = obj_conf * class_conf

            if final_conf > 0.25:  # 您的阈值
                high_conf_boxes.append({
                    'cx': sigmoid(box[0]),
                    'cy': sigmoid(box[1]),
                    'w': sigmoid(box[2]),
                    'h': sigmoid(box[3]),
                    'obj_conf': obj_conf,
                    'class_conf': class_conf,
                    'final_conf': final_conf,
                    'class_id': 0 if class_conf > 0.5 else 1  # 简单分类
                })

    print(f"高置信度检测框数量(>0.25): {len(high_conf_boxes)}")

    if high_conf_boxes:
        print("\n高置信度检测框详细信息:")
        for i, box in enumerate(high_conf_boxes[:5]):  # 只显示前5个
            print(f"  框{i}: cx={box['cx']:.4f}, cy={box['cy']:.4f}, "
                  f"w={box['w']:.4f}, h={box['h']:.4f}, "
                  f"obj_conf={box['obj_conf']:.4f}, class_conf={box['class_conf']:.4f}, "
                  f"final_conf={box['final_conf']:.4f}, class={box['class_id']}")


def test_with_actual_image(model, image_path):
    """
    使用实际图像测试模型
    """
    print("\n=== 使用实际图像测试 ===")

    if not os.path.exists(image_path):
        print(f"图像文件不存在: {image_path}")
        return

    # 加载图像
    img = cv2.imread(image_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    print(f"加载图像: {image_path}, 大小: {img.shape}")

    # 预处理图像
    img_resized = cv2.resize(img_rgb, (640, 640))
    img_normalized = img_resized.astype(np.float32) / 255.0
    img_chw = np.transpose(img_normalized, (2, 0, 1))
    img_batch = np.expand_dims(img_chw, axis=0)
    img_tensor = torch.from_numpy(img_batch).float()

    print(f"输入张量形状: {img_tensor.shape}")

    # 推理
    with torch.no_grad():
        output = model(img_tensor)

    # 分析输出
    analyze_detailed_output(output)

    # 可视化结果
    visualize_detections_with_sigmoid(output, img_rgb)

    return output


def visualize_detections_with_sigmoid(output, original_img, confidence_threshold=0.25):
    """
    使用sigmoid处理后的可视化
    """
    print("\n=== 可视化检测结果（应用sigmoid后） ===")

    # 创建图像副本用于绘制
    img_draw = original_img.copy()
    original_h, original_w = original_img.shape[:2]

    # 解析输出
    detections = correct_yolov5_output_parsing(output)

    if not detections:
        print("没有检测结果可可视化")
        return

    # 收集所有高置信度检测框
    high_conf_boxes = []
    for detection_scale in detections:
        for box in detection_scale:
            if len(box) >= 6:
                # 应用sigmoid
                cx = sigmoid(box[0])
                cy = sigmoid(box[1])
                w = sigmoid(box[2])
                h = sigmoid(box[3])
                obj_conf = sigmoid(box[4])
                class_conf = sigmoid(box[5]) if len(box) > 5 else 0
                final_conf = obj_conf * class_conf

                if final_conf > confidence_threshold:
                    high_conf_boxes.append({
                        'cx': cx, 'cy': cy, 'w': w, 'h': h,
                        'confidence': final_conf,
                        'class_id': 0 if class_conf > 0.5 else 1
                    })

    print(f"找到 {len(high_conf_boxes)} 个高置信度检测框")

    # 绘制检测框
    for i, box in enumerate(high_conf_boxes):
        # 转换为像素坐标
        x_center = box['cx'] * original_w
        y_center = box['cy'] * original_h
        box_width = box['w'] * original_w
        box_height = box['h'] * original_h

        x1 = int(x_center - box_width / 2)
        y1 = int(y_center - box_height / 2)
        x2 = int(x_center + box_width / 2)
        y2 = int(y_center + box_height / 2)

        # 确保坐标在图像范围内
        x1 = max(0, min(x1, original_w - 1))
        y1 = max(0, min(y1, original_h - 1))
        x2 = max(0, min(x2, original_w - 1))
        y2 = max(0, min(y2, original_h - 1))

        # 选择颜色
        color = (0, 255, 0) if box['class_id'] == 0 else (255, 0, 0)  # garlic: 绿色, head: 红色

        # 绘制边界框
        cv2.rectangle(img_draw, (x1, y1), (x2, y2), color, 2)

        # 绘制标签
        label = f"{'garlic' if box['class_id'] == 0 else 'head'}: {box['confidence']:.2f}"
        cv2.putText(img_draw, label, (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

    # 显示图像
    plt.figure(figsize=(15, 5))

    plt.subplot(1, 3, 1)
    plt.imshow(original_img)
    plt.title("原始图像")
    plt.axis('off')

    plt.subplot(1, 3, 2)
    plt.imshow(img_draw)
    plt.title("检测结果")
    plt.axis('off')

    # 显示检测统计
    plt.subplot(1, 3, 3)
    plt.text(0.1, 0.9, f"检测统计:", fontsize=12, fontweight='bold')
    plt.text(0.1, 0.7, f"总检测框: {len(high_conf_boxes)}", fontsize=10)
    plt.text(0.1, 0.5, f"garlic: {sum(1 for b in high_conf_boxes if b['class_id'] == 0)}",
             fontsize=10, color='green')
    plt.text(0.1, 0.3, f"head: {sum(1 for b in high_conf_boxes if b['class_id'] == 1)}",
             fontsize=10, color='red')
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.axis('off')

    plt.tight_layout()
    plt.savefig('pt_model_detection_result.jpg', dpi=150, bbox_inches='tight')
    plt.show()

    print("检测结果已保存为: pt_model_detection_result.jpg")


def main():
    pt_model_path = r"C:\Users\30855\Desktop\buff2026.2.15\runs\pose\Offi_energy_pose_v1\weights\best.pt"
    test_image_path = r"C:\Users\30855\Desktop\frame1_00056.jpg"

    print("=== YOLOv5 PT模型详细测试 ===")

    if not os.path.exists(pt_model_path):
        print(f"模型文件不存在: {pt_model_path}")
        return

    # 加载模型
    model = load_yolov5_model(pt_model_path)
    if model is None:
        return

    # 提取模型部分
    if hasattr(model, 'model'):
        yolov5_model = model.model
    elif isinstance(model, dict) and 'model' in model:
        yolov5_model = model['model']
    else:
        yolov5_model = model

    # 修复数据类型
    yolov5_model = fix_model_dtype(model)

    # 检查模型信息
    print(f"\n模型设备: {next(yolov5_model.parameters()).device}")
    print(f"模型参数数量: {sum(p.numel() for p in yolov5_model.parameters()):,}")

    # 检查类别名称
    if hasattr(model, 'names'):
        print(f"类别名称: {model.names}")

    # 测试1: 使用随机输入
    print("\n=== 测试1: 使用随机输入 ===")
    test_input = torch.randn(1, 3, 640, 640).float()
    print(f"测试输入形状: {test_input.shape}")

    with torch.no_grad():
        output = yolov5_model(test_input)

    analyze_detailed_output(output)

    # 测试2: 使用实际图像
    if os.path.exists(test_image_path):
        test_with_actual_image(yolov5_model, test_image_path)
    else:
        print(f"\n测试图像不存在: {test_image_path}")
        print("跳过实际图像测试")

    print("\n=== 测试完成 ===")


if __name__ == "__main__":
    main()