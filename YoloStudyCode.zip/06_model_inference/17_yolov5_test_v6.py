import cv2
import numpy as np
import matplotlib.pyplot as plt
import onnxruntime as ort
import os
import glob
from PIL import Image


def load_onnx_model_and_check():
    """加载ONNX模型并进行检查"""

    # ONNX模型路径
    onnx_model_path = r"C:\Users\30855\Desktop\trainer\runs\detect\train3\weights\best.onnx"

    if not os.path.exists(onnx_model_path):
        print(f"❌ ONNX模型文件不存在: {onnx_model_path}")
        return None, None

    try:
        # 创建ONNX Runtime会话
        providers = ['CPUExecutionProvider']
        if ort.get_device() == 'GPU':
            providers = ['CUDAExecutionProvider'] + providers

        session = ort.InferenceSession(onnx_model_path, providers=providers)

        # 获取模型输入输出信息
        input_info = session.get_inputs()
        output_info = session.get_outputs()

        print("✅ ONNX模型加载成功!")
        print(f"输入名称: {input_info[0].name}")
        print(f"输入形状: {input_info[0].shape}")
        print(f"输出数量: {len(output_info)}")
        for i, output in enumerate(output_info):
            print(f"输出{i}名称: {output.name}, 形状: {output.shape}")

        # 提取输入尺寸（修复：正确处理形状元组）
        input_shape = input_info[0].shape
        if isinstance(input_shape, tuple) and len(input_shape) >= 3:
            imgsz = int(input_shape[2])  # 获取640
        else:
            imgsz = 640  # 默认值

        return session, imgsz

    except Exception as e:
        print(f"❌ ONNX模型加载失败: {e}")
        return None, None


def preprocess_image(image_path, imgsz=640):
    """预处理输入图像 - 修复版本"""
    if not os.path.exists(image_path):
        print(f"❌ 图像文件不存在: {image_path}")
        return None, None, None

    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像: {image_path}")
        return None, None, None

    original_image = image.copy()
    h, w = image.shape[:2]

    # 使用letterbox方法保持比例调整大小
    resized, ratio, (dw, dh) = letterbox(image, imgsz)

    # 转换颜色通道和归一化
    resized = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
    resized = resized.transpose(2, 0, 1).astype(np.float32) / 255.0
    input_tensor = np.expand_dims(resized, axis=0)

    return input_tensor, (original_image, h, w), (ratio, dw, dh)


def letterbox(im, new_shape=640, color=(114, 114, 114)):
    """保持比例调整图像大小并填充 - 修复版本"""
    # 修复：确保new_shape是整数
    if isinstance(new_shape, (tuple, list)):
        new_shape = new_shape[0]  # 如果是元组，取第一个元素

    shape = im.shape[:2]  # 当前形状 [高度, 宽度]

    # 计算缩放比例
    r = min(new_shape / shape[0], new_shape / shape[1])
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape - new_unpad[0], new_shape - new_unpad[1]

    # 分半填充
    dw /= 2
    dh /= 2

    # 调整大小
    if shape[::-1] != new_unpad:
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)

    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right,
                            cv2.BORDER_CONSTANT, value=color)

    return im, r, (dw, dh)


def postprocess(outputs, original_shape, preprocess_info, conf_threshold=0.25):
    """后处理模型输出 - 针对YOLOv8输出格式优化"""
    ratio, dw, dh = preprocess_info
    original_h, original_w = original_shape

    # 获取模型输出[2](@ref)
    # YOLOv8输出格式为 [1, 6, 8400]，其中6表示[x1, y1, x2, y2, conf, class_id]
    predictions = outputs[0]  # [1, 6, 8400]

    # 转置为 [8400, 6]
    predictions = predictions.transpose(0, 2, 1).squeeze(0)

    # 应用置信度阈值
    keep = predictions[:, 4] > conf_threshold
    filtered_predictions = predictions[keep]

    if len(filtered_predictions) == 0:
        return []

    # 提取边界框信息
    detections = []
    for i in range(len(filtered_predictions)):
        x1, y1, x2, y2, conf, class_id = filtered_predictions[i]

        # 调整到原始图像尺寸
        x1 = (x1 - dw) / ratio
        y1 = (y1 - dh) / ratio
        x2 = (x2 - dw) / ratio
        y2 = (y2 - dh) / ratio

        # 确保边界框在图像范围内
        x1 = max(0, min(x1, original_w))
        y1 = max(0, min(y1, original_h))
        x2 = max(0, min(x2, original_w))
        y2 = max(0, min(y2, original_h))

        detections.append({
            'bbox': [x1, y1, x2, y2],
            'confidence': float(conf),
            'class_id': int(class_id),
            'class_name': f'class_{int(class_id)}'
        })

    # 应用NMS
    detections = apply_nms(detections, iou_threshold=0.45)

    return detections


def apply_nms(detections, iou_threshold=0.45):
    """应用非极大值抑制"""
    if not detections:
        return []

    # 提取边界框和置信度
    boxes = np.array([det['bbox'] for det in detections])
    scores = np.array([det['confidence'] for det in detections])

    if len(boxes) == 0:
        return []

    # 使用OpenCV的NMSBoxes[3](@ref)
    indices = cv2.dnn.NMSBoxes(
        boxes.tolist(), scores.tolist(),
        score_threshold=0.01, nms_threshold=iou_threshold
    )

    if len(indices) == 0:
        return []

    return [detections[i] for i in indices.flatten()]


def visualize_onnx_detection(session, image_path, class_names, imgsz=640):
    """可视化ONNX模型检测结果 - 修复版本"""

    # 预处理图像
    input_tensor, original_info, preprocess_info = preprocess_image(image_path, imgsz)
    if input_tensor is None:
        return None

    original_image, h, w = original_info

    # 运行推理[7](@ref)
    input_name = session.get_inputs()[0].name
    try:
        outputs = session.run(None, {input_name: input_tensor})
    except Exception as e:
        print(f"❌ 推理失败: {e}")
        return None

    # 后处理
    detections = postprocess(outputs, (h, w), preprocess_info, conf_threshold=0.25)

    # 创建可视化图像
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8))

    # 显示原始图像
    original_rgb = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)
    ax1.imshow(original_rgb)
    ax1.set_title('原始图像', fontsize=16, fontweight='bold')
    ax1.axis('off')

    # 显示检测结果
    result_image = original_image.copy()
    for det in detections:
        x1, y1, x2, y2 = [int(coord) for coord in det['bbox']]
        confidence = det['confidence']
        class_id = det['class_id']
        class_name = class_names.get(class_id, f'class_{class_id}')

        # 绘制边界框
        color = (0, 255, 0)  # 绿色
        cv2.rectangle(result_image, (x1, y1), (x2, y2), color, 2)

        # 绘制标签
        label = f'{class_name}: {confidence:.2f}'
        label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
        cv2.rectangle(result_image, (x1, y1 - label_size[1] - 10),
                      (x1 + label_size[0], y1), color, -1)
        cv2.putText(result_image, label, (x1, y1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    result_rgb = cv2.cvtColor(result_image, cv2.COLOR_BGR2RGB)
    ax2.imshow(result_rgb)
    ax2.set_title('ONNX模型检测结果', fontsize=16, fontweight='bold')
    ax2.axis('off')

    # 添加统计信息
    detection_info = f"""
检测统计信息:
- 检测到目标数量: {len(detections)}
- 图像尺寸: {h} × {w}
- 模型输入尺寸: {imgsz} × {imgsz}
    """

    if detections:
        detection_info += "\n检测详情:\n"
        for i, det in enumerate(detections):
            detection_info += (f"{i + 1}. {det['class_name']}: "
                               f"置信度 {det['confidence']:.3f}, "
                               f"位置 {[int(coord) for coord in det['bbox']]}\n")

    plt.figtext(0.02, 0.02, detection_info, fontsize=10,
                bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray"))

    plt.tight_layout()
    plt.savefig('onnx_detection_result.png', dpi=150, bbox_inches='tight')
    plt.show()

    return detections


def check_onnx_overlapping_detections(session, image_path, class_names, imgsz=640):
    """检查ONNX模型的叠加检测情况 - 修复版本"""

    input_tensor, original_info, preprocess_info = preprocess_image(image_path, imgsz)
    if input_tensor is None:
        return None, None

    original_image, h, w = original_info

    # 运行推理
    input_name = session.get_inputs()[0].name
    outputs = session.run(None, {input_name: input_tensor})

    # 使用较低的置信度阈值获取更多检测结果
    detections = postprocess(outputs, (h, w), preprocess_info, conf_threshold=0.2)

    if len(detections) < 2:
        print("⚠️ 需要至少2个检测目标来检查叠加情况")
        return None, None

    # 分类大蒜和大蒜头检测结果
    garlic_boxes = []
    garlic_head_boxes = []

    for det in detections:
        class_name = det['class_name']
        bbox = det['bbox']
        confidence = det['confidence']

        if '大蒜' in class_name and '头' not in class_name:
            garlic_boxes.append((bbox, confidence, class_name))
        elif '大蒜头' in class_name or ('大蒜' in class_name and '头' in class_name):
            garlic_head_boxes.append((bbox, confidence, class_name))

    print(f"🔍 叠加检测分析:")
    print(f"大蒜检测数量: {len(garlic_boxes)}")
    print(f"大蒜头检测数量: {len(garlic_head_boxes)}")

    # 检查叠加关系
    for i, (garlic_bbox, garlic_conf, garlic_name) in enumerate(garlic_boxes):
        for j, (head_bbox, head_conf, head_name) in enumerate(garlic_head_boxes):
            iou = calculate_iou(garlic_bbox, head_bbox)
            contains = check_containment(garlic_bbox, head_bbox)

            print(f"\n大蒜{i + 1} 和 大蒜头{j + 1}:")
            print(f"  IOU: {iou:.3f}")
            print(f"  包含关系: {contains}")
            print(f"  大蒜置信度: {garlic_conf:.3f}")
            print(f"  大蒜头置信度: {head_conf:.3f}")

    return garlic_boxes, garlic_head_boxes


def calculate_iou(box1, box2):
    """计算两个边界框的IOU"""
    x1_1, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2

    # 计算交集区域
    xi1 = max(x1_1, x1_2)
    yi1 = max(y1_1, y1_2)
    xi2 = min(x2_1, x2_2)
    yi2 = min(y2_1, y2_2)

    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)

    # 计算并集区域
    box1_area = (x2_1 - x1_1) * (y2_1 - y1_1)
    box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
    union_area = box1_area + box2_area - inter_area

    return inter_area / union_area if union_area > 0 else 0


def check_containment(box1, box2):
    """检查两个边界框的包含关系"""
    x1_1, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2

    contains_1_2 = (x1_1 <= x1_2 and y1_1 <= y1_2 and
                    x2_1 >= x2_2 and y2_1 >= y2_2)
    contains_2_1 = (x1_2 <= x1_1 and y1_2 <= y1_1 and
                    x2_2 >= x2_1 and y2_2 >= y2_1)

    if contains_1_2:
        return "大蒜包含大蒜头"
    elif contains_2_1:
        return "大蒜头包含大蒜"
    else:
        return "无明确包含关系"


def main():
    """主函数"""
    print("🧄 ONNX格式大蒜检测模型检查工具")
    print("=" * 50)

    # 加载ONNX模型
    session, imgsz = load_onnx_model_and_check()
    if session is None:
        return

    # 类别名称映射（根据您的实际类别修改）
    class_names = {
        0: "大蒜",
        1: "大蒜头"
        # 添加更多类别...
    }

    print("\n" + "=" * 50)
    print("📊 ONNX模型信息汇总:")
    print("=" * 50)
    print(f"模型路径: C:\\Users\\30855\\Desktop\\trainer\\runs\\detect\\train3\\weights\\best.onnx")
    print(f"输入尺寸: {imgsz} × {imgsz}")
    print(f"提供商: {session.get_providers()}")

    # 测试单张图像
    print("\n" + "=" * 50)
    print("🖼️ 单张图像测试")
    print("=" * 50)

    test_image_path = r"C:\Users\30855\Desktop\trainer\images\test\image_00002.jpg"

    if os.path.exists(test_image_path):
        print(f"测试图像: {test_image_path}")
        detections = visualize_onnx_detection(session, test_image_path, class_names, imgsz)

        if detections is not None:
            garlic_boxes, garlic_head_boxes = check_onnx_overlapping_detections(
                session, test_image_path, class_names, imgsz
            )
    else:
        print("⚠️ 请设置正确的测试图像路径")

    print("\n✅ ONNX模型检查完成!")


if __name__ == "__main__":
    main()