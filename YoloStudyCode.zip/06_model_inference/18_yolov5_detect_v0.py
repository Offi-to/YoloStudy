import cv2
import numpy as np
import onnxruntime as ort
import time
from collections import deque
import os


class YOLOONNXDetector:
    def __init__(self, model_path, conf_threshold=0.3, iou_threshold=0.4):
        """
        初始化YOLO ONNX检测器
        降低阈值以提高检测率
        """
        # 检查模型文件是否存在
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"模型文件不存在: {model_path}")

        # 创建ONNX Runtime会话
        try:
            # 使用GPU加速（如果可用）
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider'] if ort.get_device() == 'GPU' else [
                'CPUExecutionProvider']
            self.session = ort.InferenceSession(model_path, providers=providers)
            print("模型加载成功!")
            print(f"使用设备: {ort.get_device()}")
        except Exception as e:
            raise RuntimeError(f"模型加载失败: {e}")

        # 获取模型输入输出信息
        self.input_name = self.session.get_inputs()[0].name
        self.output_name = self.session.get_outputs()[0].name

        # 打印模型信息
        print(f"输入名称: {self.input_name}, 形状: {self.session.get_inputs()[0].shape}")
        print(f"输出名称: {self.output_name}, 形状: {self.session.get_outputs()[0].shape}")

        # 模型输入尺寸
        self.input_shape = (640, 640)

        # 检测参数 - 降低阈值以提高检测率
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold

        # 类别名称（从模型元数据中获取）
        self.class_names = {0: 'garlic', 1: 'head'}

        # 颜色配置
        self.colors = {
            'garlic': (0, 255, 0),  # 绿色 - 大蒜
            'head': (255, 0, 0)  # 蓝色 - 大蒜头
        }

        # 检测统计
        self.detection_count = 0
        self.frame_count = 0

        # FPS计算
        self.fps_deque = deque(maxlen=30)
        self.prev_time = time.time()

    def preprocess(self, image):
        """
        图像预处理
        """
        # 获取原始图像尺寸
        orig_h, orig_w = image.shape[:2]

        # 计算缩放比例
        scale_ratio = min(self.input_shape[0] / orig_w, self.input_shape[1] / orig_h)

        # 计算新的尺寸
        new_w = int(orig_w * scale_ratio)
        new_h = int(orig_h * scale_ratio)

        # 缩放图像
        resized_image = cv2.resize(image, (new_w, new_h))

        # 创建填充图像
        padded_image = np.full((self.input_shape[1], self.input_shape[0], 3), 114, dtype=np.uint8)

        # 计算填充位置
        pad_x = (self.input_shape[0] - new_w) // 2
        pad_y = (self.input_shape[1] - new_h) // 2

        # 将缩放后的图像放入填充图像中
        padded_image[pad_y:pad_y + new_h, pad_x:pad_x + new_w] = resized_image

        # 转换通道顺序和数据类型
        processed_image = padded_image.astype(np.float32) / 255.0  # 归一化
        processed_image = processed_image.transpose(2, 0, 1)  # HWC to CHW
        processed_image = np.expand_dims(processed_image, axis=0)  # 添加batch维度

        padding_info = (pad_x, pad_y, scale_ratio, new_w, new_h)

        return processed_image, padding_info

    def postprocess(self, outputs, orig_shape, padding_info):
        """
        后处理检测结果 - 优化版本
        """
        detections = []
        pad_x, pad_y, scale_ratio, new_w, new_h = padding_info
        orig_h, orig_w = orig_shape[:2]

        # 模型输出形状: [1, 6, 8400]
        predictions = outputs[0]  # [1, 6, 8400]

        # 转置为 [8400, 6]
        predictions = predictions.transpose(1, 2, 0).squeeze(2)

        # 调试：打印前几个预测值
        if self.frame_count % 100 == 0:  # 每100帧打印一次
            print(f"前5个预测值示例:")
            for i in range(min(5, predictions.shape[0])):
                print(f"  预测{i}: {predictions[i]}")

        # 提取边界框和类别概率
        for i in range(predictions.shape[0]):
            # 获取当前预测值
            pred = predictions[i]

            # 根据YOLOv5输出格式，前4个值是边界框坐标，后2个是类别概率
            if len(pred) >= 6:
                x, y, w, h, class1_conf, class2_conf = pred[:6]

                # 取最大的类别概率作为置信度
                conf = max(class1_conf, class2_conf)
                class_id = 0 if class1_conf > class2_conf else 1

                # 进一步降低阈值，特别是对大蒜头
                adjusted_threshold = self.conf_threshold
                if class_id == 1:  # 大蒜头类别
                    adjusted_threshold = max(0.15, self.conf_threshold * 0.8)  # 进一步降低大蒜头的阈值

                if conf < adjusted_threshold:
                    continue

                # 转换坐标到原始图像尺寸
                # 去除填充
                x_orig = (x - pad_x) / scale_ratio
                y_orig = (y - pad_y) / scale_ratio
                w_orig = w / scale_ratio
                h_orig = h / scale_ratio

                # 计算边界框坐标
                x1 = int(max(0, x_orig - w_orig / 2))
                y1 = int(max(0, y_orig - h_orig / 2))
                x2 = int(min(orig_w, x_orig + w_orig / 2))
                y2 = int(min(orig_h, y_orig + h_orig / 2))

                # 确保边界框有效
                if x1 >= x2 or y1 >= y2:
                    continue

                # 计算边界框面积，过滤过小的检测
                box_area = (x2 - x1) * (y2 - y1)
                if box_area < 100:  # 过滤面积小于100像素的检测
                    continue

                detections.append({
                    'bbox': [x1, y1, x2, y2],
                    'confidence': float(conf),
                    'class_id': int(class_id),
                    'class_name': self.class_names[class_id],
                    'area': box_area
                })

        # 更新检测统计
        self.detection_count += len(detections)
        self.frame_count += 1

        # 简单的NMS实现
        detections = self.non_max_suppression(detections)

        # 打印检测信息
        if len(detections) > 0 and self.frame_count % 50 == 0:
            print(f"第{self.frame_count}帧检测到{len(detections)}个目标:")
            for det in detections:
                print(f"  {det['class_name']}: 置信度{det['confidence']:.3f}, 面积{det['area']}")

        return detections

    def non_max_suppression(self, detections):
        """
        非极大值抑制 - 优化版本
        """
        if len(detections) == 0:
            return []

        # 按置信度排序
        detections.sort(key=lambda x: x['confidence'], reverse=True)

        filtered_detections = []

        while detections:
            # 取置信度最高的检测结果
            best_detection = detections.pop(0)
            filtered_detections.append(best_detection)

            # 计算与其他检测结果的IOU
            remaining_detections = []
            for detection in detections:
                # 只有同类别的检测才进行NMS
                if detection['class_id'] == best_detection['class_id']:
                    iou = self.calculate_iou(best_detection['bbox'], detection['bbox'])
                    if iou < self.iou_threshold:
                        remaining_detections.append(detection)
                else:
                    # 不同类别的检测保留
                    remaining_detections.append(detection)

            detections = remaining_detections

        return filtered_detections

    def calculate_iou(self, box1, box2):
        """
        计算两个边界框的IOU
        """
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])

        # 计算交集面积
        intersection = max(0, x2 - x1) * max(0, y2 - y1)

        # 计算并集面积
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - intersection

        return intersection / union if union > 0 else 0

    def draw_detections(self, image, detections):
        """
        在图像上绘制检测结果 - 增强版本
        """
        result_image = image.copy()

        for detection in detections:
            x1, y1, x2, y2 = detection['bbox']
            class_name = detection['class_name']
            confidence = detection['confidence']

            # 获取颜色
            color = self.colors.get(class_name, (0, 255, 255))

            # 绘制边界框
            cv2.rectangle(result_image, (x1, y1), (x2, y2), color, 2)

            # 绘制中心点
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            cv2.circle(result_image, (center_x, center_y), 3, color, -1)

            # 绘制标签背景
            label = f"{class_name}: {confidence:.2f}"
            label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]
            cv2.rectangle(result_image, (x1, y1 - label_size[1] - 10),
                          (x1 + label_size[0], y1), color, -1)

            # 绘制标签文本
            cv2.putText(result_image, label, (x1, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

        # 计算并显示FPS
        current_time = time.time()
        fps = 1 / (current_time - self.prev_time)
        self.prev_time = current_time
        self.fps_deque.append(fps)

        avg_fps = np.mean(self.fps_deque)

        # 显示统计信息
        stats_text = f"FPS: {avg_fps:.1f} | 检测数: {len(detections)} | 总检测: {self.detection_count}"
        cv2.putText(result_image, stats_text, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

        # 显示阈值信息
        threshold_text = f"阈值: {self.conf_threshold}"
        cv2.putText(result_image, threshold_text, (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

        return result_image

    def process_video(self, video_path, output_path=None):
        """
        处理视频文件 - 增强版本
        """
        # 检查视频文件是否存在
        if not os.path.exists(video_path):
            print(f"视频文件不存在: {video_path}")
            return

        # 打开视频文件
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            print(f"无法打开视频文件: {video_path}")
            # 尝试使用不同的后端
            cap = cv2.VideoCapture(video_path, cv2.CAP_FFMPEG)
            if not cap.isOpened():
                print("使用FFMPEG后端也无法打开视频文件")
                return

        # 获取视频属性
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        print(f"开始处理视频: {video_path}")
        print(f"视频尺寸: {width}x{height}, FPS: {fps}, 总帧数: {total_frames}")
        print(f"当前检测参数 - 置信度阈值: {self.conf_threshold}, IOU阈值: {self.iou_threshold}")

        # 创建视频写入器（如果需要保存结果）
        if output_path:
            # 确保输出目录存在
            os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.', exist_ok=True)
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        frame_count = 0
        start_time = time.time()

        # 重置统计
        self.detection_count = 0
        self.frame_count = 0

        while True:
            ret, frame = cap.read()
            if not ret:
                print("已到达视频末尾或读取失败")
                break

            # 预处理
            processed_frame, padding_info = self.preprocess(frame)

            # 推理
            try:
                outputs = self.session.run([self.output_name],
                                           {self.input_name: processed_frame})

                # 后处理
                detections = self.postprocess(outputs, frame.shape, padding_info)

                # 绘制检测结果
                result_frame = self.draw_detections(frame, detections)

                # 显示结果
                cv2.imshow('大蒜识别检测', result_frame)

                # 保存结果（如果需要）
                if output_path:
                    out.write(result_frame)

                frame_count += 1

                # 打印进度
                if frame_count % 30 == 0:
                    elapsed_time = time.time() - start_time
                    avg_fps = frame_count / elapsed_time
                    print(f"已处理 {frame_count}/{total_frames} 帧, 耗时: {elapsed_time:.2f}秒, 平均FPS: {avg_fps:.2f}")

                # 按键控制
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):  # 按q退出
                    print("用户中断处理")
                    break
                elif key == ord('+'):  # 按+增加阈值
                    self.conf_threshold = min(0.9, self.conf_threshold + 0.05)
                    print(f"增加阈值至: {self.conf_threshold}")
                elif key == ord('-'):  # 按-降低阈值
                    self.conf_threshold = max(0.05, self.conf_threshold - 0.05)
                    print(f"降低阈值至: {self.conf_threshold}")

            except Exception as e:
                print(f"处理第 {frame_count} 帧时出错: {e}")
                continue

        # 计算处理时间
        end_time = time.time()
        total_time = end_time - start_time
        avg_fps = frame_count / total_time if total_time > 0 else 0

        print(f"\n处理完成!")
        print(f"总帧数: {frame_count}, 总时间: {total_time:.2f}秒")
        print(f"平均FPS: {avg_fps:.2f}")
        print(f"总检测数: {self.detection_count}")
        print(f"平均每帧检测数: {self.detection_count / frame_count:.2f}" if frame_count > 0 else 0)

        # 释放资源
        cap.release()
        if output_path:
            out.release()
        cv2.destroyAllWindows()

    def test_with_image(self, image_path):
        """
        使用单张图像测试模型
        """
        if not os.path.exists(image_path):
            print(f"图像文件不存在: {image_path}")
            return

        image = cv2.imread(image_path)
        if image is None:
            print(f"无法读取图像: {image_path}")
            return

        # 预处理
        processed_image, padding_info = self.preprocess(image)

        # 推理
        outputs = self.session.run([self.output_name],
                                   {self.input_name: processed_image})

        # 后处理
        detections = self.postprocess(outputs, image.shape, padding_info)

        # 绘制检测结果
        result_image = self.draw_detections(image, detections)

        # 显示结果
        cv2.imshow('大蒜识别检测 - 测试', result_image)
        print(f"检测到 {len(detections)} 个目标")
        for det in detections:
            print(f"  {det['class_name']}: 置信度 {det['confidence']:.3f}, 位置 {det['bbox']}")

        cv2.waitKey(0)
        cv2.destroyAllWindows()


def main():
    # 配置参数
    MODEL_PATH = r"C:\Users\30855\Desktop\trainer\garlic_identify1.onnx"
    VIDEO_PATH = r"C:\Users\30855\Desktop\Video_20251227210941462.avi"
    OUTPUT_PATH = "output_video.mp4"  # 输出视频路径（可选）
    TEST_IMAGE_PATH = "test_image.jpg"  # 测试图像路径（可选）

    # 检查模型文件是否存在
    if not os.path.exists(MODEL_PATH):
        print(f"模型文件不存在: {MODEL_PATH}")
        print("请将模型文件路径修改为正确的路径")
        return

    try:
        # 创建检测器 - 使用更低的阈值
        detector = YOLOONNXDetector(
            model_path=MODEL_PATH,
            conf_threshold=0.2,  # 进一步降低置信度阈值
            iou_threshold=0.4  # 降低IOU阈值以减少重叠框过滤
        )

        # 检查视频文件是否存在
        if not os.path.exists(VIDEO_PATH):
            print(f"视频文件不存在: {VIDEO_PATH}")
            print("请先使用单张图像测试模型")

            # 使用单张图像测试
            if os.path.exists(TEST_IMAGE_PATH):
                print("使用单张图像测试模型...")
                detector.test_with_image(TEST_IMAGE_PATH)
            else:
                print("测试图像也不存在，请检查文件路径")
            return

        # 处理视频
        detector.process_video(VIDEO_PATH, OUTPUT_PATH)

    except Exception as e:
        print(f"程序运行出错: {e}")
        # 添加详细的错误处理和日志记录

if __name__ == "__main__":
    main()