import cv2
import numpy as np
import matplotlib.pyplot as plt
import onnxruntime as ort
import os
import glob
from PIL import Image
import torch


def load_onnx_model(onnx_path):
    """加载ONNX模型"""
    if not os.path.exists(onnx_path):
        print(f"❌❌ ONNX模型文件不存在: {onnx_path}")
        return None, None

    try:
        # 创建ONNX Runtime会话
        session = ort.InferenceSession(onnx_path)

        # 获取输入输出信息
        input_name = session.get_inputs()[0].name
        output_name = session.get_outputs()[0].name

        print("✅ ONNX模型加载成功!")
        print(f"输入名称: {input_name}")
        print(f"输出名称: {output_name}")
        print(f"输入形状: {session.get_inputs()[0].shape}")
        print(f"输出形状: {session.get_outputs()[0].shape}")

        return session, input_name, output_name
    except Exception as e:
        print(f"❌❌ ONNX模型加载失败: {e}")
        return None, None, None


def preprocess_image(image_path, target_size=640):
    """预处理图像"""
    if not os.path.exists(image_path):
        print(f"❌❌ 图像文件不存在: {image_path}")
        return None, None, None

    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌❌ 无法读取图像: {image_path}")
        return None, None, None

    # 保存原始图像用于显示
    original_image = image.copy()
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    # 获取原始尺寸
    h, w = image.shape[:2]

    # 调整大小并归一化
    input_image = cv2.resize(image, (target_size, target_size))
    input_image = input_image.astype(np.float32) / 255.0

    # 转换通道顺序: HWC to CHW
    input_image = input_image.transpose(2, 0, 1)

    # 添加batch维度
    input_tensor = np.expand_dims(input_image, axis=0)

    return input_tensor, original_image, (w, h)


def xywh2xyxy(x, y, w, h):
    """将中心坐标转换为角点坐标"""
    x1 = x - w / 2
    y1 = y - h / 2
    x2 = x + w / 2
    y2 = y + h / 2
    return x1, y1, x2, y2


def non_max_suppression(prediction, conf_threshold=0.25, iou_threshold=0.45):
    """非极大值抑制"""
    boxes = []
    scores = []
    class_ids = []

    # 解析预测结果
    # prediction形状: [1, 6, 8400]
    prediction = prediction[0]  # 去掉batch维度 [6, 8400]

    # 遍历所有预测框
    for i in range(prediction.shape[1]):  # 8400个框
        # 获取类别概率
        class_scores = prediction[4:, i]  # 最后2个是类别概率
        class_id = np.argmax(class_scores)
        confidence = class_scores[class_id]

        # 过滤低置信度框
        if confidence > conf_threshold:
            # 获取边界框坐标 (cx, cy, w, h)
            cx, cy, w, h = prediction[:4, i]

            # 转换为角点坐标
            x1, y1, x2, y2 = xywh2xyxy(cx, cy, w, h)

            boxes.append([x1, y1, x2, y2])
            scores.append(confidence)
            class_ids.append(class_id)

    if len(boxes) == 0:
        return [], [], []

    # 应用NMS
    boxes = np.array(boxes)
    scores = np.array(scores)
    class_ids = np.array(class_ids)

    # 使用OpenCV的NMS
    indices = cv2.dnn.NMSBoxes(boxes.tolist(), scores.tolist(), conf_threshold, iou_threshold)

    if len(indices) > 0:
        indices = indices.flatten()
        return boxes[indices], scores[indices], class_ids[indices]
    else:
        return [], [], []


def scale_boxes(boxes, original_shape, target_shape=640):
    """将边界框从目标尺寸缩放回原始尺寸"""
    if len(boxes) == 0:
        return boxes

    orig_w, orig_h = original_shape
    scale_x = orig_w / target_shape
    scale_y = orig_h / target_shape

    scaled_boxes = boxes.copy()
    scaled_boxes[:, 0] = boxes[:, 0] * scale_x  # x1
    scaled_boxes[:, 1] = boxes[:, 1] * scale_y  # y1
    scaled_boxes[:, 2] = boxes[:, 2] * scale_x  # x2
    scaled_boxes[:, 3] = boxes[:, 3] * scale_y  # y2

    return scaled_boxes


def visualize_detection_onnx(session, input_name, output_name, image_path, conf_threshold=0.25):
    """使用ONNX模型进行检测并可视化结果"""

    # 预处理图像
    input_tensor, original_image, original_shape = preprocess_image(image_path)
    if input_tensor is None:
        return None

    # 推理
    try:
        outputs = session.run([output_name], {input_name: input_tensor})
        prediction = outputs[0]
    except Exception as e:
        print(f"❌❌ 推理失败: {e}")
        return None

    # 应用NMS
    boxes, scores, class_ids = non_max_suppression(prediction, conf_threshold)

    # 缩放边界框到原始图像尺寸
    if len(boxes) > 0:
        boxes = scale_boxes(boxes, original_shape)

    # 创建可视化图像
    result_image = original_image.copy()

    # 定义类别名称和颜色
    class_names = {0: 'garlic', 1: 'head'}
    colors = [(0, 255, 0), (255, 0, 0)]  # 绿色: garlic, 红色: head

    # 绘制检测框
    for i, (box, score, class_id) in enumerate(zip(boxes, scores, class_ids)):
        x1, y1, x2, y2 = box.astype(int)

        # 绘制边界框
        color = colors[class_id]
        cv2.rectangle(result_image, (x1, y1), (x2, y2), color, 2)

        # 绘制标签
        label = f"{class_names[class_id]}: {score:.2f}"
        label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]
        cv2.rectangle(result_image, (x1, y1 - label_size[1] - 10),
                      (x1 + label_size[0], y1), color, -1)
        cv2.putText(result_image, label, (x1, y1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    # 创建可视化对比图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8))

    # 显示原始图像
    ax1.imshow(cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB))
    ax1.set_title('原始图像', fontsize=16, fontweight='bold')
    ax1.axis('off')

    # 显示检测结果
    ax2.imshow(cv2.cvtColor(result_image, cv2.COLOR_BGR2RGB))
    ax2.set_title('ONNX模型检测结果', fontsize=16, fontweight='bold')
    ax2.axis('off')

    # 添加统计信息
    detection_info = f"""
检测统计信息 (ONNX模型):
- 检测到目标数量: {len(boxes)}
- 图像原始尺寸: {original_shape}
- 模型输入尺寸: 640x640
- 模型输出形状: {prediction.shape}
    """

    # 显示每个检测目标的详细信息
    if len(boxes) > 0:
        detection_info += "\n检测详情:\n"
        garlic_count = 0
        head_count = 0

        for i, (box, score, class_id) in enumerate(zip(boxes, scores, class_ids)):
            class_name = class_names[class_id]

            # 统计各类别数量
            if class_name == 'garlic':
                garlic_count += 1
            elif class_name == 'head':
                head_count += 1

            x1, y1, x2, y2 = box.astype(int)
            detection_info += f"{i + 1}. {class_name}: 置信度 {score:.3f}, 位置 [{x1}, {y1}, {x2}, {y2}]\n"

        detection_info += f"\n类别统计:\n- garlic(大蒜): {garlic_count}个\n- head(大蒜头): {head_count}个"

    plt.figtext(0.02, 0.02, detection_info, fontsize=10,
                bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray"))

    plt.tight_layout()
    plt.savefig('onnx_detection_result.png', dpi=150, bbox_inches='tight')
    plt.show()

    return boxes, scores, class_ids


def check_overlapping_detections_onnx(boxes, scores, class_ids):
    """检查garlic和head的叠加检测情况"""

    if len(boxes) < 2:
        print("⚠️ 需要至少2个检测目标来检查叠加情况")
        return None

    # 获取garlic和head的检测结果
    garlic_boxes = []
    head_boxes = []

    for i, (box, score, class_id) in enumerate(zip(boxes, scores, class_ids)):
        class_name = 'garlic' if class_id == 0 else 'head'

        if class_id == 0:  # garlic
            garlic_boxes.append((box, score, class_name))
        elif class_id == 1:  # head
            head_boxes.append((box, score, class_name))

    print(f"🔍🔍 叠加检测分析:")
    print(f"garlic检测数量: {len(garlic_boxes)}")
    print(f"head检测数量: {len(head_boxes)}")

    # 检查叠加关系
    overlap_pairs = []
    for i, (garlic_bbox, garlic_conf, garlic_name) in enumerate(garlic_boxes):
        for j, (head_bbox, head_conf, head_name) in enumerate(head_boxes):
            # 计算IOU（交并比）
            iou = calculate_iou(garlic_bbox, head_bbox)

            # 检查包含关系
            contains = check_containment(garlic_bbox, head_bbox)

            print(f"\ngarlic{i + 1} 和 head{j + 1}:")
            print(f"  IOU: {iou:.3f}")
            print(f"  包含关系: {contains}")
            print(f"  garlic置信度: {garlic_conf:.3f}")
            print(f"  head置信度: {head_conf:.3f}")

            # 记录有重叠的配对
            if iou > 0.1:  # IOU阈值
                overlap_pairs.append((i, j, iou, contains))

    return garlic_boxes, head_boxes, overlap_pairs


def calculate_iou(box1, box2):
    """计算两个边界框的IOU"""
    x11, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2

    # 计算交集区域
    xi1 = max(x11, x1_2)
    yi1 = max(y1_1, y1_2)
    xi2 = min(x2_1, x2_2)
    yi2 = min(y2_1, y2_2)

    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)

    # 计算并集区域
    box1_area = (x2_1 - x11) * (y2_1 - y1_1)
    box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
    union_area = box1_area + box2_area - inter_area

    return inter_area / union_area if union_area > 0 else 0


def check_containment(box1, box2):
    """检查两个边界框的包含关系"""
    x1_1, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2

    # 检查box1是否包含box2
    contains_1_2 = (x1_1 <= x1_2 and y1_1 <= y1_2 and
                    x2_1 >= x2_2 and y2_1 >= y2_2)

    # 检查box2是否包含box1
    contains_2_1 = (x1_2 <= x1_1 and y1_2 <= y1_1 and
                    x2_2 >= x2_1 and y2_2 >= y2_1)

    if contains_1_2:
        return "garlic包含head"
    elif contains_2_1:
        return "head包含garlic"
    else:
        return "无明确包含关系"


def test_on_multiple_images_onnx(session, input_name, output_name, image_folder, num_images=3):
    """在多个图像上测试ONNX模型"""

    # 查找图像文件
    image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp']
    image_paths = []

    for ext in image_extensions:
        image_paths.extend(glob.glob(os.path.join(image_folder, ext)))

    if not image_paths:
        print(f"❌❌ 在文件夹 {image_folder} 中未找到图像文件")
        return

    # 限制测试图像数量
    image_paths = image_paths[:num_images]

    print(f"🔍🔍 在 {len(image_paths)} 张图像上测试ONNX模型...")

    for i, image_path in enumerate(image_paths):
        print(f"\n{'=' * 50}")
        print(f"测试图像 {i + 1}: {os.path.basename(image_path)}")
        print(f"{'=' * 50}")

        # 可视化检测结果
        boxes, scores, class_ids = visualize_detection_onnx(session, input_name, output_name, image_path)

        if boxes is not None and len(boxes) > 0:
            # 检查叠加检测
            check_overlapping_detections_onnx(boxes, scores, class_ids)


def main():
    """主函数"""

    print("🧄🧄 大蒜检测ONNX模型检查工具")
    print("=" * 50)

    # ONNX模型路径 - 请修改为您的实际路径
    onnx_path = r"C:\Users\30855\Desktop\trainer\garlic_identify1_.onnx"  # 替换为您的ONNX模型路径

    # 1. 加载ONNX模型
    session, input_name, output_name = load_onnx_model(onnx_path)
    if session is None:
        return

    print("\n" + "=" * 50)
    print("📊📊 ONNX模型信息汇总:")
    print("=" * 50)
    print(f"模型路径: {onnx_path}")
    print(f"输入名称: {input_name}")
    print(f"输出名称: {output_name}")
    print(f"输入形状: {session.get_inputs()[0].shape}")
    print(f"输出形状: {session.get_outputs()[0].shape}")
    print("类别名称: {0: 'garlic', 1: 'head'}")

    # 2. 测试单张图像
    print("\n" + "=" * 50)
    print("🖼🖼🖼️ 单张图像测试")
    print("=" * 50)

    # 请将下面的路径替换为您的测试图像路径
    test_image_path = r"C:\Users\30855\Desktop\trainer\images\train\image_00069.jpg"  # 替换为实际路径

    if os.path.exists(test_image_path):
        print(f"测试图像: {test_image_path}")
        boxes, scores, class_ids = visualize_detection_onnx(session, input_name, output_name, test_image_path)

        if boxes is not None and len(boxes) > 0:
            # 详细分析叠加检测
            garlic_boxes, head_boxes, overlap_pairs = check_overlapping_detections_onnx(boxes, scores, class_ids)

            if overlap_pairs:
                print(f"\n🎯 发现 {len(overlap_pairs)} 对有重叠的检测目标")
                for i, j, iou, relation in overlap_pairs:
                    print(f"  garlic{i + 1} 和 head{j + 1}: IOU={iou:.3f}, 关系={relation}")
    else:
        print("⚠️ 请设置正确的测试图像路径")

    # 3. 批量测试（可选）
    print("\n" + "=" * 50)
    print("📸📸 批量图像测试")
    print("=" * 50)

    test_folder = r"C:\Users\30855\Desktop\trainer\images\test"  # 替换为实际文件夹路径
    if os.path.exists(test_folder):
        test_on_multiple_images_onnx(session, input_name, output_name, test_folder, num_images=3)
    else:
        print("⚠️ 请设置正确的测试文件夹路径")

    print("\n✅ ONNX模型检查完成!")


if __name__ == "__main__":
    main()