import cv2
import onnxruntime as ort
import numpy as np


class ONNXVideoDetector:
    def __init__(self, onnx_model_path, conf_threshold=0.3):
        self.conf_threshold = conf_threshold

        # 初始化ONNX Runtime
        try:
            self.session = ort.InferenceSession(onnx_model_path)
            print("ONNX模型加载成功!")
        except Exception as e:
            print(f"ONNX模型加载失败: {e}")
            return

        # 获取模型信息
        self.input_name = self.session.get_inputs()[0].name
        self.output_names = [output.name for output in self.session.get_outputs()]

        # 输入形状 [batch, channels, height, width]
        self.input_shape = self.session.get_inputs()[0].shape
        self.input_height = self.input_shape[2]
        self.input_width = self.input_shape[3]

        print(f"输入形状: {self.input_shape}")
        print(f"输出名称: {self.output_names}")

        # 添加显示窗口尺寸控制
        self.display_width = 1280
        self.display_height = 720

        # 定义不同类别的颜色（用于不同类别的框）
        self.colors = [
            (0, 255, 0),  # 绿色
            (255, 0, 0),  # 蓝色
            (0, 0, 255),  # 红色
            (255, 255, 0),  # 青色
            (255, 0, 255),  # 紫色
            (0, 255, 255),  # 黄色
            (128, 0, 128),  # 深紫色
            (0, 128, 128),  # 橄榄色
        ]

    def preprocess(self, image):
        """预处理图像 - YOLO格式"""
        # 调整大小
        img = cv2.resize(image, (self.input_width, self.input_height))

        # 转换颜色通道 BGR -> RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        # 归一化
        img = img.astype(np.float32) / 255.0

        # 调整维度顺序 HWC -> CHW
        img = np.transpose(img, (2, 0, 1))

        # 添加batch维度
        img = np.expand_dims(img, axis=0)

        return img

    def postprocess(self, outputs, original_shape):
        """后处理 - 处理YOLO输出"""
        detections = []

        # YOLO输出通常是 [1, 84, 8400] 或类似格式
        for i, output in enumerate(outputs):
            # 处理不同的输出格式
            if len(output.shape) == 3:
                # 常见的YOLO输出格式 [1, 84, 8400]
                # 84 = 4(bbox) + 80(classes)
                output = output[0]  # 移除batch维度

                # 遍历所有检测
                for j in range(output.shape[1]):
                    # 获取边界框和类别分数
                    bbox = output[:4, j]  # x_center, y_center, width, height
                    scores = output[4:, j]

                    # 找到最高分数和对应的类别
                    class_id = np.argmax(scores)
                    confidence = scores[class_id]

                    if confidence > self.conf_threshold:
                        # 转换边界框坐标
                        x_center, y_center, width, height = bbox

                        # 转换为左上角和右下角坐标
                        x1 = (x_center - width / 2) * original_shape[1]
                        y1 = (y_center - height / 2) * original_shape[0]
                        x2 = (x_center + width / 2) * original_shape[1]
                        y2 = (y_center + height / 2) * original_shape[0]

                        # 确保坐标不超出图像范围
                        x1 = max(0, int(x1))
                        y1 = max(0, int(y1))
                        x2 = min(original_shape[1], int(x2))
                        y2 = min(original_shape[0], int(y2))

                        detections.append({
                            'bbox': [x1, y1, x2, y2],
                            'confidence': float(confidence),
                            'class_id': int(class_id)
                        })

        return detections

    def resize_frame(self, frame):
        """调整帧大小以适应显示窗口"""
        h, w = frame.shape[:2]

        # 计算缩放比例
        scale = min(self.display_width / w, self.display_height / h)
        new_w = int(w * scale)
        new_h = int(h * scale)

        # 调整大小
        resized_frame = cv2.resize(frame, (new_w, new_h))
        return resized_frame

    def draw_detection_boxes(self, frame, detections):
        """绘制检测框和标签"""
        for det in detections:
            x1, y1, x2, y2 = det['bbox']
            conf = det['confidence']
            class_id = det['class_id']

            # 根据类别ID选择颜色
            color = self.colors[class_id % len(self.colors)]

            # 绘制边界框 - 更粗的线条
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 3)

            # 绘制角标，让框更明显
            corner_length = min(20, (x2 - x1) // 4, (y2 - y1) // 4)

            # 左上角
            cv2.line(frame, (x1, y1), (x1 + corner_length, y1), color, 3)
            cv2.line(frame, (x1, y1), (x1, y1 + corner_length), color, 3)

            # 右上角
            cv2.line(frame, (x2, y1), (x2 - corner_length, y1), color, 3)
            cv2.line(frame, (x2, y1), (x2, y1 + corner_length), color, 3)

            # 左下角
            cv2.line(frame, (x1, y2), (x1 + corner_length, y2), color, 3)
            cv2.line(frame, (x1, y2), (x1, y2 - corner_length), color, 3)

            # 右下角
            cv2.line(frame, (x2, y2), (x2 - corner_length, y2), color, 3)
            cv2.line(frame, (x2, y2), (x2, y2 - corner_length), color, 3)

            # 创建标签背景
            label = f"ID:{class_id} {conf:.2f}"
            (text_width, text_height), baseline = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)

            # 标签背景位置
            label_bg_y1 = max(y1 - text_height - 10, 0)
            label_bg_y2 = y1
            label_bg_x1 = x1
            label_bg_x2 = x1 + text_width + 10

            # 绘制半透明标签背景
            overlay = frame.copy()
            cv2.rectangle(overlay, (label_bg_x1, label_bg_y1),
                          (label_bg_x2, label_bg_y2), color, -1)
            alpha = 0.6  # 透明度
            cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)

            # 绘制标签文字
            cv2.putText(frame, label, (x1 + 5, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

            # 在框内中心显示置信度
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            cv2.putText(frame, f"{conf:.2f}",
                        (center_x - 15, center_y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

            print(f"检测到物体: 类别ID {class_id}, 置信度 {conf:.3f}, 位置 [{x1}, {y1}, {x2}, {y2}]")

        return frame

    def process_video(self, video_path):
        """处理视频"""
        cap = cv2.VideoCapture(video_path)

        if not cap.isOpened():
            print(f"无法打开视频: {video_path}")
            return

        # 获取视频信息
        original_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        original_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        print(f"视频分辨率: {original_width}x{original_height}")
        print(f"视频FPS: {fps:.2f}")
        print(f"总帧数: {total_frames}")

        # 创建可调整大小的窗口
        cv2.namedWindow('Detection', cv2.WINDOW_NORMAL)
        cv2.resizeWindow('Detection', self.display_width, self.display_height)

        frame_count = 0
        detection_count = 0

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            frame_count += 1

            # 预处理
            input_tensor = self.preprocess(frame)

            # 推理
            outputs = self.session.run(self.output_names, {self.input_name: input_tensor})

            # 后处理
            detections = self.postprocess(outputs, frame.shape)

            # 统计检测结果
            if detections:
                detection_count += len(detections)
                print(f"第 {frame_count} 帧检测到 {len(detections)} 个物体")

            # 绘制检测框
            frame_with_boxes = self.draw_detection_boxes(frame.copy(), detections)

            # 调整帧大小以适应显示
            display_frame = self.resize_frame(frame_with_boxes)

            # 添加帧信息和检测统计
            cv2.putText(display_frame, f"Frame: {frame_count}/{total_frames}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(display_frame, f"Detections: {len(detections)}", (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(display_frame, f"Total: {detection_count}", (10, 90),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            # 显示帧
            cv2.imshow('Detection', display_frame)

            # 按键控制
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord(' '):  # 空格键暂停/继续
                cv2.waitKey(0)
            elif key == ord('+'):  # + 键放大窗口
                self.display_width = min(self.display_width + 100, 1920)
                self.display_height = min(self.display_height + 100, 1080)
                cv2.resizeWindow('Detection', self.display_width, self.display_height)
            elif key == ord('-'):  # - 键缩小窗口
                self.display_width = max(self.display_width - 100, 640)
                self.display_height = max(self.display_height - 100, 480)
                cv2.resizeWindow('Detection', self.display_width, self.display_height)

        cap.release()
        cv2.destroyAllWindows()

        # 输出统计信息
        print(f"\n=== 检测统计 ===")
        print(f"总帧数: {frame_count}")
        print(f"总检测数: {detection_count}")
        print(f"检测率: {detection_count / frame_count:.2f} 个物体/帧")


# 使用示例
if __name__ == "__main__":
    # 使用ONNX模型
    detector = ONNXVideoDetector("C:/Users/30855/Desktop/buff.onnx", conf_threshold=0.3)
    detector.process_video("C:/Users/30855/Desktop/33ce6a7a9ce0824d56743a1a4af8f560.mp4")