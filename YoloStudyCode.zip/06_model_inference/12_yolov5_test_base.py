import onnxruntime as ort
import cv2
import numpy as np
import time
from typing import List, Tuple


class ONNXModelTester:
    def __init__(self, model_path: str, conf_threshold: float = 0.25, iou_threshold: float = 0.45):
        """
        初始化ONNX模型测试器

        参数:
            model_path: ONNX模型文件路径
            conf_threshold: 置信度阈值
            iou_threshold: 非极大值抑制的IOU阈值
        """
        # 创建推理会话
        self.session = ort.InferenceSession(model_path)

        # 获取输入输出信息
        self.input_name = self.session.get_inputs()[0].name
        self.output_name = self.session.get_outputs()[0].name
        self.input_shape = self.session.get_inputs()[0].shape  # [1, 3, 640, 640]
        self.output_shape = self.session.get_outputs()[0].shape  # [1, 6, 8400]

        # 模型参数
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold
        self.img_size = (640, 640)  # 模型期望的输入尺寸

        # 类别名称 (从您的模型信息中提取)
        self.class_names = {0: 'garlic', 1: 'head'}

        print(f"模型加载成功!")
        print(f"输入名称: {self.input_name}, 形状: {self.input_shape}")
        print(f"输出名称: {self.output_name}, 形状: {self.output_shape}")
        print(f"检测类别: {self.class_names}")

    def preprocess(self, image: np.ndarray) -> np.ndarray:
        """
        图像预处理：调整大小、归一化、转换通道顺序

        参数:
            image: 输入图像 (H, W, C)
        返回:
            预处理后的图像 (1, 3, 640, 640)
        """
        # 记录原始图像尺寸
        self.orig_shape = image.shape[:2]  # (H, W)

        # 调整图像大小到640x640
        img_resized = cv2.resize(image, self.img_size)

        # 转换颜色空间 BGR -> RGB
        img_rgb = cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB)

        # 归一化到0-1范围
        img_normalized = img_rgb.astype(np.float32) / 255.0

        # 转换通道顺序 HWC -> CHW
        img_chw = np.transpose(img_normalized, (2, 0, 1))

        # 添加批次维度
        img_batch = np.expand_dims(img_chw, axis=0)

        return img_batch.astype(np.float32)

    def postprocess(self, outputs: np.ndarray) -> List[Tuple]:
        """
        后处理：解析模型输出，应用置信度阈值和NMS

        参数:
            outputs: 模型输出 [1, 6, 8400]
        返回:
            检测结果列表 [(x1, y1, x2, y2, conf, class_id), ...]
        """
        # 转换输出形状 [1, 6, 8400] -> [8400, 6]
        predictions = outputs[0].transpose(1, 0)

        detections = []

        for pred in predictions:
            # 提取边界框坐标 (x_center, y_center, width, height)
            x_center, y_center, width, height = pred[:4]

            # 提取类别置信度
            class_scores = pred[4:6]

            # 获取最大置信度及其类别
            max_class_score = np.max(class_scores)
            class_id = np.argmax(class_scores)

            # 应用置信度阈值
            if max_class_score < self.conf_threshold:
                continue

            # 转换边界框格式 (xywh -> xyxy)
            x1 = x_center - width / 2
            y1 = y_center - height / 2
            x2 = x_center + width / 2
            y2 = y_center + height / 2

            # 将坐标缩放回原始图像尺寸
            scale_x = self.orig_shape[1] / self.img_size[0]  # 宽度缩放比例
            scale_y = self.orig_shape[0] / self.img_size[1]  # 高度缩放比例

            x1 = int(x1 * scale_x)
            y1 = int(y1 * scale_y)
            x2 = int(x2 * scale_x)
            y2 = int(y2 * scale_y)

            # 确保坐标不超出图像边界
            x1 = max(0, min(x1, self.orig_shape[1]))
            y1 = max(0, min(y1, self.orig_shape[0]))
            x2 = max(0, min(x2, self.orig_shape[1]))
            y2 = max(0, min(y2, self.orig_shape[0]))

            detections.append((x1, y1, x2, y2, max_class_score, class_id))

        # 应用非极大值抑制 (NMS)
        return self.non_max_suppression(detections)

    def non_max_suppression(self, detections: List[Tuple]) -> List[Tuple]:
        """
        非极大值抑制，去除重叠的检测框

        参数:
            detections: 原始检测结果
        返回:
            经过NMS过滤的检测结果
        """
        if len(detections) == 0:
            return []

        # 按置信度排序
        detections.sort(key=lambda x: x[4], reverse=True)

        keep = []
        while len(detections) > 0:
            # 取置信度最高的检测框
            best = detections.pop(0)
            keep.append(best)

            # 计算与剩余检测框的IOU
            remaining = []
            for det in detections:
                iou = self.calculate_iou(best, det)
                if iou < self.iou_threshold:
                    remaining.append(det)

            detections = remaining

        return keep

    def calculate_iou(self, box1: Tuple, box2: Tuple) -> float:
        """
        计算两个边界框的IOU (交并比)
        """
        x1_1, y1_1, x2_1, y2_1 = box1[:4]
        x1_2, y1_2, x2_2, y2_2 = box2[:4]

        # 计算交集区域
        x_left = max(x1_1, x1_2)
        y_top = max(y1_1, y1_2)
        x_right = min(x2_1, x2_2)
        y_bottom = min(y2_1, y2_2)

        if x_right < x_left or y_bottom < y_top:
            return 0.0

        intersection_area = (x_right - x_left) * (y_bottom - y_top)

        # 计算并集区域
        area1 = (x2_1 - x1_1) * (y2_1 - y1_1)
        area2 = (x2_2 - x1_2) * (y2_2 - y1_2)
        union_area = area1 + area2 - intersection_area

        return intersection_area / union_area if union_area > 0 else 0.0

    def draw_detections(self, image: np.ndarray, detections: List[Tuple]) -> np.ndarray:
        """
        在图像上绘制检测结果

        参数:
            image: 原始图像
            detections: 检测结果
        返回:
            绘制了检测框的图像
        """
        result_image = image.copy()

        # 定义颜色 (BGR格式)
        colors = {
            0: (0, 255, 0),  # 绿色 - garlic
            1: (0, 0, 255)  # 红色 - head
        }

        for det in detections:
            x1, y1, x2, y2, conf, class_id = det

            # 绘制边界框
            color = colors.get(class_id, (255, 255, 255))
            cv2.rectangle(result_image, (x1, y1), (x2, y2), color, 2)

            # 绘制标签和置信度
            label = f"{self.class_names[class_id]}: {conf:.2f}"
            label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]

            # 标签背景
            cv2.rectangle(result_image,
                          (x1, y1 - label_size[1] - 10),
                          (x1 + label_size[0], y1),
                          color, -1)

            # 标签文字
            cv2.putText(result_image, label,
                        (x1, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        return result_image

    def test_image(self, image_path: str, output_path: str = None) -> None:
        """
        测试单张图像

        参数:
            image_path: 输入图像路径
            output_path: 输出图像路径 (可选)
        """
        # 读取图像
        image = cv2.imread(image_path)
        if image is None:
            print(f"错误: 无法读取图像 {image_path}")
            return

        print(f"测试图像: {image_path}")
        print(f"原始图像尺寸: {image.shape}")

        # 预处理
        start_time = time.time()
        input_data = self.preprocess(image)
        preprocess_time = time.time() - start_time

        # 推理
        start_time = time.time()
        outputs = self.session.run([self.output_name], {self.input_name: input_data})[0]
        inference_time = time.time() - start_time

        # 后处理
        start_time = time.time()
        detections = self.postprocess(outputs)
        postprocess_time = time.time() - start_time

        # 绘制结果
        result_image = self.draw_detections(image, detections)

        # 显示结果信息
        print(f"预处理时间: {preprocess_time * 1000:.2f}ms")
        print(f"推理时间: {inference_time * 1000:.2f}ms")
        print(f"后处理时间: {postprocess_time * 1000:.2f}ms")
        print(f"总时间: {(preprocess_time + inference_time + postprocess_time) * 1000:.2f}ms")
        print(f"检测到 {len(detections)} 个目标:")

        for i, det in enumerate(detections):
            x1, y1, x2, y2, conf, class_id = det
            class_name = self.class_names[class_id]
            print(f"  {i + 1}. {class_name}: 置信度 {conf:.3f}, 位置 [{x1}, {y1}, {x2}, {y2}]")

        # 保存或显示结果
        if output_path:
            cv2.imwrite(output_path, result_image)
            print(f"结果已保存到: {output_path}")

        # 显示结果图像
        cv2.imshow('Detection Result', result_image)
        cv2.waitKey(0)
        cv2.destroyAllWindows()


# 使用示例
if __name__ == "__main__":
    # 替换为您的ONNX模型路径
    MODEL_PATH = r"C:\Users\30855\Desktop\trainer\garlic_identify1.onnx"  # 请修改为实际模型路径
    IMAGE_PATH = r"C:\Users\30855\MVS\Data\Image_20251227211047044.bmp"  # 请修改为测试图像路径

    # 创建测试器
    tester = ONNXModelTester(MODEL_PATH)

    # 测试图像
    tester.test_image(IMAGE_PATH, "result.jpg")