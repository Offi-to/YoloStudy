import cv2
import numpy as np
import matplotlib.pyplot as plt
from ultralytics import YOLO
import os
import glob
from PIL import Image
import torch


def load_model_and_check():
    """加载训练好的模型并进行检查"""

    # 模型路径 - 根据您的训练配置
    model_path = r"C:\Users\30855\Desktop\trainer\runs\detect\train2\weights\best.pt"

    # 检查模型文件是否存在
    if not os.path.exists(model_path):
        print(f"模型文件不存在: {model_path}")
        print("请先完成模型训练或检查路径是否正确")
        return None

    # 加载模型
    try:
        model = YOLO(model_path)
        print("✅ 模型加载成功!")
        print(f"模型类别: {model.names}")
        print(f"模型类别数量: {len(model.names)}")

        # 检查设备
        device = next(model.parameters()).device
        print(f"模型运行在: {device}")

        return model
    except Exception as e:
        print(f"❌ 模型加载失败: {e}")
        return None


def process_video_detection(model, video_path, output_path=None, conf_threshold=0.25, display=True):
    """处理视频检测并保存结果[4,6](@ref)"""

    if not os.path.exists(video_path):
        print(f"❌ 视频文件不存在: {video_path}")
        return None

    # 打开视频文件[6,7](@ref)
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("❌ 无法打开视频文件")
        return None

    # 获取视频属性[6](@ref)
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    print(f"📹 视频信息: {fps}FPS, 分辨率: {frame_width}x{frame_height}, 总帧数: {total_frames}")

    # 设置视频输出[4,6](@ref)
    if output_path:
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (frame_width, frame_height))

    frame_count = 0
    detection_stats = []

    print("🔍 开始处理视频检测...")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_count += 1
        print(f"处理帧: {frame_count}/{total_frames}", end='\r')

        # 进行预测[1](@ref)
        results = model(frame, conf=conf_threshold, imgsz=640)

        if len(results) > 0:
            result = results[0]

            # 绘制检测结果[1](@ref)
            detected_frame = result.plot()

            # 记录检测统计信息
            if len(result.boxes) > 0:
                frame_stats = {
                    'frame': frame_count,
                    'total_detections': len(result.boxes),
                    'detections_by_class': {}
                }

                for box in result.boxes:
                    cls_id = int(box.cls)
                    class_name = model.names[cls_id]
                    conf = box.conf[0].item()

                    if class_name not in frame_stats['detections_by_class']:
                        frame_stats['detections_by_class'][class_name] = 0
                    frame_stats['detections_by_class'][class_name] += 1

                detection_stats.append(frame_stats)

                # 在帧上添加统计信息[5](@ref)
                stats_text = f"Frame: {frame_count} | Detections: {len(result.boxes)}"
                cv2.putText(detected_frame, stats_text, (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        else:
            detected_frame = frame

        # 保存或显示结果[6](@ref)
        if output_path:
            out.write(detected_frame)

        if display:
            cv2.imshow('Video Detection', detected_frame)
            # 按Q键退出[6](@ref)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    if output_path:
        out.release()
    cv2.destroyAllWindows()

    print(f"\n✅ 视频处理完成! 处理了 {frame_count} 帧")
    return detection_stats


def analyze_video_detections(detection_stats, model):
    """分析视频检测结果"""
    if not detection_stats:
        print("❌ 没有检测数据可分析")
        return

    total_frames = len(detection_stats)
    total_detections = sum([stats['total_detections'] for stats in detection_stats])

    print(f"\n📊 视频检测分析报告:")
    print(f"总帧数: {total_frames}")
    print(f"总检测数: {total_detections}")
    print(f"平均每帧检测数: {total_detections / total_frames:.2f}")

    # 统计各类别检测数量
    class_totals = {}
    for stats in detection_stats:
        for class_name, count in stats['detections_by_class'].items():
            if class_name not in class_totals:
                class_totals[class_name] = 0
            class_totals[class_name] += count

    print("\n📈 类别检测统计:")
    for class_name, count in class_totals.items():
        percentage = (count / total_detections) * 100
        print(f"  {class_name}: {count}次 ({percentage:.1f}%)")

    return class_totals


def check_video_overlapping(model, video_path, sample_interval=30):
    """检查视频中的叠加检测情况[1](@ref)"""

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("❌ 无法打开视频文件")
        return None

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    overlapping_frames = []

    print(f"🔍 检查视频叠加检测 (采样间隔: {sample_interval}帧)")

    for frame_num in range(0, total_frames, sample_interval):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_num)
        ret, frame = cap.read()

        if not ret:
            continue

        # 进行预测
        results = model(frame, conf=0.2)
        if len(results) == 0:
            continue

        result = results[0]
        garlic_boxes = []
        garlic_head_boxes = []

        # 分类检测框[1](@ref)
        for box in result.boxes:
            cls_id = int(box.cls)
            class_name = model.names[cls_id]
            bbox = box.xyxy[0].cpu().numpy()
            conf = box.conf[0].item()

            if '大蒜' in class_name and '头' not in class_name:
                garlic_boxes.append((bbox, conf, class_name))
            elif '大蒜头' in class_name or ('大蒜' in class_name and '头' in class_name):
                garlic_head_boxes.append((bbox, conf, class_name))

        # 检查叠加关系
        if garlic_boxes and garlic_head_boxes:
            frame_overlaps = []
            for i, (garlic_bbox, garlic_conf, garlic_name) in enumerate(garlic_boxes):
                for j, (head_bbox, head_conf, head_name) in enumerate(garlic_head_boxes):
                    iou = calculate_iou(garlic_bbox, head_bbox)
                    contains = check_containment(garlic_bbox, head_bbox)

                    if iou > 0.1:  # 存在一定重叠
                        frame_overlaps.append({
                            'frame': frame_num,
                            'garlic_bbox': garlic_bbox,
                            'head_bbox': head_bbox,
                            'iou': iou,
                            'containment': contains,
                            'garlic_conf': garlic_conf,
                            'head_conf': head_conf
                        })

            if frame_overlaps:
                overlapping_frames.extend(frame_overlaps)
                print(f"帧 {frame_num}: 发现 {len(frame_overlaps)} 个叠加检测")

    cap.release()

    if overlapping_frames:
        print(f"\n⚠️ 在 {len(overlapping_frames)} 个检测中发现叠加情况")
        # 显示最严重的几个叠加案例
        overlapping_frames.sort(key=lambda x: x['iou'], reverse=True)
        for i, overlap in enumerate(overlapping_frames[:3]):
            print(f"案例 {i + 1}: 帧 {overlap['frame']}, IOU: {overlap['iou']:.3f}, 关系: {overlap['containment']}")
    else:
        print("✅ 未发现明显的叠加检测问题")

    return overlapping_frames


def calculate_iou(box1, box2):
    """计算两个边界框的IOU[1](@ref)"""
    x1_1, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2

    # 计算交集区域
    xi1 = max(x1_1, x1_2)
    yi1 = max(y1_1, y1_2)
    xi2 = min(x2_1, x2_2)
    yi2 = min(y2_1, y2_2)

    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)

    # 计算并集区域
    box1_area = (x2_1 - x1_1) * (y2_1 - y1_1)
    box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
    union_area = box1_area + box2_area - inter_area

    return inter_area / union_area if union_area > 0 else 0


def check_containment(box1, box2):
    """检查两个边界框的包含关系[1](@ref)"""
    x1_1, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2

    # 检查box1是否包含box2
    contains_1_2 = (x1_1 <= x1_2 and y1_1 <= y1_2 and
                    x2_1 >= x2_2 and y2_1 >= y2_2)

    # 检查box2是否包含box1
    contains_2_1 = (x1_2 <= x1_1 and y1_2 <= y1_1 and
                    x2_2 >= x2_1 and y2_2 >= y2_1)

    if contains_1_2:
        return "大蒜包含大蒜头"
    elif contains_2_1:
        return "大蒜头包含大蒜"
    else:
        return "无明确包含关系"


def generate_detection_report(model, video_path, detection_stats, overlapping_frames):
    """生成检测报告"""
    print("\n" + "=" * 60)
    print("📋 大蒜检测视频分析报告")
    print("=" * 60)

    # 基础信息
    cap = cv2.VideoCapture(video_path)
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    duration = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) / fps
    cap.release()

    print(f"视频文件: {os.path.basename(video_path)}")
    print(f"视频时长: {duration:.1f}秒 ({fps}FPS)")
    print(f"模型类别: {model.names}")

    # 检测统计
    if detection_stats:
        total_detections = sum([stats['total_detections'] for stats in detection_stats])
        avg_detections = total_detections / len(detection_stats)
        print(f"平均检测数: {avg_detections:.1f}个/帧")

    # 叠加检测情况
    if overlapping_frames:
        print(f"⚠️ 发现叠加检测: {len(overlapping_frames)}处")
        avg_iou = sum([overlap['iou'] for overlap in overlapping_frames]) / len(overlapping_frames)
        print(f"平均IOU: {avg_iou:.3f}")
    else:
        print("✅ 叠加检测: 无显著问题")

    print("=" * 60)


def main():
    """主函数"""

    print("🧄 大蒜检测视频检查工具")
    print("=" * 50)

    # 1. 加载模型
    model = load_model_and_check()
    if model is None:
        return

    print("\n" + "=" * 50)
    print("📊 模型信息汇总:")
    print("=" * 50)
    print(f"模型路径: runs/detect/train2/weights/best.pt")
    print(f"类别数量: {len(model.names)}")
    print("类别名称:")
    for class_id, class_name in model.names.items():
        print(f"  {class_id}: {class_name}")

    # 2. 视频检测
    print("\n" + "=" * 50)
    print("🎥 视频检测模式")
    print("=" * 50)

    # 请将下面的路径替换为您的测试视频路径
    test_video_path = r"C:\Users\30855\MVS\Data\MV-CA013-A0UC (J84320541)\Video_20251224040610620.avi"  # 替换为实际路径
    output_video_path = r"C:\Users\30855\Desktop"  # 输出路径

    if os.path.exists(test_video_path):
        print(f"测试视频: {test_video_path}")

        # 进行视频检测
        detection_stats = process_video_detection(
            model,
            test_video_path,
            output_path=output_video_path,
            conf_threshold=0.25,
            display=True
        )

        # 分析检测结果
        if detection_stats:
            analyze_video_detections(detection_stats, model)

            # 检查叠加检测
            overlapping_frames = check_video_overlapping(model, test_video_path)

            # 生成报告
            generate_detection_report(model, test_video_path, detection_stats, overlapping_frames)
    else:
        print("⚠️ 请设置正确的测试视频路径")
        # 如果没有视频文件，尝试使用摄像头[2](@ref)
        use_camera = input("是否使用摄像头进行实时检测? (y/n): ")
        if use_camera.lower() == 'y':
            print("📷 启动摄像头检测...")
            # 简单的摄像头检测
            cap = cv2.VideoCapture(0)
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                results = model(frame, conf=0.25)
                if len(results) > 0:
                    detected_frame = results[0].plot()
                    cv2.imshow('Camera Detection', detected_frame)
                else:
                    cv2.imshow('Camera Detection', frame)

                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break

            cap.release()
            cv2.destroyAllWindows()

    print("\n✅ 视频检测完成!")


if __name__ == "__main__":
    main()