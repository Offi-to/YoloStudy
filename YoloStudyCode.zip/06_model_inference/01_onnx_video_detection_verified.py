import cv2
import numpy as np
import matplotlib.pyplot as plt
import onnxruntime as ort
import os
import glob
from PIL import Image
import torch
import time


def load_onnx_model(onnx_path):
    """加载ONNX模型"""
    if not os.path.exists(onnx_path):
        print(f"❌❌ ONNX模型文件不存在: {onnx_path}")
        return None, None, None

    try:
        # 创建ONNX Runtime会话
        session = ort.InferenceSession(onnx_path)

        # 获取输入输出信息
        input_name = session.get_inputs()[0].name
        output_name = session.get_outputs()[0].name

        print("✅ ONNX模型加载成功!")
        print(f"输入名称: {input_name}")
        print(f"输出名称: {output_name}")
        print(f"输入形状: {session.get_inputs()[0].shape}")
        print(f"输出形状: {session.get_outputs()[0].shape}")

        return session, input_name, output_name
    except Exception as e:
        print(f"❌❌ ONNX模型加载失败: {e}")
        return None, None, None


def preprocess_frame(frame, target_size=640):
    """预处理视频帧"""
    if frame is None:
        return None, None, None

    # 保存原始图像用于显示
    original_frame = frame.copy()
    h, w = frame.shape[:2]

    # 调整大小并归一化
    input_frame = cv2.resize(frame, (target_size, target_size))
    input_frame = input_frame.astype(np.float32) / 255.0

    # 转换通道顺序: HWC to CHW
    input_frame = input_frame.transpose(2, 0, 1)

    # 添加batch维度
    input_tensor = np.expand_dims(input_frame, axis=0)

    return input_tensor, original_frame, (w, h)


def xywh2xyxy(x, y, w, h):
    """将中心坐标转换为角点坐标"""
    x1 = x - w / 2
    y1 = y - h / 2
    x2 = x + w / 2
    y2 = y + h / 2
    return x1, y1, x2, y2


def non_max_suppression(prediction, conf_threshold=0.25, iou_threshold=0.45):
    """非极大值抑制"""
    boxes = []
    scores = []
    class_ids = []

    # 解析预测结果
    prediction = prediction[0]  # 去掉batch维度 [6, 8400]

    # 遍历所有预测框
    for i in range(prediction.shape[1]):
        # 获取类别概率
        class_scores = prediction[4:, i]
        class_id = np.argmax(class_scores)
        confidence = class_scores[class_id]

        # 过滤低置信度框
        if confidence > conf_threshold:
            # 获取边界框坐标 (cx, cy, w, h)
            cx, cy, w, h = prediction[:4, i]

            # 转换为角点坐标
            x1, y1, x2, y2 = xywh2xyxy(cx, cy, w, h)

            boxes.append([x1, y1, x2, y2])
            scores.append(confidence)
            class_ids.append(class_id)

    if len(boxes) == 0:
        return [], [], []

    # 应用NMS
    boxes = np.array(boxes)
    scores = np.array(scores)
    class_ids = np.array(class_ids)

    # 使用OpenCV的NMS
    indices = cv2.dnn.NMSBoxes(boxes.tolist(), scores.tolist(), conf_threshold, iou_threshold)

    if len(indices) > 0:
        indices = indices.flatten()
        return boxes[indices], scores[indices], class_ids[indices]
    else:
        return [], [], []


def scale_boxes(boxes, original_shape, target_shape=640):
    """将边界框从目标尺寸缩放回原始尺寸"""
    if len(boxes) == 0:
        return boxes

    orig_w, orig_h = original_shape
    scale_x = orig_w / target_shape
    scale_y = orig_h / target_shape

    scaled_boxes = boxes.copy()
    scaled_boxes[:, 0] = boxes[:, 0] * scale_x  # x1
    scaled_boxes[:, 1] = boxes[:, 1] * scale_y  # y1
    scaled_boxes[:, 2] = boxes[:, 2] * scale_x  # x2
    scaled_boxes[:, 3] = boxes[:, 3] * scale_y  # y2

    return scaled_boxes


def process_video_frame(session, input_name, output_name, frame, conf_threshold=0.25):
    """处理单帧视频并进行检测"""
    # 预处理帧
    input_tensor, original_frame, original_shape = preprocess_frame(frame)
    if input_tensor is None:
        return None, [], [], []

    # 推理
    try:
        outputs = session.run([output_name], {input_name: input_tensor})
        prediction = outputs[0]
    except Exception as e:
        print(f"❌❌ 推理失败: {e}")
        return None, [], [], []

    # 应用NMS
    boxes, scores, class_ids = non_max_suppression(prediction, conf_threshold)

    # 缩放边界框到原始图像尺寸
    if len(boxes) > 0:
        boxes = scale_boxes(boxes, original_shape)

    return original_frame, boxes, scores, class_ids


def draw_detections(frame, boxes, scores, class_ids, fps=None, frame_count=None, total_objects=None):
    """在帧上绘制检测结果"""
    result_frame = frame.copy()

    # 定义类别名称和颜色
    class_names = {0: 'garlic', 1: 'head'}
    colors = [(0, 255, 0), (255, 0, 0)]  # 绿色: garlic, 红色: head

    # 绘制检测框
    garlic_count = 0
    head_count = 0

    for i, (box, score, class_id) in enumerate(zip(boxes, scores, class_ids)):
        x1, y1, x2, y2 = box.astype(int)

        # 统计数量
        if class_id == 0:
            garlic_count += 1
        else:
            head_count += 1

        # 绘制边界框
        color = colors[class_id]
        cv2.rectangle(result_frame, (x1, y1), (x2, y2), color, 2)

        # 绘制标签
        label = f"{class_names[class_id]}: {score:.2f}"
        label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]

        # 标签背景
        cv2.rectangle(result_frame, (x1, y1 - label_size[1] - 10),
                      (x1 + label_size[0], y1), color, -1)
        # 标签文字
        cv2.putText(result_frame, label, (x1, y1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    # 绘制统计信息
    info_y = 30
    cv2.putText(result_frame, f"Garlic: {garlic_count}", (10, info_y),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(result_frame, f"Head: {head_count}", (10, info_y + 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

    if fps is not None:
        cv2.putText(result_frame, f"FPS: {fps:.1f}", (10, info_y + 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

    if frame_count is not None:
        cv2.putText(result_frame, f"Frame: {frame_count}", (10, info_y + 90),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

    return result_frame, garlic_count, head_count


def process_video(session, input_name, output_name, video_path, output_path=None, conf_threshold=0.25,
                  show_display=True, save_output=True, frame_skip=0):
    """处理视频文件并进行大蒜检测"""

    # 打开视频文件 [6,7](@ref)
    if not os.path.exists(video_path):
        print(f"❌❌ 视频文件不存在: {video_path}")
        return False

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"❌❌ 无法打开视频文件: {video_path}")
        return False

    # 获取视频属性 [6,7](@ref)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    print(f"📹 视频信息: {width}x{height}, FPS: {fps:.2f}, 总帧数: {total_frames}")

    # 设置输出视频 [7](@ref)
    if save_output and output_path:
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    # 性能统计
    frame_count = 0
    processed_count = 0
    start_time = time.time()
    total_garlic = 0
    total_head = 0

    # 跳帧计数器（用于性能优化）[2](@ref)
    skip_counter = 0

    print("🎬 开始处理视频...")
    print("按 'q' 键退出，按 'p' 键暂停")

    paused = False

    while True:
        if not paused:
            ret, frame = cap.read()
            if not ret:
                print("✅ 视频处理完成!")
                break

            # 跳帧处理以提高性能 [2](@ref)
            skip_counter += 1
            if skip_counter <= frame_skip:
                # 如果设置了跳帧，跳过当前帧但还是要写入输出（如果需要）
                if save_output and output_path:
                    out.write(frame)
                continue
            skip_counter = 0

            frame_count += 1
            processed_count += 1

            # 处理当前帧
            processed_frame, boxes, scores, class_ids = process_video_frame(
                session, input_name, output_name, frame, conf_threshold)

            # 计算实时FPS
            current_time = time.time()
            elapsed_time = current_time - start_time
            current_fps = processed_count / elapsed_time if elapsed_time > 0 else 0

            # 绘制检测结果
            if processed_frame is not None:
                result_frame, garlic_count, head_count = draw_detections(
                    processed_frame, boxes, scores, class_ids,
                    fps=current_fps, frame_count=frame_count
                )

                total_garlic += garlic_count
                total_head += head_count

                # 显示结果
                if show_display:
                    cv2.imshow('大蒜检测 - 视频模式', result_frame)

                # 保存输出视频
                if save_output and output_path:
                    out.write(result_frame)

            # 进度显示
            if frame_count % 30 == 0:  # 每30帧显示一次进度
                progress = (frame_count / total_frames) * 100
                print(f"📊 处理进度: {progress:.1f}% ({frame_count}/{total_frames}), 实时FPS: {current_fps:.1f}")

        # 键盘控制
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):  # 退出
            break
        elif key == ord('p'):  # 暂停/继续
            paused = not paused
            print("⏸️ 已暂停" if paused else "▶️ 继续播放")
        elif key == ord('s'):  # 保存当前帧
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            frame_path = f"snapshot_{timestamp}.jpg"
            cv2.imwrite(frame_path, result_frame if processed_frame is not None else frame)
            print(f"📷 截图已保存: {frame_path}")

    # 释放资源 [6,7](@ref)
    cap.release()
    if save_output and output_path:
        out.release()
    cv2.destroyAllWindows()

    # 输出统计信息
    total_time = time.time() - start_time
    avg_fps = processed_count / total_time if total_time > 0 else 0

    print("\n" + "=" * 50)
    print("📈 处理统计信息:")
    print(f"总处理时间: {total_time:.2f}秒")
    print(f"平均FPS: {avg_fps:.2f}")
    print(f"处理帧数: {processed_count}/{total_frames}")
    print(f"总大蒜检测数: {total_garlic}")
    print(f"总大蒜头检测数: {total_head}")

    if save_output and output_path:
        print(f"输出视频已保存: {output_path}")

    return True


def process_camera(session, input_name, output_name, camera_id=0, conf_threshold=0.25):
    """处理摄像头实时流"""

    # 打开摄像头 [8](@ref)
    cap = cv2.VideoCapture(camera_id)
    if not cap.isOpened():
        print(f"❌❌ 无法打开摄像头 {camera_id}")
        return False

    # 设置摄像头参数 [8](@ref)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 30)

    print("📹 摄像头模式已启动")
    print("按 'q' 键退出，按 's' 键保存截图")

    frame_count = 0
    start_time = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            print("❌ 无法从摄像头读取帧")
            break

        frame_count += 1

        # 处理当前帧
        processed_frame, boxes, scores, class_ids = process_video_frame(
            session, input_name, output_name, frame, conf_threshold)

        # 计算FPS
        current_time = time.time()
        fps = frame_count / (current_time - start_time) if (current_time - start_time) > 0 else 0

        # 绘制检测结果
        if processed_frame is not None:
            result_frame, garlic_count, head_count = draw_detections(
                processed_frame, boxes, scores, class_ids, fps=fps
            )

            cv2.imshow('大蒜检测 - 摄像头模式', result_frame)

        # 键盘控制
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('s'):
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            frame_path = f"camera_snapshot_{timestamp}.jpg"
            cv2.imwrite(frame_path, result_frame if processed_frame is not None else frame)
            print(f"📷 摄像头截图已保存: {frame_path}")

    # 释放资源
    cap.release()
    cv2.destroyAllWindows()

    return True


def main():
    """主函数"""
    print("🧄🧄 大蒜检测ONNX模型 - 视频检测模式")
    print("=" * 50)

    # ONNX模型路径
    onnx_path = r"C:\Users\30855\Desktop\trainer\garlic_identify1_.onnx"

    # 1. 加载ONNX模型0
    session, input_name, output_name = load_onnx_model(onnx_path)
    if session is None:
        return

    while True:
        print("\n请选择检测模式:")
        print("1. 视频文件检测")
        print("2. 摄像头实时检测")
        print("3. 退出")

        choice = input("请输入选择 (1/2/3): ").strip()

        if choice == '1':
            # 视频文件检测
            video_path = input("请输入视频文件路径: ").strip()
            output_path = input("请输入输出视频路径(可选，直接回车跳过保存): ").strip()

            if not output_path:
                output_path = None
                save_output = False
            else:
                save_output = True

            # 性能优化选项 [2](@ref)
            frame_skip = input("请输入跳帧数(0-不跳帧, 1-每2帧处理1帧, 以此类推，推荐1-3): ").strip()
            try:
                frame_skip = int(frame_skip) if frame_skip else 0
            except:
                frame_skip = 0
                print("⚠️ 使用默认值: 不跳帧")

            process_video(session, input_name, output_name, video_path, output_path,
                          frame_skip=frame_skip, save_output=save_output)

        elif choice == '2':
            # 摄像头检测
            camera_id = input("请输入摄像头ID(默认0): ").strip()
            try:
                camera_id = int(camera_id) if camera_id else 0
            except:
                camera_id = 0
                print("⚠️ 使用默认摄像头ID: 0")

            process_camera(session, input_name, output_name, camera_id)

        elif choice == '3':
            print("👋 感谢使用，再见!")
            break
        else:
            print("❌ 无效选择，请重新输入!")


if __name__ == "__main__":
    main()