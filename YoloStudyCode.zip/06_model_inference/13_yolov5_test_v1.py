import onnxruntime as ort
import cv2
import numpy as np
import time
from typing import List, Tuple, Dict


class ONNXModelTester:
    def __init__(self, model_path: str, conf_threshold: float = 0.25, iou_threshold: float = 0.45):
        """
        初始化ONNX模型测试器 - 优化版本

        参数:
            model_path: ONNX模型文件路径
            conf_threshold: 置信度阈值
            iou_threshold: 非极大值抑制的IOU阈值
        """
        # 创建推理会话
        self.session = ort.InferenceSession(model_path)

        # 获取输入输出信息
        self.input_name = self.session.get_inputs()[0].name
        self.output_name = self.session.get_outputs()[0].name
        self.input_shape = self.session.get_inputs()[0].shape
        self.output_shape = self.session.get_outputs()[0].shape

        # 模型参数
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold
        self.img_size = (640, 640)

        # 类别名称 - 根据您的需求调整
        self.class_names = {0: 'garlic', 1: 'head'}

        # 新增：大蒜和大蒜头的关联关系
        self.garlic_head_relationship = {
            'garlic': 'head',  # 大蒜对应蒜头
            'head': 'garlic'  # 蒜头对应大蒜
        }

        print(f"模型加载成功!")
        print(f"输入名称: {self.input_name}, 形状: {self.input_shape}")
        print(f"输出名称: {self.output_name}, 形状: {self.output_shape}")
        print(f"检测类别: {self.class_names}")

    def preprocess(self, image: np.ndarray) -> np.ndarray:
        """
        图像预处理：调整大小、归一化、转换通道顺序
        """
        self.orig_shape = image.shape[:2]

        # 调整图像大小到640x640
        img_resized = cv2.resize(image, self.img_size)

        # 转换颜色空间 BGR -> RGB
        img_rgb = cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB)

        # 归一化到0-1范围
        img_normalized = img_rgb.astype(np.float32) / 255.0

        # 转换通道顺序 HWC -> CHW
        img_chw = np.transpose(img_normalized, (2, 0, 1))

        # 添加批次维度
        img_batch = np.expand_dims(img_chw, axis=0)

        return img_batch.astype(np.float32)

    def postprocess(self, outputs: np.ndarray) -> List[Tuple]:
        """
        后处理：解析模型输出，应用置信度阈值和优化的NMS
        """
        # 转换输出形状 [1, 6, 8400] -> [8400, 6]
        predictions = outputs[0].transpose(1, 0)

        detections = []

        for pred in predictions:
            # 提取边界框坐标和类别置信度
            x_center, y_center, width, height = pred[:4]
            class_scores = pred[4:6]

            # 获取最大置信度及其类别
            max_class_score = np.max(class_scores)
            class_id = np.argmax(class_scores)

            # 应用置信度阈值
            if max_class_score < self.conf_threshold:
                continue

            # 转换边界框格式 (xywh -> xyxy)
            x1 = x_center - width / 2
            y1 = y_center - height / 2
            x2 = x_center + width / 2
            y2 = y_center + height / 2

            # 将坐标缩放回原始图像尺寸
            scale_x = self.orig_shape[1] / self.img_size[0]
            scale_y = self.orig_shape[0] / self.img_size[1]

            x1 = int(x1 * scale_x)
            y1 = int(y1 * scale_y)
            x2 = int(x2 * scale_x)
            y2 = int(y2 * scale_y)

            # 确保坐标不超出图像边界
            x1 = max(0, min(x1, self.orig_shape[1]))
            y1 = max(0, min(y1, self.orig_shape[0]))
            x2 = max(0, min(x2, self.orig_shape[1]))
            y2 = max(0, min(y2, self.orig_shape[0]))

            detections.append((x1, y1, x2, y2, max_class_score, class_id))

        # 应用优化的非极大值抑制
        return self.optimized_nms(detections)

    def optimized_nms(self, detections: List[Tuple]) -> List[Tuple]:
        """
        优化的非极大值抑制，确保大蒜和蒜头可以同时检测
        """
        if len(detections) == 0:
            return []

        # 按类别分组
        garlic_detections = [det for det in detections if det[5] == 0]  # garlic
        head_detections = [det for det in detections if det[5] == 1]  # head

        final_detections = []

        # 对大蒜检测应用NMS
        garlic_keep = self.class_aware_nms(garlic_detections)
        final_detections.extend(garlic_keep)

        # 对蒜头检测应用NMS
        head_keep = self.class_aware_nms(head_detections)
        final_detections.extend(head_keep)

        # 处理大蒜和蒜头之间的重叠关系
        final_detections = self.handle_garlic_head_overlap(final_detections)

        return final_detections

    def class_aware_nms(self, detections: List[Tuple]) -> List[Tuple]:
        """
        类别感知的NMS，只对同一类别的检测框进行抑制
        """
        if len(detections) == 0:
            return []

        # 按置信度排序
        detections.sort(key=lambda x: x[4], reverse=True)

        keep = []
        while len(detections) > 0:
            # 取置信度最高的检测框
            best = detections.pop(0)
            keep.append(best)

            # 只与同类别的检测框计算IOU
            remaining = []
            for det in detections:
                iou = self.calculate_iou(best, det)
                if iou < self.iou_threshold:
                    remaining.append(det)

            detections = remaining

        return keep

    def handle_garlic_head_overlap(self, detections: List[Tuple]) -> List[Tuple]:
        """
        处理大蒜和蒜头之间的重叠关系，确保它们可以共存
        """
        garlic_detections = [det for det in detections if det[5] == 0]
        head_detections = [det for det in detections if det[5] == 1]

        final_detections = []
        final_detections.extend(garlic_detections)
        final_detections.extend(head_detections)

        # 如果只有大蒜或只有蒜头被检测到，尝试根据位置关系补充另一个
        if len(garlic_detections) > 0 and len(head_detections) == 0:
            # 为大蒜检测补充蒜头检测
            for garlic in garlic_detections:
                head_detection = self.create_complementary_detection(garlic, target_class=1)
                final_detections.append(head_detection)

        elif len(head_detections) > 0 and len(garlic_detections) == 0:
            # 为蒜头检测补充大蒜检测
            for head in head_detections:
                garlic_detection = self.create_complementary_detection(head, target_class=0)
                final_detections.append(garlic_detection)

        return final_detections

    def create_complementary_detection(self, base_detection: Tuple, target_class: int) -> Tuple:
        """
        创建互补检测框：基于一个检测框创建另一个类别的检测框
        """
        x1, y1, x2, y2, conf, class_id = base_detection

        # 调整检测框大小和位置
        if target_class == 1:  # 创建蒜头检测框（通常比大蒜小）
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            width = int((x2 - x1) * 0.6)  # 蒜头比大蒜小
            height = int((y2 - y1) * 0.6)

            new_x1 = max(0, center_x - width // 2)
            new_y1 = max(0, center_y - height // 2)
            new_x2 = min(self.orig_shape[1], center_x + width // 2)
            new_y2 = min(self.orig_shape[0], center_y + height // 2)

            # 适当降低互补检测框的置信度
            new_conf = max(0.3, conf * 0.8)

        else:  # 创建大蒜检测框（通常比蒜头大）
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            width = int((x2 - x1) * 1.2)  # 大蒜比蒜头大
            height = int((y2 - y1) * 1.2)

            new_x1 = max(0, center_x - width // 2)
            new_y1 = max(0, center_y - height // 2)
            new_x2 = min(self.orig_shape[1], center_x + width // 2)
            new_y2 = min(self.orig_shape[0], center_y + height // 2)

            new_conf = max(0.3, conf * 0.8)

        return (new_x1, new_y1, new_x2, new_y2, new_conf, target_class)

    def calculate_iou(self, box1: Tuple, box2: Tuple) -> float:
        """
        计算两个边界框的IOU (交并比)
        """
        x1_1, y1_1, x2_1, y2_1 = box1[:4]
        x1_2, y1_2, x2_2, y2_2 = box2[:4]

        # 计算交集区域
        x_left = max(x1_1, x1_2)
        y_top = max(y1_1, y1_2)
        x_right = min(x2_1, x2_2)
        y_bottom = min(y2_1, y2_2)

        if x_right < x_left or y_bottom < y_top:
            return 0.0

        intersection_area = (x_right - x_left) * (y_bottom - y_top)

        # 计算并集区域
        area1 = (x2_1 - x1_1) * (y2_1 - y1_1)
        area2 = (x2_2 - x1_2) * (y2_2 - y1_2)
        union_area = area1 + area2 - intersection_area

        return intersection_area / union_area if union_area > 0 else 0.0

    def draw_detections(self, image: np.ndarray, detections: List[Tuple]) -> np.ndarray:
        """
        在图像上绘制检测结果，用不同颜色区分大蒜和蒜头
        """
        result_image = image.copy()

        # 定义颜色 (BGR格式)
        colors = {
            0: (0, 255, 0),  # 绿色 - garlic
            1: (0, 0, 255)  # 红色 - head
        }

        # 先绘制所有检测框
        for det in detections:
            x1, y1, x2, y2, conf, class_id = det

            # 绘制边界框
            color = colors.get(class_id, (255, 255, 255))
            thickness = 3 if class_id == 0 else 2  # 大蒜框更粗
            cv2.rectangle(result_image, (x1, y1), (x2, y2), color, thickness)

            # 绘制标签和置信度
            label = f"{self.class_names[class_id]}: {conf:.2f}"
            label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]

            # 标签背景
            cv2.rectangle(result_image,
                          (x1, y1 - label_size[1] - 10),
                          (x1 + label_size[0], y1),
                          color, -1)

            # 标签文字
            cv2.putText(result_image, label,
                        (x1, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        # 添加统计信息
        garlic_count = len([det for det in detections if det[5] == 0])
        head_count = len([det for det in detections if det[5] == 1])

        info_text = f"Garlic: {garlic_count}, Head: {head_count}"
        cv2.putText(result_image, info_text,
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        return result_image

    def test_image(self, image_path: str, output_path: str = None) -> Dict:
        """
        测试单张图像，返回详细的检测结果
        """
        # 读取图像
        image = cv2.imread(image_path)
        if image is None:
            print(f"错误: 无法读取图像 {image_path}")
            return {}

        print(f"测试图像: {image_path}")
        print(f"原始图像尺寸: {image.shape}")

        # 记录时间
        start_time = time.time()

        # 预处理
        input_data = self.preprocess(image)
        preprocess_time = time.time() - start_time

        # 推理
        inference_start = time.time()
        outputs = self.session.run([self.output_name], {self.input_name: input_data})[0]
        inference_time = time.time() - inference_start

        # 后处理
        postprocess_start = time.time()
        detections = self.postprocess(outputs)
        postprocess_time = time.time() - postprocess_start

        total_time = time.time() - start_time

        # 绘制结果
        result_image = self.draw_detections(image, detections)

        # 显示结果信息
        print(f"预处理时间: {preprocess_time * 1000:.2f}ms")
        print(f"推理时间: {inference_time * 1000:.2f}ms")
        print(f"后处理时间: {postprocess_time * 1000:.2f}ms")
        print(f"总时间: {total_time * 1000:.2f}ms")

        garlic_detections = [det for det in detections if det[5] == 0]
        head_detections = [det for det in detections if det[5] == 1]

        print(f"检测到 {len(garlic_detections)} 个大蒜, {len(head_detections)} 个蒜头")

        # 输出详细信息
        for i, det in enumerate(garlic_detections):
            x1, y1, x2, y2, conf, class_id = det
            print(f"  大蒜 {i + 1}: 置信度 {conf:.3f}, 位置 [{x1}, {y1}, {x2}, {y2}]")

        for i, det in enumerate(head_detections):
            x1, y1, x2, y2, conf, class_id = det
            print(f"  蒜头 {i + 1}: 置信度 {conf:.3f}, 位置 [{x1}, {y1}, {x2}, {y2}]")

        # 保存结果
        if output_path:
            cv2.imwrite(output_path, result_image)
            print(f"结果已保存到: {output_path}")

        # 显示结果
        cv2.imshow('Detection Result', result_image)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

        return {
            'garlic_count': len(garlic_detections),
            'head_count': len(head_detections),
            'total_time': total_time,
            'detections': detections
        }


# 使用示例
if __name__ == "__main__":
    # 替换为您的ONNX模型路径
    MODEL_PATH = r"C:\Users\30855\Desktop\trainer\garlic_identify1.onnx"
    IMAGE_PATH = r"C:\Users\30855\MVS\Data\Image_20251227211047044.bmp"

    # 创建测试器
    tester = ONNXModelTester(MODEL_PATH, conf_threshold=0.2)  # 降低阈值提高检测率

    # 测试图像
    results = tester.test_image(IMAGE_PATH, "optimized_result.jpg")

    # 可以根据结果进一步调整参数
    if results['garlic_count'] == 0 or results['head_count'] == 0:
        print("检测不完整，建议调整置信度阈值或模型参数")