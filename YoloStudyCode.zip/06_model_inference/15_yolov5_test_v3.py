import onnxruntime as ort
import cv2
import numpy as np
import time
import os
import argparse
from typing import List, Tuple, Dict, Optional, Union


class GarlicDetectionModel:
    def __init__(self, model_path: str, conf_threshold: float = 0.25, iou_threshold: float = 0.45):
        """
        大蒜检测模型 - 基于ONNX的YOLO模型

        参数:
            model_path: ONNX模型文件路径
            conf_threshold: 置信度阈值
            iou_threshold: 非极大值抑制的IOU阈值
        """
        # 验证模型文件是否存在
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"模型文件不存在: {model_path}")

        # 创建推理会话
        try:
            # 设置ONNX Runtime执行提供者
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
            self.session = ort.InferenceSession(model_path, providers=providers)
            print("✓ ONNX模型加载成功")
        except Exception as e:
            print(f"⚠ CUDA不可用，使用CPU执行: {e}")
            self.session = ort.InferenceSession(model_path, providers=['CPUExecutionProvider'])

        # 获取模型信息
        self.input_name = self.session.get_inputs()[0].name
        self.output_name = self.session.get_outputs()[0].name
        self.input_shape = self.session.get_inputs()[0].shape

        # 根据模型信息设置参数
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold
        self.img_size = (640, 640)  # YOLO标准输入尺寸

        # 类别名称 - 根据模型元数据设置
        self.class_names = {0: 'garlic', 1: 'head'}
        self.class_colors = {
            0: (0, 255, 0),  # 绿色 - 大蒜
            1: (0, 0, 255)  # 红色 - 蒜头
        }

        print(f"✓ 输入名称: {self.input_name}")
        print(f"✓ 输出名称: {self.output_name}")
        print(f"✓ 输入形状: {self.input_shape}")
        print(f"✓ 检测类别: {self.class_names}")
        print(f"✓ 置信度阈值: {conf_threshold}")
        print(f"✓ IOU阈值: {iou_threshold}")

    def preprocess(self, image: np.ndarray) -> np.ndarray:
        """
        图像预处理：调整大小、归一化、转换通道顺序
        确保输出尺寸严格为 [1, 3, 640, 640]
        """
        # 保存原始图像尺寸
        self.orig_height, self.orig_width = image.shape[:2]

        # 保持宽高比的调整
        img_resized = self.letterbox(image, new_shape=self.img_size)

        # 转换颜色空间 BGR -> RGB
        img_rgb = cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB)

        # 归一化到0-1范围
        img_normalized = img_rgb.astype(np.float32) / 255.0

        # 转换通道顺序 HWC -> CHW
        img_chw = np.transpose(img_normalized, (2, 0, 1))

        # 添加批次维度
        img_batch = np.expand_dims(img_chw, axis=0)

        return img_batch.astype(np.float32)

    def letterbox(self, img: np.ndarray, new_shape=(640, 640), color=(114, 114, 114)) -> np.ndarray:
        """
        保持宽高比的调整大小
        """
        shape = img.shape[:2]  # 当前形状 [高度, 宽度]
        if isinstance(new_shape, int):
            new_shape = (new_shape, new_shape)

        # 计算缩放比例
        r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])

        # 计算等比例缩放后的尺寸
        new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
        dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]

        # 等比例缩放
        img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)

        # 添加填充
        top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
        left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
        img = cv2.copyMakeBorder(img, top, bottom, left, right,
                                 cv2.BORDER_CONSTANT, value=color)

        return img

    def postprocess(self, outputs: np.ndarray) -> List[Tuple]:
        """
        后处理：解析YOLO模型输出
        """
        # 转换输出形状 [1, 6, 8400] -> [8400, 6]
        predictions = outputs[0].transpose(1, 0)

        detections = []

        for pred in predictions:
            # 提取边界框坐标和类别置信度
            x_center, y_center, width, height = pred[:4]
            class_scores = pred[4:6]

            # 获取最大置信度及其类别
            max_class_score = np.max(class_scores)
            class_id = np.argmax(class_scores)

            # 应用置信度阈值
            if max_class_score < self.conf_threshold:
                continue

            # 转换边界框格式 (xywh -> xyxy)
            x1 = x_center - width / 2
            y1 = y_center - height / 2
            x2 = x_center + width / 2
            y2 = y_center + height / 2

            # 将坐标转换回原始图像尺寸
            x1, y1, x2, y2 = self.scale_coordinates((x1, y1, x2, y2))

            detections.append((x1, y1, x2, y2, max_class_score, class_id))

        # 应用非极大值抑制
        return self.non_max_suppression(detections)

    def scale_coordinates(self, coordinates: Tuple[float, float, float, float]) -> Tuple[int, int, int, int]:
        """
        将坐标从640x640缩放回原始图像尺寸
        """
        x1, y1, x2, y2 = coordinates

        # 计算缩放比例
        scale_x = self.orig_width / 640.0
        scale_y = self.orig_height / 640.0

        x1 = int(x1 * scale_x)
        y1 = int(y1 * scale_y)
        x2 = int(x2 * scale_x)
        y2 = int(y2 * scale_y)

        # 确保坐标不超出图像边界
        x1 = max(0, min(x1, self.orig_width))
        y1 = max(0, min(y1, self.orig_height))
        x2 = max(0, min(x2, self.orig_width))
        y2 = max(0, min(y2, self.orig_height))

        return x1, y1, x2, y2

    def non_max_suppression(self, detections: List[Tuple]) -> List[Tuple]:
        """
        非极大值抑制
        """
        if len(detections) == 0:
            return []

        # 按类别分组处理
        garlic_detections = [det for det in detections if det[5] == 0]
        head_detections = [det for det in detections if det[5] == 1]

        # 对每个类别分别应用NMS
        keep_garlic = self._nms_single_class(garlic_detections)
        keep_head = self._nms_single_class(head_detections)

        return keep_garlic + keep_head

    def _nms_single_class(self, detections: List[Tuple]) -> List[Tuple]:
        """
        对单个类别应用NMS
        """
        if len(detections) == 0:
            return []

        # 按置信度排序
        detections.sort(key=lambda x: x[4], reverse=True)

        keep = []
        while detections:
            # 取置信度最高的检测框
            best = detections.pop(0)
            keep.append(best)

            # 计算与其他检测框的IOU
            detections = [det for det in detections
                          if self.calculate_iou(best, det) < self.iou_threshold]

        return keep

    def calculate_iou(self, box1: Tuple, box2: Tuple) -> float:
        """
        计算两个边界框的IOU
        """
        x1_1, y1_1, x2_1, y2_1 = box1[:4]
        x1_2, y1_2, x2_2, y2_2 = box2[:4]

        # 计算交集区域
        x_left = max(x1_1, x1_2)
        y_top = max(y1_1, y1_2)
        x_right = min(x2_1, x2_2)
        y_bottom = min(y2_1, y2_2)

        if x_right < x_left or y_bottom < y_top:
            return 0.0

        intersection_area = (x_right - x_left) * (y_bottom - y_top)

        # 计算并集区域
        area1 = (x2_1 - x1_1) * (y2_1 - y1_1)
        area2 = (x2_2 - x1_2) * (y2_2 - y1_2)
        union_area = area1 + area2 - intersection_area

        return intersection_area / union_area if union_area > 0 else 0.0

    def draw_detections(self, image: np.ndarray, detections: List[Tuple]) -> np.ndarray:
        """
        在图像上绘制检测结果
        """
        result_image = image.copy()

        # 绘制检测框
        for det in detections:
            x1, y1, x2, y2, conf, class_id = det

            # 获取颜色和标签
            color = self.class_colors.get(class_id, (255, 255, 255))
            label = f"{self.class_names[class_id]}: {conf:.2f}"

            # 绘制边界框
            cv2.rectangle(result_image, (x1, y1), (x2, y2), color, 2)

            # 绘制标签背景
            label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
            cv2.rectangle(result_image,
                          (x1, y1 - label_size[1] - 10),
                          (x1 + label_size[0], y1),
                          color, -1)

            # 绘制标签文字
            cv2.putText(result_image, label,
                        (x1, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        # 添加统计信息
        garlic_count = len([d for d in detections if d[5] == 0])
        head_count = len([d for d in detections if d[5] == 1])

        info_text = f"Garlic: {garlic_count}, Head: {head_count}"
        cv2.putText(result_image, info_text,
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        return result_image

    def detect_image(self, image_path: str, output_path: Optional[str] = None,
                     show_result: bool = True) -> Dict:
        """
        检测单张图像
        """
        # 读取图像
        if not os.path.exists(image_path):
            return {"error": f"图像文件不存在: {image_path}"}

        image = cv2.imread(image_path)
        if image is None:
            return {"error": f"无法读取图像: {image_path}"}

        print(f"🔍 检测图像: {os.path.basename(image_path)}")
        print(f"📐 原始尺寸: {image.shape[1]}x{image.shape[0]}")

        # 记录时间
        start_time = time.time()

        try:
            # 预处理
            print("🔄 预处理中...")
            input_data = self.preprocess(image)
            preprocess_time = time.time() - start_time

            # 推理
            print("🤖 模型推理中...")
            inference_start = time.time()
            outputs = self.session.run([self.output_name], {self.input_name: input_data})[0]
            inference_time = time.time() - inference_start

            # 后处理
            print("📊 后处理中...")
            postprocess_start = time.time()
            detections = self.postprocess(outputs)
            postprocess_time = time.time() - postprocess_start

            total_time = time.time() - start_time

            # 统计结果
            garlic_detections = [d for d in detections if d[5] == 0]
            head_detections = [d for d in detections if d[5] == 1]

            # 显示时间信息
            print(f"⏱️ 预处理时间: {preprocess_time * 1000:.1f}ms")
            print(f"⏱️ 推理时间: {inference_time * 1000:.1f}ms")
            print(f"⏱️ 后处理时间: {postprocess_time * 1000:.1f}ms")
            print(f"⏱️ 总时间: {total_time * 1000:.1f}ms")
            print(f"✅ 检测结果: {len(garlic_detections)} 个大蒜, {len(head_detections)} 个蒜头")

            # 绘制结果
            result_image = self.draw_detections(image, detections)

            # 保存结果
            if output_path:
                cv2.imwrite(output_path, result_image)
                print(f"💾 结果保存到: {output_path}")

            # 显示结果
            if show_result:
                cv2.imshow('大蒜检测结果', result_image)
                cv2.waitKey(0)
                cv2.destroyAllWindows()

            return {
                'success': True,
                'garlic_count': len(garlic_detections),
                'head_count': len(head_detections),
                'total_time': total_time,
                'detections': detections,
                'image_size': f"{self.orig_width}x{self.orig_height}"
            }

        except Exception as e:
            return {"error": f"检测过程中出错: {str(e)}"}

    def detect_video(self, video_path: str, output_path: Optional[str] = None,
                     show_fps: bool = True, max_frames: int = 0) -> Dict:
        """
        检测视频文件
        """
        if not os.path.exists(video_path):
            return {"error": f"视频文件不存在: {video_path}"}

        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            return {"error": f"无法打开视频: {video_path}"}

        # 获取视频信息
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        print(f"🎥 视频信息: {os.path.basename(video_path)}")
        print(f"📏 分辨率: {width}x{height}")
        print(f"📈 FPS: {fps}")
        print(f"📊 总帧数: {total_frames}")

        # 设置输出视频
        out = None
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        # 处理视频帧
        frame_count = 0
        total_garlic_count = 0
        total_head_count = 0
        start_time = time.time()

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            if max_frames > 0 and frame_count >= max_frames:
                break

            # 检测当前帧
            frame_start = time.time()

            # 预处理
            input_data = self.preprocess(frame)

            # 推理
            outputs = self.session.run([self.output_name], {self.input_name: input_data})[0]

            # 后处理
            detections = self.postprocess(outputs)

            frame_time = time.time() - frame_start

            # 统计
            garlic_count = len([d for d in detections if d[5] == 0])
            head_count = len([d for d in detections if d[5] == 1])
            total_garlic_count += garlic_count
            total_head_count += head_count

            # 绘制检测结果
            result_frame = self.draw_detections(frame, detections)

            # 显示FPS
            if show_fps:
                fps_text = f"FPS: {1.0 / frame_time:.1f}"
                cv2.putText(result_frame, fps_text, (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

            # 显示处理信息
            info_text = f"Frame: {frame_count}/{total_frames}"
            cv2.putText(result_frame, info_text, (10, 90),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)

            # 写入输出视频
            if out:
                out.write(result_frame)

            # 显示当前帧
            cv2.imshow('大蒜检测 - 视频', result_frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                print("\n⏹️ 用户中断处理")
                break

            frame_count += 1
            if frame_count % 10 == 0:
                print(f"📊 已处理: {frame_count}/{total_frames} 帧", end='\r')

        # 释放资源
        cap.release()
        if out:
            out.release()
        cv2.destroyAllWindows()

        total_time = time.time() - start_time
        avg_fps = frame_count / total_time if total_time > 0 else 0

        print(f"\n✅ 视频处理完成!")
        print(f"📊 总处理帧数: {frame_count}")
        print(f"⏱️ 总处理时间: {total_time:.2f}秒")
        print(f"📈 平均FPS: {avg_fps:.1f}")
        print(f"🧄 平均大蒜数/帧: {total_garlic_count / frame_count if frame_count > 0 else 0:.1f}")
        print(f"🧄 平均蒜头数/帧: {total_head_count / frame_count if frame_count > 0 else 0:.1f}")

        return {
            'success': True,
            'total_frames': frame_count,
            'total_garlic_count': total_garlic_count,
            'total_head_count': total_head_count,
            'total_time': total_time,
            'avg_fps': avg_fps
        }

    def test_model_input(self):
        """
        测试模型输入形状
        """
        print("🧪 测试模型输入...")

        # 创建一个测试图像
        test_image = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        print(f"测试图像形状: {test_image.shape}")

        # 预处理
        input_data = self.preprocess(test_image)
        print(f"预处理后形状: {input_data.shape}")

        # 验证形状
        expected_shape = (1, 3, 640, 640)
        if input_data.shape == expected_shape:
            print("✅ 输入形状正确!")
            return True
        else:
            print(f"❌ 输入形状错误! 期望: {expected_shape}, 实际: {input_data.shape}")
            return False

    def detect_folder(self, folder_path: str, output_folder: Optional[str] = None) -> Dict:
        """
        批量检测文件夹中的所有图片
        """
        if not os.path.exists(folder_path):
            return {"error": f"文件夹不存在: {folder_path}"}

        # 获取所有图片文件
        image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
        image_files = [f for f in os.listdir(folder_path)
                       if os.path.splitext(f)[1].lower() in image_extensions]

        if not image_files:
            return {"error": f"文件夹中没有找到图片文件: {folder_path}"}

        print(f"📁 找到 {len(image_files)} 张图片")

        # 创建输出文件夹
        if output_folder and not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # 处理每张图片
        results = []
        total_garlic = 0
        total_head = 0
        total_time = 0

        for i, image_file in enumerate(image_files):
            image_path = os.path.join(folder_path, image_file)

            print(f"\n📄 处理图片 ({i + 1}/{len(image_files)}): {image_file}")

            output_path = None
            if output_folder:
                output_path = os.path.join(output_folder, f"detected_{image_file}")

            result = self.detect_image(image_path, output_path, show_result=False)

            if 'success' in result and result['success']:
                results.append({
                    'file': image_file,
                    'garlic_count': result['garlic_count'],
                    'head_count': result['head_count'],
                    'time': result['total_time']
                })
                total_garlic += result['garlic_count']
                total_head += result['head_count']
                total_time += result['total_time']

                print(f"✅ 处理完成: {result['garlic_count']} 个大蒜, {result['head_count']} 个蒜头")
            else:
                print(f"❌ 处理失败: {result.get('error', '未知错误')}")

        # 输出统计信息
        print(f"\n{'=' * 50}")
        print(f"📊 批量处理完成!")
        print(f"📁 总处理图片: {len(results)} 张")
        print(f"🧄 总大蒜数: {total_garlic}")
        print(f"🧄 总蒜头数: {total_head}")
        print(f"⏱️ 总处理时间: {total_time:.2f}秒")
        print(f"📈 平均每张图片处理时间: {total_time / len(results) if results else 0:.2f}秒")
        print(f"{'=' * 50}")

        return {
            'success': True,
            'total_images': len(results),
            'total_garlic': total_garlic,
            'total_head': total_head,
            'total_time': total_time,
            'results': results
        }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='大蒜检测系统')
    parser.add_argument('--model', type=str, required=True, help='模型文件路径')
    parser.add_argument('--source', type=str, required=True, help='输入源（图片/视频/文件夹）')
    parser.add_argument('--output', type=str, default='output', help='输出路径')
    parser.add_argument('--conf', type=float, default=0.25, help='置信度阈值')
    parser.add_argument('--iou', type=float, default=0.45, help='IOU阈值')
    parser.add_argument('--mode', choices=['image', 'video', 'folder', 'camera'],
                        default='image', help='检测模式')

    args = parser.parse_args()

    try:
        # 创建检测器
        print("🚀 初始化大蒜检测模型...")
        detector = GarlicDetectionModel(args.model, conf_threshold=args.conf, iou_threshold=args.iou)

        # 测试模型输入
        print("\n" + "=" * 50)
        print("测试模型输入形状")
        print("=" * 50)
        if not detector.test_model_input():
            print("❌ 模型输入测试失败，请检查预处理代码")
            return

        # 根据模式处理
        if args.mode == 'image':
            # 单张图片检测
            if not os.path.exists(args.source):
                print(f"❌ 图片文件不存在: {args.source}")
                return

            output_path = os.path.join(args.output, 'detected_' + os.path.basename(args.source))
            os.makedirs(os.path.dirname(output_path), exist_ok=True)

            print("\n" + "=" * 50)
            print("单张图片检测")
            print("=" * 50)

            result = detector.detect_image(args.source, output_path)

            if 'error' in result:
                print(f"❌ 错误: {result['error']}")
            else:
                print(f"✅ 检测成功!")

        elif args.mode == 'video':
            # 视频检测
            if not os.path.exists(args.source):
                print(f"❌ 视频文件不存在: {args.source}")
                return

            output_path = os.path.join(args.output, 'detected_' + os.path.basename(args.source))
            os.makedirs(os.path.dirname(output_path), exist_ok=True)

            print("\n" + "=" * 50)
            print("视频检测")
            print("=" * 50)

            result = detector.detect_video(args.source, output_path)

            if 'error' in result:
                print(f"❌ 错误: {result['error']}")
            else:
                print(f"✅ 视频处理完成!")

        elif args.mode == 'folder':
            # 文件夹批量处理
            if not os.path.exists(args.source):
                print(f"❌ 文件夹不存在: {args.source}")
                return

            output_folder = os.path.join(args.output, 'batch_results')
            os.makedirs(output_folder, exist_ok=True)

            print("\n" + "=" * 50)
            print("批量图片检测")
            print("=" * 50)

            result = detector.detect_folder(args.source, output_folder)

            if 'error' in result:
                print(f"❌ 错误: {result['error']}")
            else:
                print(f"✅ 批量处理完成!")

        elif args.mode == 'camera':
            # 摄像头实时检测
            print("\n" + "=" * 50)
            print("摄像头实时检测")
            print("=" * 50)
            print("按下 'q' 键退出，按下 's' 键保存当前帧")

            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                print("❌ 无法打开摄像头")
                return

            frame_count = 0
            save_dir = os.path.join(args.output, 'camera_snapshots')
            os.makedirs(save_dir, exist_ok=True)

            while True:
                ret, frame = cap.read()
                if not ret:
                    print("❌ 无法读取摄像头画面")
                    break

                frame_count += 1

                # 每隔5帧处理一次，提高实时性
                if frame_count % 5 == 0:
                    # 预处理
                    input_data = detector.preprocess(frame)

                    # 推理
                    outputs = detector.session.run([detector.output_name],
                                                   {detector.input_name: input_data})[0]

                    # 后处理
                    detections = detector.postprocess(outputs)

                    # 绘制结果
                    result_frame = detector.draw_detections(frame, detections)

                    # 显示处理信息
                    info_text = f"Frame: {frame_count} | Press 'q' to quit"
                    cv2.putText(result_frame, info_text, (10, 120),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                    cv2.imshow('大蒜检测 - 摄像头', result_frame)
                else:
                    cv2.imshow('大蒜检测 - 摄像头', frame)

                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('s'):
                    # 保存当前帧
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    save_path = os.path.join(save_dir, f'snapshot_{timestamp}.jpg')
                    cv2.imwrite(save_path, frame)
                    print(f"📸 已保存快照: {save_path}")

            cap.release()
            cv2.destroyAllWindows()
            print("✅ 摄像头检测结束")

    except Exception as e:
        print(f"❌ 程序运行出错: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # 如果使用命令行参数，取消下面的注释
    # main()

    # 或者使用以下方式直接运行
    MODEL_PATH = r"C:\Users\30855\Desktop\trainer\garlic_identify1.onnx"
    IMAGE_PATH = r"C:\Users\30855\MVS\Data\Image_20251227211047044.bmp"
    OUTPUT_PATH = "detection_result.jpg"

    try:
        print("🚀 初始化大蒜检测模型...")
        detector = GarlicDetectionModel(MODEL_PATH, conf_threshold=0.2)

        # 测试模型输入
        print("\n" + "=" * 50)
        print("测试模型输入形状")
        print("=" * 50)
        if not detector.test_model_input():
            print("❌ 模型输入测试失败，请检查预处理代码")
        else:
            # 检测单张图像
            print("\n" + "=" * 50)
            print("单张图像检测")
            print("=" * 50)
            result = detector.detect_image(IMAGE_PATH, OUTPUT_PATH)

            if 'error' in result:
                print(f"❌ 错误: {result['error']}")
            else:
                print(f"✅ 检测成功!")
                print(f"📊 大蒜数量: {result['garlic_count']}")
                print(f"📊 蒜头数量: {result['head_count']}")
                print(f"⏱️ 处理时间: {result['total_time'] * 1000:.1f}ms")

    except FileNotFoundError as e:
        print(f"❌ 文件错误: {e}")
    except RuntimeError as e:
        print(f"❌ 运行时错误: {e}")
    except Exception as e:
        print(f"❌ 未知错误: {e}")
        import traceback

        traceback.print_exc()