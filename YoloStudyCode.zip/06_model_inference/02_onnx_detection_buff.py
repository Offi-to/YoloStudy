import cv2
import onnxruntime as ort
import numpy as np


class ONNXVideoDetector:
    def __init__(self, onnx_model_path, conf_threshold=0.3):
        self.conf_threshold = conf_threshold

        # 初始化ONNX Runtime
        try:
            so = ort.SessionOptions()
            so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            self.session = ort.InferenceSession(onnx_model_path, so)
            print("ONNX模型加载成功!")
        except Exception as e:
            print(f"ONNX模型加载失败: {e}")
            return

        # 获取模型信息
        self.input_name = self.session.get_inputs()[0].name
        self.output_names = [output.name for output in self.session.get_outputs()]

        # 输入形状 [batch, channels, height, width]
        self.input_shape = self.session.get_inputs()[0].shape
        self.input_height = self.input_shape[2]
        self.input_width = self.input_shape[3]

        print(f"输入形状: {self.input_shape}")
        print(f"输出名称: {self.output_names}")
        print(f"输出形状: {[output.shape for output in self.session.get_outputs()]}")

        # 添加显示窗口尺寸控制
        self.display_width = 3840
        self.display_height = 2160

        # 定义不同类别的颜色
        self.colors = [
            (0, 255, 0), (255, 0, 0), (0, 0, 255), (255, 255, 0),
            (255, 0, 255), (0, 255, 255), (128, 0, 128), (0, 128, 128),
            (255, 165, 0), (128, 128, 0), (255, 192, 203), (0, 128, 255)
        ]

    def preprocess(self, image):
        """预处理图像 - YOLO格式"""
        # 调整大小
        img = cv2.resize(image, (self.input_width, self.input_height))

        # 转换颜色通道 BGR -> RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        # 归一化
        img = img.astype(np.float32) / 255.0

        # 调整维度顺序 HWC -> CHW
        img = np.transpose(img, (2, 0, 1))

        # 添加batch维度
        img = np.expand_dims(img, axis=0)

        return img

    def postprocess(self, outputs, original_shape):
        """改进的后处理逻辑，支持多种YOLO输出格式[1,5](@ref)"""
        detections = []
        original_h, original_w = original_shape[:2]

        for i, output in enumerate(outputs):
            output_data = output[0]  # 移除batch维度

            # 打印输出形状以便调试
            print(f"输出 {i}: 形状 {output_data.shape}")

            # 处理不同的YOLO输出格式
            if len(output_data.shape) == 2:
                # 格式: [num_detections, 6] - 常见于某些YOLO版本
                # 6: [x1, y1, x2, y2, confidence, class_id]
                for j in range(output_data.shape[0]):
                    detection = output_data[j]
                    if len(detection) >= 6:
                        x1, y1, x2, y2, conf, class_id = detection[:6]

                        if conf > self.conf_threshold:
                            # 转换坐标到原始图像尺寸
                            x1 = int(x1 * original_w / self.input_width)
                            y1 = int(y1 * original_h / self.input_height)
                            x2 = int(x2 * original_w / self.input_width)
                            y2 = int(y2 * original_h / self.input_height)

                            # 确保坐标在图像范围内
                            x1 = max(0, min(x1, original_w))
                            y1 = max(0, min(y1, original_h))
                            x2 = max(0, min(x2, original_w))
                            y2 = max(0, min(y2, original_h))

                            if x2 > x1 and y2 > y1:  # 确保是有效的边界框
                                detections.append({
                                    'bbox': [x1, y1, x2, y2],
                                    'confidence': float(conf),
                                    'class_id': int(class_id)
                                })

            elif len(output_data.shape) == 3:
                # 格式: [1, 84, 8400] 或类似 - YOLOv8格式
                # 84 = 4(bbox) + 80(classes) 或类似
                num_classes = output_data.shape[1] - 4
                num_anchors = output_data.shape[2]

                print(f"检测到YOLO格式: {num_classes} 个类别, {num_anchors} 个锚点")

                # 重塑为 [num_anchors, (4 + num_classes)]
                output_data = output_data.reshape(-1, num_anchors).T

                for j in range(output_data.shape[0]):
                    detection = output_data[j]
                    bbox = detection[:4]
                    scores = detection[4:4 + num_classes]

                    # 找到最高分数和对应的类别
                    class_id = np.argmax(scores)
                    confidence = scores[class_id]

                    if confidence > self.conf_threshold:
                        # YOLO格式: [x_center, y_center, width, height]
                        x_center, y_center, width, height = bbox

                        # 转换为左上角和右下角坐标（相对于输入尺寸）
                        x1 = (x_center - width / 2) * self.input_width
                        y1 = (y_center - height / 2) * self.input_height
                        x2 = (x_center + width / 2) * self.input_width
                        y2 = (y_center + height / 2) * self.input_height

                        # 缩放回原始图像尺寸
                        x1 = int(x1 * original_w / self.input_width)
                        y1 = int(y1 * original_h / self.input_height)
                        x2 = int(x2 * original_w / self.input_width)
                        y2 = int(y2 * original_h / self.input_height)

                        # 确保坐标在图像范围内
                        x1 = max(0, min(x1, original_w))
                        y1 = max(0, min(y1, original_h))
                        x2 = max(0, min(x2, original_w))
                        y2 = max(0, min(y2, original_h))

                        if x2 > x1 and y2 > y1:  # 确保是有效的边界框
                            detections.append({
                                'bbox': [x1, y1, x2, y2],
                                'confidence': float(confidence),
                                'class_id': int(class_id)
                            })

        # 应用非极大值抑制(NMS)去除重叠框[5](@ref)
        if len(detections) > 0:
            detections = self.non_max_suppression(detections)

        return detections

    def non_max_suppression(self, detections, iou_threshold=0.5):
        """非极大值抑制 - 去除重叠的检测框[5](@ref)"""
        if len(detections) == 0:
            return []

        # 按置信度排序
        detections = sorted(detections, key=lambda x: x['confidence'], reverse=True)

        keep = []
        suppressed = set()

        for i in range(len(detections)):
            if i in suppressed:
                continue

            keep.append(detections[i])
            bbox1 = detections[i]['bbox']
            area1 = (bbox1[2] - bbox1[0]) * (bbox1[3] - bbox1[1])

            for j in range(i + 1, len(detections)):
                if j in suppressed:
                    continue

                bbox2 = detections[j]['bbox']
                area2 = (bbox2[2] - bbox2[0]) * (bbox2[3] - bbox2[1])

                # 计算交并比(IoU)
                x1 = max(bbox1[0], bbox2[0])
                y1 = max(bbox1[1], bbox2[1])
                x2 = min(bbox1[2], bbox2[2])
                y2 = min(bbox1[3], bbox2[3])

                w = max(0, x2 - x1)
                h = max(0, y2 - y1)
                intersection = w * h
                union = area1 + area2 - intersection
                iou = intersection / union if union > 0 else 0

                if iou > iou_threshold:
                    suppressed.add(j)

        return keep

    def resize_frame(self, frame):
        """调整帧大小以适应显示窗口"""
        h, w = frame.shape[:2]

        # 计算缩放比例
        scale = min(self.display_width / w, self.display_height / h)
        new_w = int(w * scale)
        new_h = int(h * scale)

        # 调整大小
        resized_frame = cv2.resize(frame, (new_w, new_h))
        return resized_frame

    def draw_detection_boxes(self, frame, detections):
        """绘制检测框和标签[6,8](@ref)"""
        for det in detections:
            x1, y1, x2, y2 = det['bbox']
            conf = det['confidence']
            class_id = det['class_id']

            # 根据类别ID选择颜色
            color = self.colors[class_id % len(self.colors)]

            # 绘制边界框
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 3)

            # 绘制角标，让框更明显
            corner_length = min(20, (x2 - x1) // 4, (y2 - y1) // 4)

            # 左上角
            cv2.line(frame, (x1, y1), (x1 + corner_length, y1), color, 3)
            cv2.line(frame, (x1, y1), (x1, y1 + corner_length), color, 3)

            # 创建标签背景
            label = f"Class:{class_id} {conf:.2f}"
            (text_width, text_height), baseline = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)

            # 标签背景位置
            label_bg_y1 = max(y1 - text_height - 10, 0)
            label_bg_x2 = x1 + text_width + 10

            # 绘制标签背景
            cv2.rectangle(frame, (x1, label_bg_y1),
                          (label_bg_x2, y1), color, -1)

            # 绘制标签文字
            cv2.putText(frame, label, (x1 + 5, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

            print(f"检测到物体: 类别ID {class_id}, 置信度 {conf:.3f}, 位置 [{x1}, {y1}, {x2}, {y2}]")

        return frame

    def process_video(self, video_path):
        """处理视频"""
        cap = cv2.VideoCapture(video_path)

        if not cap.isOpened():
            print(f"无法打开视频: {video_path}")
            return

        # 获取视频信息
        original_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        original_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        print(f"视频分辨率: {original_width}x{original_height}")
        print(f"视频FPS: {fps:.2f}")
        print(f"总帧数: {total_frames}")

        # 创建可调整大小的窗口
        cv2.namedWindow('Detection', cv2.WINDOW_NORMAL)
        cv2.resizeWindow('Detection', self.display_width, self.display_height)

        frame_count = 0
        detection_count = 0

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            frame_count += 1

            # 预处理
            input_tensor = self.preprocess(frame)

            # 推理[1](@ref)
            try:
                outputs = self.session.run(self.output_names, {self.input_name: input_tensor})

                # 后处理
                detections = self.postprocess(outputs, frame.shape)

                # 统计检测结果
                if detections:
                    detection_count += len(detections)
                    print(f"第 {frame_count} 帧检测到 {len(detections)} 个物体")
                else:
                    print(f"第 {frame_count} 帧: 未检测到物体")

                # 绘制检测框
                frame_with_boxes = self.draw_detection_boxes(frame.copy(), detections)

            except Exception as e:
                print(f"推理错误: {e}")
                frame_with_boxes = frame.copy()

            # 调整帧大小以适应显示
            display_frame = self.resize_frame(frame_with_boxes)

            # 添加帧信息和检测统计
            cv2.putText(display_frame, f"Frame: {frame_count}/{total_frames}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(display_frame, f"Detections: {len(detections)}", (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(display_frame, f"Total: {detection_count}", (10, 90),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            # 显示帧
            cv2.imshow('Detection', display_frame)

            # 按键控制
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord(' '):  # 空格键暂停/继续
                cv2.waitKey(0)
            elif key == ord('s'):  # 保存当前帧
                cv2.imwrite(f'frame_{frame_count}.jpg', frame_with_boxes)
                print(f"帧已保存: frame_{frame_count}.jpg")

        cap.release()
        cv2.destroyAllWindows()

        # 输出统计信息
        print(f"\n=== 检测统计 ===")
        print(f"总帧数: {frame_count}")
        print(f"总检测数: {detection_count}")
        if frame_count > 0:
            print(f"检测率: {detection_count / frame_count:.2f} 个物体/帧")


# 使用示例
if __name__ == "__main__":
    # 使用ONNX模型
    detector = ONNXVideoDetector("C:/Users/30855/Desktop/buff.onnx", conf_threshold=0.3)
    detector.process_video("C:/Users/30855/Desktop/33ce6a7a9ce0824d56743a1a4af8f560.mp4")