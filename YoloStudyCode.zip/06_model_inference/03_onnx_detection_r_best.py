import cv2
import numpy as np
import onnxruntime as ort
import time
from pathlib import Path


class YOLOPoseDetector:
    def __init__(self, model_path, conf_threshold=0.5, iou_threshold=0.5):
        """
        初始化YOLO姿态检测器

        Args:
            model_path: ONNX模型文件路径
            conf_threshold: 置信度阈值
            iou_threshold: NMS的IOU阈值
        """
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold

        # 初始化ONNX Runtime
        self.session = ort.InferenceSession(model_path)

        # 获取输入输出信息
        self.input_name = self.session.get_inputs()[0].name
        self.output_name = self.session.get_outputs()[0].name

        # 输入尺寸
        self.input_size = (640, 640)

        # 颜色列表用于绘制不同的关键点
        self.colors = [
            (255, 0, 0), (0, 255, 0), (0, 0, 255),
            (255, 255, 0), (255, 0, 255), (0, 255, 255),
            (128, 0, 0), (0, 128, 0), (0, 0, 128),
            (128, 128, 0), (128, 0, 128), (0, 128, 128),
            (255, 128, 0), (255, 0, 128), (128, 255, 0)
        ]

    def preprocess(self, image):
        """
        预处理输入图像
        """
        # 调整图像大小并保持宽高比
        h, w = image.shape[:2]
        scale = min(self.input_size[0] / h, self.input_size[1] / w)
        new_h, new_w = int(h * scale), int(w * scale)

        # 调整图像大小
        resized = cv2.resize(image, (new_w, new_h))

        # 创建填充后的图像
        padded = np.full((self.input_size[0], self.input_size[1], 3), 114, dtype=np.uint8)
        padded[:new_h, :new_w] = resized

        # 转换颜色通道和数据类型
        padded = cv2.cvtColor(padded, cv2.COLOR_BGR2RGB)
        padded = padded.astype(np.float32) / 255.0

        # 转换为CHW格式并添加批次维度
        input_tensor = padded.transpose(2, 0, 1)[np.newaxis, ...]

        return input_tensor, (w, h), scale, (new_w, new_h)

    def postprocess(self, outputs, original_size, scale, resized_size):
        """
        后处理模型输出
        """
        predictions = outputs[0]  # [1, 6, 8400]
        predictions = predictions.squeeze(0)  # [6, 8400]

        # 转置为 [8400, 6]
        predictions = predictions.transpose(1, 0)

        # 过滤低置信度的检测
        conf_mask = predictions[:, 4] > self.conf_threshold
        predictions = predictions[conf_mask]

        if len(predictions) == 0:
            return []

        # 获取边界框坐标 (cx, cy, w, h)
        boxes = predictions[:, :4]

        # 转换边界框格式 (cx, cy, w, h) -> (x1, y1, x2, y2)
        x1 = boxes[:, 0] - boxes[:, 2] / 2
        y1 = boxes[:, 1] - boxes[:, 3] / 2
        x2 = boxes[:, 0] + boxes[:, 2] / 2
        y2 = boxes[:, 1] + boxes[:, 3] / 2

        # 缩放回原始图像尺寸
        scale_x = original_size[0] / resized_size[0]
        scale_y = original_size[1] / resized_size[1]

        x1 = x1 * scale_x
        y1 = y1 * scale_y
        x2 = x2 * scale_x
        y2 = y2 * scale_y

        # 获取置信度
        scores = predictions[:, 4]

        # 应用NMS
        indices = self.non_max_suppression(np.column_stack([x1, y1, x2, y2]), scores)

        results = []
        for idx in indices:
            box = [x1[idx], y1[idx], x2[idx], y2[idx]]
            score = scores[idx]

            # 获取关键点信息（如果有）
            keypoints = []
            if predictions.shape[1] > 5:
                # 假设第5个元素之后是关键点信息
                # 具体格式需要根据您的模型调整
                kpt_data = predictions[idx, 5:]
                # 这里假设关键点格式为 [x1, y1, conf1, x2, y2, conf2, ...]
                for i in range(0, len(kpt_data), 3):
                    if i + 2 < len(kpt_data):
                        kx = kpt_data[i] * scale_x
                        ky = kpt_data[i + 1] * scale_y
                        kconf = kpt_data[i + 2]
                        if kconf > 0.5:  # 关键点置信度阈值
                            keypoints.append((kx, ky, kconf))

            results.append({
                'bbox': box,
                'score': score,
                'keypoints': keypoints
            })

        return results

    def non_max_suppression(self, boxes, scores):
        """
        非极大值抑制
        """
        x1 = boxes[:, 0]
        y1 = boxes[:, 1]
        x2 = boxes[:, 2]
        y2 = boxes[:, 3]

        areas = (x2 - x1) * (y2 - y1)
        order = scores.argsort()[::-1]

        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)

            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])

            w = np.maximum(0.0, xx2 - xx1)
            h = np.maximum(0.0, yy2 - yy1)
            inter = w * h
            ovr = inter / (areas[i] + areas[order[1:]] - inter)

            inds = np.where(ovr <= self.iou_threshold)[0]
            order = order[inds + 1]

        return keep

    def draw_detections(self, image, detections):
        """
        在图像上绘制检测结果
        """
        for detection in detections:
            bbox = detection['bbox']
            score = detection['score']
            keypoints = detection['keypoints']

            # 绘制边界框
            x1, y1, x2, y2 = map(int, bbox)
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)

            # 绘制置信度
            label = f'{score:.2f}'
            cv2.putText(image, label, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            # 绘制关键点
            for i, (x, y, conf) in enumerate(keypoints):
                color = self.colors[i % len(self.colors)]
                cv2.circle(image, (int(x), int(y)), 3, color, -1)
                cv2.putText(image, f'{i}', (int(x), int(y) - 5),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.3, color, 1)

        return image

    def process_video(self, video_path, output_path=None):
        """
        处理视频文件
        """
        # 打开视频
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            print(f"无法打开视频文件: {video_path}")
            return

        # 获取视频信息
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # 设置输出视频
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        frame_count = 0
        start_time = time.time()

        print("开始处理视频...")
        print("按 'q' 键退出，按 'p' 键暂停")

        paused = False

        while True:
            if not paused:
                ret, frame = cap.read()
                if not ret:
                    break

                # 处理帧
                input_tensor, original_size, scale, resized_size = self.preprocess(frame)

                # 推理
                outputs = self.session.run([self.output_name], {self.input_name: input_tensor})

                # 后处理
                detections = self.postprocess(outputs, original_size, scale, resized_size)

                # 绘制结果
                result_frame = self.draw_detections(frame.copy(), detections)

                # 显示FPS
                frame_count += 1
                if frame_count % 30 == 0:
                    elapsed_time = time.time() - start_time
                    fps = frame_count / elapsed_time
                    cv2.putText(result_frame, f'FPS: {fps:.2f}', (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                # 显示检测数量
                cv2.putText(result_frame, f'Detections: {len(detections)}', (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                # 保存或显示结果
                if output_path:
                    out.write(result_frame)

                cv2.imshow('YOLO Pose Detection', result_frame)

            # 键盘控制
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('p'):
                paused = not paused
                print("暂停" if paused else "继续")

        # 清理
        cap.release()
        if output_path:
            out.release()
        cv2.destroyAllWindows()

        print(f"处理完成！共处理 {frame_count} 帧")


def main():
    # 模型路径
    model_path = r"C:\Users\30855\Desktop\buff.onnx"  # 替换为您的模型路径

    # 视频路径
    video_path = r"C:\Users\30855\Desktop\33ce6a7a9ce0824d56743a1a4af8f560.mp4" # 替换为您的视频路径
    output_path = "output_video1.mp4"  # 输出视频路径（可选）

    # 检查文件是否存在
    if not Path(model_path).exists():
        print(f"模型文件不存在: {model_path}")
        return

    if not Path(video_path).exists():
        print(f"视频文件不存在: {video_path}")
        return

    # 创建检测器
    detector = YOLOPoseDetector(
        model_path=model_path,
        conf_threshold=0.5,
        iou_threshold=0.5
    )

    # 处理视频
    detector.process_video(video_path, output_path)


if __name__ == "__main__":
    main()