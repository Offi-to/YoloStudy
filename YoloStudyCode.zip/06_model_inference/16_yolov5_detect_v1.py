import cv2
import numpy as np
import matplotlib.pyplot as plt
from ultralytics import YOLO
import os
import glob
from PIL import Image
import torch


def load_model_and_check():
    """加载训练好的模型并进行检查"""

    # 模型路径 - 根据您的训练配置
    model_path = r"C:\Users\30855\Desktop\trainer\runs\detect\train\weights\best.pt"

    # 检查模型文件是否存在
    if not os.path.exists(model_path):
        print(f"模型文件不存在: {model_path}")
        print("请先完成模型训练或检查路径是否正确")
        return None

    # 加载模型
    try:
        model = YOLO(model_path)
        print("✅ 模型加载成功!")
        print(f"模型类别: {model.names}")
        print(f"模型类别数量: {len(model.names)}")

        # 根据您的ONNX模型信息，类别应该是 {0: 'garlic', 1: 'head'}
        print("确认类别映射:")
        for class_id, class_name in model.names.items():
            print(f"  {class_id}: {class_name}")

        # 检查设备
        device = next(model.parameters()).device
        print(f"模型运行在: {device}")

        return model
    except Exception as e:
        print(f"❌❌ 模型加载失败: {e}")
        return None


def visualize_detection(model, image_path, conf_threshold=0.25):
    """可视化检测结果"""

    # 读取图像
    if not os.path.exists(image_path):
        print(f"❌❌ 图像文件不存在: {image_path}")
        return None

    image = cv2.imread(image_path)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    original_image = image_rgb.copy()

    # 进行预测 - 根据您的ONNX模型输出形状调整参数
    results = model(image_path, conf=conf_threshold, imgsz=640)

    if len(results) == 0:
        print("❌❌ 未检测到任何目标")
        return None

    result = results[0]

    # 创建可视化图像
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8))

    # 显示原始图像
    ax1.imshow(original_image)
    ax1.set_title('原始图像', fontsize=16, fontweight='bold')
    ax1.axis('off')

    # 显示检测结果
    plotted_image = result.plot()
    plotted_image_rgb = cv2.cvtColor(plotted_image, cv2.COLOR_BGR2RGB)
    ax2.imshow(plotted_image_rgb)
    ax2.set_title('检测结果', fontsize=16, fontweight='bold')
    ax2.axis('off')

    # 添加统计信息
    detection_info = f"""
检测统计信息:
- 检测到目标数量: {len(result.boxes)}
- 图像尺寸: {result.orig_shape}
- 推理时间: {result.speed['preprocess'] + result.speed['inference'] + result.speed['postprocess']:.1f}ms
- 模型输出形状: [1, 6, 8400] (根据ONNX模型)
    """

    # 显示每个检测目标的详细信息
    if len(result.boxes) > 0:
        detection_info += "\n检测详情:\n"
        garlic_count = 0
        head_count = 0

        for i, box in enumerate(result.boxes):
            cls_id = int(box.cls)
            conf = box.conf[0].item()
            bbox = box.xyxy[0].cpu().numpy()
            class_name = model.names[cls_id]

            # 统计各类别数量
            if class_name == 'garlic':
                garlic_count += 1
            elif class_name == 'head':
                head_count += 1

            detection_info += f"{i + 1}. {class_name}: 置信度 {conf:.3f}, 位置 {bbox.astype(int)}\n"

        detection_info += f"\n类别统计:\n- garlic(大蒜): {garlic_count}个\n- head(大蒜头): {head_count}个"

    plt.figtext(0.02, 0.02, detection_info, fontsize=10,
                bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray"))

    plt.tight_layout()
    plt.savefig('detection_result.png', dpi=150, bbox_inches='tight')
    plt.show()

    return result


def check_overlapping_detections(model, image_path):
    """专门检查garlic和head的叠加检测情况"""

    results = model(image_path, conf=0.2)  # 使用较低的置信度阈值
    if len(results) == 0:
        return None

    result = results[0]

    if len(result.boxes) < 2:
        print("⚠️ 需要至少2个检测目标来检查叠加情况")
        return None

    # 获取garlic和head的检测结果
    garlic_boxes = []
    head_boxes = []

    for box in result.boxes:
        cls_id = int(box.cls)
        class_name = model.names[cls_id]
        bbox = box.xyxy[0].cpu().numpy()
        conf = box.conf[0].item()

        if class_name == 'garlic':
            garlic_boxes.append((bbox, conf, class_name))
        elif class_name == 'head':
            head_boxes.append((bbox, conf, class_name))

    print(f"🔍🔍 叠加检测分析:")
    print(f"garlic检测数量: {len(garlic_boxes)}")
    print(f"head检测数量: {len(head_boxes)}")

    # 检查叠加关系
    overlap_pairs = []
    for i, (garlic_bbox, garlic_conf, garlic_name) in enumerate(garlic_boxes):
        for j, (head_bbox, head_conf, head_name) in enumerate(head_boxes):
            # 计算IOU（交并比）
            iou = calculate_iou(garlic_bbox, head_bbox)

            # 检查包含关系
            contains = check_containment(garlic_bbox, head_bbox)

            print(f"\ngarlic{i + 1} 和 head{j + 1}:")
            print(f"  IOU: {iou:.3f}")
            print(f"  包含关系: {contains}")
            print(f"  garlic置信度: {garlic_conf:.3f}")
            print(f"  head置信度: {head_conf:.3f}")

            # 记录有重叠的配对
            if iou > 0.1:  # IOU阈值
                overlap_pairs.append((i, j, iou, contains))

    return garlic_boxes, head_boxes, overlap_pairs


def calculate_iou(box1, box2):
    """计算两个边界框的IOU"""
    x11, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2

    # 计算交集区域
    xi1 = max(x11, x1_2)
    yi1 = max(y1_1, y1_2)
    xi2 = min(x2_1, x2_2)
    yi2 = min(y2_1, y2_2)

    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)

    # 计算并集区域
    box1_area = (x2_1 - x11) * (y2_1 - y1_1)
    box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
    union_area = box1_area + box2_area - inter_area

    return inter_area / union_area if union_area > 0 else 0


def check_containment(box1, box2):
    """检查两个边界框的包含关系"""
    x1_1, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2

    # 检查box1是否包含box2
    contains_1_2 = (x1_1 <= x1_2 and y1_1 <= y1_2 and
                    x2_1 >= x2_2 and y2_1 >= y2_2)

    # 检查box2是否包含box1
    contains_2_1 = (x1_2 <= x1_1 and y1_2 <= y1_1 and
                    x2_2 >= x2_1 and y2_2 >= y2_1)

    if contains_1_2:
        return "garlic包含head"
    elif contains_2_1:
        return "head包含garlic"
    else:
        return "无明确包含关系"


def test_on_multiple_images(model, image_folder, num_images=3):
    """在多个图像上测试模型"""

    # 查找图像文件
    image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp']
    image_paths = []

    for ext in image_extensions:
        image_paths.extend(glob.glob(os.path.join(image_folder, ext)))

    if not image_paths:
        print(f"❌❌ 在文件夹 {image_folder} 中未找到图像文件")
        return

    # 限制测试图像数量
    image_paths = image_paths[:num_images]

    print(f"🔍🔍 在 {len(image_paths)} 张图像上测试模型...")

    for i, image_path in enumerate(image_paths):
        print(f"\n{'=' * 50}")
        print(f"测试图像 {i + 1}: {os.path.basename(image_path)}")
        print(f"{'=' * 50}")

        # 可视化检测结果
        result = visualize_detection(model, image_path)

        if result is not None:
            # 检查叠加检测
            check_overlapping_detections(model, image_path)


def analyze_model_output(model, test_image_path):
    """分析模型输出结构"""
    if not os.path.exists(test_image_path):
        print(f"❌❌ 测试图像不存在: {test_image_path}")
        return

    # 进行预测并获取原始输出
    results = model(test_image_path, verbose=False)

    if len(results) > 0:
        result = results[0]
        print("\n📊 模型输出分析:")
        print(f"原始输出形状: {result.orig_shape}")

        if hasattr(result, 'boxes') and result.boxes is not None:
            print(f"检测框数量: {len(result.boxes)}")
            print("检测框详细信息:")
            for i, box in enumerate(result.boxes):
                cls_id = int(box.cls)
                conf = box.conf[0].item()
                bbox = box.xyxy[0].cpu().numpy()
                print(f"  目标{i + 1}: 类别{cls_id}({model.names[cls_id]}), 置信度{conf:.3f}, 位置{bbox.astype(int)}")


def main():
    """主函数"""

    print("🧄🧄 大蒜检测模型检查工具")
    print("=" * 50)

    # 1. 加载模型
    model = load_model_and_check()
    if model is None:
        return

    print("\n" + "=" * 50)
    print("📊📊 模型信息汇总:")
    print("=" * 50)
    print(f"模型路径: runs/detect/train3/weights/best.pt")
    print(f"类别数量: {len(model.names)}")
    print("类别名称:")
    for class_id, class_name in model.names.items():
        print(f"  {class_id}: {class_name}")

    # 2. 分析模型输出结构
    print("\n" + "=" * 50)
    print("🔬🔬 模型输出结构分析")
    print("=" * 50)

    # 请将下面的路径替换为您的测试图像路径
    test_image_path = r"C:\Users\30855\Desktop\trainer\images\train\image_00041.jpg"  # 替换为实际路径

    if os.path.exists(test_image_path):
        analyze_model_output(model, test_image_path)
    else:
        print("⚠️ 请设置正确的测试图像路径")

    # 3. 测试单张图像
    print("\n" + "=" * 50)
    print("🖼🖼🖼️ 单张图像测试")
    print("=" * 50)

    if os.path.exists(test_image_path):
        print(f"测试图像: {test_image_path}")
        result = visualize_detection(model, test_image_path)

        if result is not None:
            # 详细分析叠加检测
            garlic_boxes, head_boxes, overlap_pairs = check_overlapping_detections(model, test_image_path)

            if overlap_pairs:
                print(f"\n🎯 发现 {len(overlap_pairs)} 对有重叠的检测目标")
                for i, j, iou, relation in overlap_pairs:
                    print(f"  garlic{i + 1} 和 head{j + 1}: IOU={iou:.3f}, 关系={relation}")
    else:
        print("⚠️ 请设置正确的测试图像路径")

    # 4. 批量测试（可选）
    print("\n" + "=" * 50)
    print("📸📸 批量图像测试")
    print("=" * 50)

    test_folder = r"C:\Users\30855\Desktop\trainer\images\test"  # 替换为实际文件夹路径
    if os.path.exists(test_folder):
        test_on_multiple_images(model, test_folder, num_images=3)
    else:
        print("⚠️ 请设置正确的测试文件夹路径")

    print("\n✅ 模型检查完成!")


if __name__ == "__main__":
    main()