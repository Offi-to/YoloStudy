import os
import shutil
import random
import re

# 尝试导入sklearn，如果不存在则提示安装
try:
    from sklearn.model_selection import train_test_split
except ImportError:
    print("错误: 未找到 sklearn 模块")
    print("请运行以下命令安装: pip install scikit-learn")
    print("或者: pip install sklearn")
    exit(1)


def split_dataset(images_dir, labels_dir=None, output_dir=None, train_ratio=0.7, val_ratio=0.2, test_ratio=0.1, random_seed=42, name_prefix="image"):
    """
    将数据集划分为训练集、验证集和测试集，并统一图片名称

    Args:
        images_dir (str): 图片文件夹路径
        labels_dir (str): 标签文件夹路径（可选，如果存在的话）
        output_dir (str): 输出文件夹路径
        train_ratio (float): 训练集比例
        val_ratio (float): 验证集比例
        test_ratio (float): 测试集比例
        random_seed (int): 随机种子
        name_prefix (str): 图片名称前缀
    """
    # 验证比例总和
    total_ratio = train_ratio + val_ratio + test_ratio
    if abs(total_ratio - 1.0) > 1e-6:
        print(f"警告: 比例总和应为1.0，当前为 {total_ratio}，将自动调整...")
        # 归一化比例
        train_ratio /= total_ratio
        val_ratio /= total_ratio
        test_ratio /= total_ratio

    # 设置随机种子
    random.seed(random_seed)

    # 获取所有图片文件
    image_extensions = ['.jpg', '.jpeg', '.png',
                        '.bmp', '.tiff', '.tif', '.webp']
    image_files = []

    for filename in os.listdir(images_dir):
        ext = os.path.splitext(filename)[1].lower()
        if ext in image_extensions:
            image_files.append(filename)

    # 检查图片名称是否需要重命名
    name_pattern = re.compile(r'^' + re.escape(name_prefix) + r'_\d+\.\w+$')
    need_rename = not all(name_pattern.match(f) for f in image_files)
    if need_rename:
        print(f"检测到图片名称不统一，将重命名为 {name_prefix}_00001 格式")

    if not image_files:
        print(f"在 {images_dir} 中未找到图片文件")
        return False

    print(f"找到 {len(image_files)} 个图片文件")

    # 如果提供了标签目录，验证图片和标签是否匹配
    label_files = []
    if labels_dir and os.path.exists(labels_dir):
        for filename in os.listdir(labels_dir):
            ext = os.path.splitext(filename)[1].lower()
            if ext == '.txt':  # 假设标签是txt格式
                label_files.append(filename)

        print(f"找到 {len(label_files)} 个标签文件")

        # 验证图片和标签是否一一对应
        image_names = {os.path.splitext(f)[0] for f in image_files}
        label_names = {os.path.splitext(f)[0] for f in label_files}
        missing_labels = image_names - label_names
        missing_images = label_names - image_names

        if missing_labels:
            print(f"警告: 以下图片缺少对应标签: {list(missing_labels)[:10]}...")  # 只显示前10个
        if missing_images:
            print(f"警告: 以下标签缺少对应图片: {list(missing_images)[:10]}...")  # 只显示前10个

    # 创建输出目录
    if output_dir is None:
        output_dir = os.path.join(os.path.dirname(images_dir), "dataset_split")

    os.makedirs(output_dir, exist_ok=True)
    train_dir = os.path.join(output_dir, "train")
    val_dir = os.path.join(output_dir, "val")
    test_dir = os.path.join(output_dir, "test")

    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(val_dir, exist_ok=True)
    os.makedirs(test_dir, exist_ok=True)

    # 创建图片子目录
    train_images_dir = os.path.join(train_dir, "images")
    val_images_dir = os.path.join(val_dir, "images")
    test_images_dir = os.path.join(test_dir, "images")

    os.makedirs(train_images_dir, exist_ok=True)
    os.makedirs(val_images_dir, exist_ok=True)
    os.makedirs(test_images_dir, exist_ok=True)

    # 如果有标签目录，也创建相应的标签子目录
    train_labels_dir = val_labels_dir = test_labels_dir = None
    if labels_dir and os.path.exists(labels_dir):
        train_labels_dir = os.path.join(train_dir, "labels")
        val_labels_dir = os.path.join(val_dir, "labels")
        test_labels_dir = os.path.join(test_dir, "labels")

        os.makedirs(train_labels_dir, exist_ok=True)
        os.makedirs(val_labels_dir, exist_ok=True)
        os.makedirs(test_labels_dir, exist_ok=True)

    # 分割数据集
    if test_ratio > 0:
        # 先分出测试集
        train_val_images, test_images = train_test_split(
            image_files,
            test_size=test_ratio,
            random_state=random_seed
        )

        # 再将剩余数据分为训练集和验证集
        train_ratio_adjusted = train_ratio / (train_ratio + val_ratio)
        train_images, val_images = train_test_split(
            train_val_images,
            test_size=(1 - train_ratio_adjusted),
            random_state=random_seed
        )
    else:
        # 只分训练集和验证集
        train_images, val_images = train_test_split(
            image_files,
            test_size=val_ratio,
            random_state=random_seed
        )
        test_images = []

    print(f"训练集: {len(train_images)} 个文件")
    print(f"验证集: {len(val_images)} 个文件")
    print(f"测试集: {len(test_images)} 个文件")

    # 复制文件到对应目录
    def copy_files(file_list, src_img_dir, dst_img_dir, src_lbl_dir=None, dst_lbl_dir=None, rename=False, prefix="image"):
        for idx, filename in enumerate(file_list):
            # 如果需要重命名
            if rename:
                old_name, ext = os.path.splitext(filename)
                new_filename = f"{prefix}_{idx+1:05d}{ext}"
                dst_img_path = os.path.join(dst_img_dir, new_filename)
            else:
                dst_img_path = os.path.join(dst_img_dir, filename)

            # 复制图片
            src_img_path = os.path.join(src_img_dir, filename)
            shutil.copy2(src_img_path, dst_img_path)
            if rename:
                print(f"复制并重命名图片: {filename} -> {new_filename}")
            else:
                print(f"复制图片: {filename}")

            # 如果有标签文件，也复制标签并重命名
            if src_lbl_dir and dst_lbl_dir:
                old_label_name = os.path.splitext(filename)[0] + '.txt'
                src_lbl_path = os.path.join(src_lbl_dir, old_label_name)
                if os.path.exists(src_lbl_path):
                    if rename:
                        new_label_name = f"{prefix}_{idx+1:05d}.txt"
                        dst_lbl_path = os.path.join(
                            dst_lbl_dir, new_label_name)
                    else:
                        dst_lbl_path = os.path.join(
                            dst_lbl_dir, old_label_name)
                    shutil.copy2(src_lbl_path, dst_lbl_path)
                    if rename:
                        print(
                            f"复制并重命名标签: {old_label_name} -> {new_label_name}")
                    else:
                        print(f"复制标签: {old_label_name}")

    print("正在复制训练集文件...")
    copy_files(train_images, images_dir, train_images_dir,
               labels_dir, train_labels_dir, need_rename, name_prefix)

    print("正在复制验证集文件...")
    copy_files(val_images, images_dir, val_images_dir,
               labels_dir, val_labels_dir, need_rename, name_prefix)

    if test_images:
        print("正在复制测试集文件...")
        copy_files(test_images, images_dir, test_images_dir,
                   labels_dir, test_labels_dir, need_rename, name_prefix)

    # 生成数据集配置文件
    dataset_config = f"""# 数据集配置文件
path: {os.path.abspath(output_dir)}
train: images  # 训练图片文件夹相对于path的路径
val: images  # 验证图片文件夹相对于path的路径
test: images  # 测试图片文件夹相对于path的路径 (可选)

# 类别信息 (根据实际需要修改)
nc:  # 类别数量
names: [ ]  # 类别名称列表，例如 ['person', 'car', 'dog']

# 数据集统计
train_count: {len(train_images)}
val_count: {len(val_images)}
test_count: {len(test_images)}
"""

    config_path = os.path.join(output_dir, "dataset.yaml")
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(dataset_config)

    print(f"数据集划分完成! 输出目录: {output_dir}")
    print(f"数据集配置文件: {config_path}")
    return True


def main():
    print("数据集划分工具")
    print("=" * 40)

    # 获取用户输入
    images_dir = input("请输入图片文件夹路径: ").strip()
    if not os.path.exists(images_dir):
        print(f"错误: 图片文件夹不存在 - {images_dir}")
        return

    labels_dir = input("请输入标签文件夹路径 (可选，直接回车跳过): ").strip()
    if labels_dir and not os.path.exists(labels_dir):
        print(f"警告: 标签文件夹不存在 - {labels_dir}，将只处理图片")
        labels_dir = None

    output_dir = input("请输入输出文件夹路径 (默认为 dataset_split): ").strip()
    if not output_dir:
        output_dir = None

    name_prefix = input("请输入图片名称前缀 (默认为 'image'): ").strip()
    if not name_prefix:
        name_prefix = "image"

    try:
        train_ratio = float(input("请输入训练集比例 (默认 0.7): ").strip() or "0.7")
    except ValueError:
        train_ratio = 0.7

    try:
        val_ratio = float(input("请输入验证集比例 (默认 0.2): ").strip() or "0.2")
    except ValueError:
        val_ratio = 0.2

    try:
        test_ratio = float(input("请输入测试集比例 (默认 0.1): ").strip() or "0.1")
    except ValueError:
        test_ratio = 0.1

    try:
        random_seed = int(input("请输入随机种子 (默认 42): ").strip() or "42")
    except ValueError:
        random_seed = 42

    print(f"图片目录: {images_dir}")
    print(f"标签目录: {labels_dir if labels_dir else '无'}")
    print(f"输出目录: {output_dir if output_dir else 'dataset_split'}")
    print(f"名称前缀: {name_prefix}")
    print(f"训练集比例: {train_ratio}, 验证集比例: {val_ratio}, 测试集比例: {test_ratio}")
    print("-" * 40)

    success = split_dataset(
        images_dir=images_dir,
        labels_dir=labels_dir,
        output_dir=output_dir,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        test_ratio=test_ratio,
        random_seed=random_seed,
        name_prefix=name_prefix
    )

    if success:
        print("\n数据集划分任务完成!")
    else:
        print("\n数据集划分任务失败!")


if __name__ == "__main__":
    main()
