import os
import sys
import argparse
from pathlib import Path


def rename_txt_with_start_index(folder_path, start_index=0, prefix="image", extensions=(".txt",)):
    """
    重命名文件夹中的txt文件，支持指定起始编号

    Args:
        folder_path (str): 包含txt文件的文件夹路径
        start_index (int): 起始编号，默认为0
        prefix (str): 文件名前缀，默认为"image"
        extensions (tuple): 支持的文本文件扩展名
    """
    folder = Path(folder_path)

    if not folder.exists():
        print(f"错误: 文件夹不存在 - {folder_path}")
        return False

    # 获取所有txt文件
    txt_files = []
    for ext in extensions:
        txt_files.extend(list(folder.glob(f"*{ext}")))
        txt_files.extend(list(folder.glob(f"*{ext.upper()}")))

    if not txt_files:
        print(f"在文件夹 {folder_path} 中未找到txt文件")
        return False

    # 按名称排序以确保重命名顺序一致
    txt_files.sort(key=lambda x: x.name)

    print(f"找到 {len(txt_files)} 个txt文件")

    # 重命名文件
    for i, old_file in enumerate(txt_files):
        new_index = start_index + i
        new_name = f"{prefix}{new_index:05d}{old_file.suffix}"
        new_file_path = folder / new_name

        # 处理重名情况
        counter = 1
        while new_file_path.exists() and new_file_path != old_file:
            name_part = f"{prefix}{new_index:05d}_{counter}"
            new_name = f"{name_part}{old_file.suffix}"
            new_file_path = folder / new_name
            counter += 1

        try:
            old_file.rename(new_file_path)
            print(f"重命名: {old_file.name} -> {new_name}")
        except Exception as e:
            print(f"重命名失败 {old_file.name}: {str(e)}")
            return False

    print(f"txt文件重命名完成! 共重命名了 {len(txt_files)} 个文件")
    return True


def main():
    parser = argparse.ArgumentParser(description="重命名文件夹中的txt文件，支持指定起始编号")
    parser.add_argument("folder_path", nargs='?', help="包含txt文件的文件夹路径")
    parser.add_argument("--start_index", type=int,
                        default=0, help="起始编号 (默认: 0)")
    parser.add_argument("--prefix", type=str,
                        default="image", help="文件名前缀 (默认: image)")

    args = parser.parse_args()

    # 如果没有提供文件夹路径，询问用户输入
    if not args.folder_path:
        folder_path_input = input("请输入要重命名txt文件的文件夹路径: ").strip()
        # 移除可能的引号
        folder_path = folder_path_input.strip('"\'\'')
        if not folder_path:
            print("错误: 未提供文件夹路径")
            return
        # 询问起始编号
        try:
            start_index_input = input("请输入起始编号 (默认为0): ").strip()
            start_index = int(start_index_input) if start_index_input else 0
        except ValueError:
            start_index = 0
            print("输入无效，使用默认起始编号 0")
        # 询问前缀
        prefix_input = input("请输入文件名前缀 (默认为'image'): ").strip()
        prefix = prefix_input if prefix_input else "image"
    else:
        folder_path = args.folder_path
        start_index = args.start_index
        prefix = args.prefix

    success = rename_txt_with_start_index(folder_path, start_index, prefix)

    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
