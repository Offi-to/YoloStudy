import cv2
import os


def video_to_frames(video_path, output_dir, base_name="base_b", start_num=1750, frame_interval=30):
    """
    将视频按帧间隔截取为图片

    参数:
    video_path: 视频文件路径
    output_dir: 图片保存目录
    base_name: 图片基础名称，默认为"base_b"
    start_num: 起始编号，默认为1750
    frame_interval: 帧间隔，默认为30（每隔30帧截取一张）
    """

    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 打开视频文件
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print("错误：无法打开视频文件")
        return False

    # 获取视频信息
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = total_frames / fps

    print(f"视频信息：{total_frames}帧, {fps:.2f}fps, 时长：{duration:.2f}秒")
    print(f"截取设置：从{start_num}开始命名，每隔{frame_interval}帧截取一张")

    current_frame = 0
    saved_count = 0
    frame_num = start_num

    while True:
        ret, frame = cap.read()

        if not ret:
            break

        # 每隔frame_interval帧保存一张
        if current_frame % frame_interval == 0:
            # 生成文件名：base_b1750, base_b1751, ...
            filename = f"{base_name}{frame_num}.jpg"
            filepath = os.path.join(output_dir, filename)

            # 保存图片
            cv2.imwrite(filepath, frame)
            saved_count += 1
            frame_num += 1

            print(f"已保存: {filename} (第{current_frame}帧)")

        current_frame += 1

    cap.release()
    print(f"\n完成！共保存了{saved_count}张图片")
    return True


# 使用示例
if __name__ == "__main__":
    # 设置参数
    video_file = r"D:\MvsDatas\MV-CA013-A0UC (J84320541)\r5.avi"  # 替换为你的视频路径
    output_folder = r"D:\MvsDatas\MV-CA013-A0UC (J84320541)\red"  # 图片保存文件夹
    base_name = "base_r"  # 基础名称
    start_number = 3408  # 起始编号
    interval = 8  # 帧间隔（每隔8帧截取一张）

    # 执行截取
    video_to_frames(video_file, output_folder, base_name, start_number, interval)