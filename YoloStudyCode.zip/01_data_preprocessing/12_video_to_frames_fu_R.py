import cv2
import os
import sys

def video_to_frames(video_path, output_dir, base_name="base_b", start_num=1750, frame_interval=30):
    """
    将视频按帧间隔截取为图片

    参数:
    video_path: 视频文件路径
    output_dir: 图片保存目录
    base_name: 图片基础名称，默认为"base_b"
    start_num: 起始编号，默认为1750
    frame_interval: 帧间隔，默认为30（每隔30帧截取一张）
    """

    # 检查视频文件是否存在
    if not os.path.exists(video_path):
        print(f"错误：视频文件不存在 - {video_path}")
        return False

    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 尝试用 OpenCV 的不同后端打开视频
    cap = None
    backends = [
        (cv2.CAP_DSHOW, "DirectShow"),   # Windows 下对 AVI 兼容性最好
        (cv2.CAP_FFMPEG, "FFmpeg"),      # 通用备选
        (cv2.CAP_ANY, "默认后端")         # 让 OpenCV 自己选
    ]

    used_backend = "未知"
    for backend_id, backend_name in backends:
        cap = cv2.VideoCapture(video_path, backend_id)
        if cap.isOpened():
            used_backend = backend_name
            break

    # 如果 OpenCV 完全打不开，尝试用 imageio 作为后备
    if cap is None or not cap.isOpened():
        print("OpenCV 无法打开视频，尝试使用 imageio...")
        try:
            import imageio
            # 使用 imageio 读取视频
            frames = imageio.get_reader(video_path, 'ffmpeg')
            total_frames = frames.count_frames()
            # 获取 fps（imageio 3.x 方法）
            if hasattr(frames, 'get_meta_data'):
                meta = frames.get_meta_data()
                fps = meta.get('fps', 30)
            else:
                fps = 30  # 默认值
            duration = total_frames / fps if fps > 0 else 0

            print(f"视频信息：{total_frames}帧, {fps:.2f}fps, 时长：{duration:.2f}秒")
            print(f"截取设置：从{start_num}开始命名，每隔{frame_interval}帧截取一张")

            saved_count = 0
            frame_num = start_num
            for idx, frame in enumerate(frames):
                if idx % frame_interval == 0:
                    # imageio 返回的帧是 RGB 格式，转成 BGR 以匹配 OpenCV 保存的惯例
                    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                    filename = f"{base_name}{frame_num}.jpg"
                    filepath = os.path.join(output_dir, filename)
                    cv2.imwrite(filepath, frame_bgr)
                    saved_count += 1
                    frame_num += 1
                    print(f"已保存: {filename} (第{idx}帧)")

            print(f"\n完成！共保存了{saved_count}张图片（使用 imageio）")
            return True

        except ImportError:
            print("错误：未安装 imageio，无法使用备用方案。")
            print("请执行: pip install imageio imageio-ffmpeg")
            return False
        except Exception as e:
            print(f"imageio 读取失败: {e}")
            return False

    # 以下是 OpenCV 成功打开后的处理
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    # 有些编码的 total_frames 可能不准确，尝试修正
    if total_frames <= 0:
        print("警告：无法获取总帧数，将直接读取到结束。")
        total_frames = "未知"

    duration = total_frames / fps if isinstance(total_frames, int) and fps > 0 else "未知"
    print(f"使用后端: {used_backend}")
    print(f"视频信息：{total_frames}帧, {fps:.2f}fps, 时长：{duration}秒")
    print(f"截取设置：从{start_num}开始命名，每隔{frame_interval}帧截取一张")

    current_frame = 0
    saved_count = 0
    frame_num = start_num

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if current_frame % frame_interval == 0:
            filename = f"{base_name}{frame_num}.jpg"
            filepath = os.path.join(output_dir, filename)
            cv2.imwrite(filepath, frame)
            saved_count += 1
            frame_num += 1
            print(f"已保存: {filename} (第{current_frame}帧)")

        current_frame += 1

    cap.release()
    print(f"\n完成！共保存了{saved_count}张图片")
    return True


if __name__ == "__main__":
    # ===== 请根据实际情况修改以下参数 =====
    video_file = r"C:\Users\30855\Desktop\R\r_red.avi"   # 视频文件路径
    output_folder = r"C:\Users\30855\Desktop\R\red"      # 输出图片文件夹
    base_name = "r_red"    # 文件名前缀
    start_number = 0       # 起始编号
    interval = 3           # 帧间隔（每隔3帧截取一张）
    # ====================================

    success = video_to_frames(video_file, output_folder, base_name, start_number, interval)
    if not success:
        print("程序未能完成截取，请检查错误信息。")
        sys.exit(1)