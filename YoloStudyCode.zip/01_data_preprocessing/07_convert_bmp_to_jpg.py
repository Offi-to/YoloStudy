import os
from PIL import Image


def simple_convert_bmp_to_jpg(folder_path):
    """简单版本：将文件夹内所有BMP转为JPG，覆盖原文件"""
    for filename in os.listdir(folder_path):
        if filename.endswith('.bmp'):
            bmp_path = os.path.join(folder_path, filename)
            jpg_path = os.path.splitext(bmp_path)[0] + '.jpg'

            with Image.open(bmp_path) as img:
                img.convert('RGB').save(jpg_path, 'JPEG')
            print(f'已转换: {filename}')


# 使用示例
simple_convert_bmp_to_jpg(r"D:\大蒜数据集")