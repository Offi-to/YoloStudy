import os
import sys
from pathlib import Path


def rename_images_with_start_index(folder_path, start_index=0, prefix="image",
                                   extensions=(".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp")):
    """
    重命名文件夹中的图片文件，支持指定起始编号

    Args:
        folder_path (str): 包含图片的文件夹路径
        start_index (int): 起始编号，默认为0
        prefix (str): 文件名前缀，默认为"image"
        extensions (tuple): 支持的图片扩展名
    """
    folder = Path(folder_path)

    if not folder.exists():
        print(f"错误: 文件夹不存在 - {folder_path}")
        return False
    if not folder.is_dir():
        print(f"错误: 路径不是文件夹 - {folder_path}")
        return False

    # 获取所有图片文件
    image_files = []
    for ext in extensions:
        # 同时匹配大小写扩展名
        pattern = f"*{ext}"
        image_files.extend(folder.glob(pattern.lower()))
        image_files.extend(folder.glob(pattern.upper()))

    # 去重并过滤掉文件夹
    image_files = list(set([f for f in image_files if f.is_file()]))

    if not image_files:
        print(f"在文件夹 {folder_path} 中未找到支持的图片文件")
        print(f"支持的扩展名: {', '.join(extensions)}")
        return False

    # 按名称排序以确保重命名顺序一致
    image_files.sort(key=lambda x: x.name)

    print(f"找到 {len(image_files)} 个图片文件")
    print(f"重命名模式: {prefix}{{序号:05d}}{{原扩展名}}")
    print(f"起始序号: {start_index}")
    print("开始重命名...")

    # 重命名逻辑
    success_count = 0
    skipped_files = []

    for i, old_file in enumerate(image_files):
        new_index = start_index + i
        new_name = f"{prefix}{new_index:05d}{old_file.suffix}"
        new_file_path = folder / new_name

        # 如果新旧路径相同，跳过重命名
        if new_file_path == old_file:
            print(f"跳过: {old_file.name} -> 文件名未改变")
            skipped_files.append(old_file.name)
            success_count += 1
            continue

        # 处理重名情况
        counter = 1
        original_new_path = new_file_path
        while new_file_path.exists() and new_file_path != old_file:
            name_part = f"{prefix}{new_index:05d}_{counter}"
            new_name = f"{name_part}{old_file.suffix}"
            new_file_path = folder / new_name
            counter += 1

        try:
            old_file.rename(new_file_path)
            if new_file_path != original_new_path:
                print(f"重命名: {old_file.name} -> {new_name} (避免重名)")
            else:
                print(f"重命名: {old_file.name} -> {new_name}")
            success_count += 1
        except Exception as e:
            print(f"重命名失败 {old_file.name}: {str(e)}")
            continue

    print(f"\n图片重命名完成! 成功: {success_count}/{len(image_files)}")
    if skipped_files:
        print(f"跳过的文件: {len(skipped_files)}个 (文件名未改变)")
    return success_count == len(image_files)


def main():
    """
    直接在这里修改路径和参数，然后运行脚本即可
    """
    # ====== 在这里直接修改你的路径和参数 ======

    # 图片文件夹路径（直接修改这里）
    folder_path = r"C:\Users\30855\Desktop\2026.3.7大蒜数据"

    # 起始编号（默认从0开始）
    start_index = 838

    # 文件名前缀（默认"image"）
    prefix = "garlic_"

    # ======================================

    print("=" * 50)
    print("图片批量重命名工具")
    print("=" * 50)
    print(f"目标文件夹: {folder_path}")
    print(f"起始编号: {start_index}")
    print(f"文件前缀: {prefix}")
    print("=" * 50)

    # 确认操作
    confirm = input("确认开始重命名？(y/n): ")
    if confirm.lower() != 'y':
        print("操作已取消")
        return

    # 执行重命名
    success = rename_images_with_start_index(folder_path, start_index, prefix)

    if not success:
        print("部分文件处理失败，请检查上述错误信息")
        sys.exit(1)
    else:
        print("所有文件处理成功!")


if __name__ == "__main__":
    main()