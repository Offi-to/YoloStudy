import cv2
import os
import sys


def extract_frames(video_path, save_path, frame_interval=10, start_index=0, filename_prefix="frame_"):
    """
    从视频中提取帧并保存为图片

    Args:
        video_path (str): 输入视频路径
        save_path (str): 保存图片的路径
        frame_interval (int): 提取帧的间隔，默认每10帧提取一帧
        start_index (int): 图片名称的起始编号，默认为0
        filename_prefix (str): 图片名称前缀，默认为"frame_"
    """
    # 检查输入视频路径是否存在
    if not os.path.exists(video_path):
        print(f"错误: 视频文件不存在 - {video_path}")
        return False

    # 如果路径不存在则创建路径
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    # 检查视频文件扩展名
    supported_formats = [".mp4", ".avi", ".mov",
                         ".mkv", ".wmv", ".flv", ".webm", ".m4v"]
    file_extension = os.path.splitext(video_path)[1].lower()

    if file_extension not in supported_formats:
        print(f"警告: 视频格式 {file_extension} 可能不受支持，尝试处理...")
    else:
        print(f"检测到支持的视频格式: {file_extension}")

    # 尝试打开视频文件
    video = cv2.VideoCapture(video_path)

    # 检查视频是否成功打开
    if not video.isOpened():
        print(f"错误: 无法打开视频文件 - {video_path}")
        return False

    # 获取视频信息
    total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = video.get(cv2.CAP_PROP_FPS)
    duration = total_frames / fps if fps > 0 else 0

    print(f"视频总帧数: {total_frames}, FPS: {fps:.2f}, 时长: {duration:.2f}秒")

    count = 0
    saved_count = 0

    while True:
        ret, frame = video.read()
        if not ret:
            print("视频读取完成")
            break

        count += 1

        # 每frame_interval帧提取一帧
        if count % frame_interval == 0:
            # 生成文件名
            filename = f"{filename_prefix}{saved_count + start_index:05d}.jpg"
            save_file_path = os.path.join(save_path, filename)

            # 保存帧
            success = cv2.imwrite(save_file_path, frame)
            if success:
                saved_count += 1
                print(f"已保存: {save_file_path}")
            else:
                print(f"保存失败: {save_file_path}")

    # 释放资源
    video.release()
    cv2.destroyAllWindows()

    print(f"提取完成! 共处理了 {count} 帧，保存了 {saved_count} 张图片")
    return True


def process_videos_in_folder(folder_path, save_base_path, frame_interval=10, start_index=0, filename_prefix="frame_"):
    """
    处理文件夹中的所有视频文件

    Args:
        folder_path (str): 包含视频文件的文件夹路径
        save_base_path (str): 保存图片的基础路径
        frame_interval (int): 提取帧的间隔
        start_index (int): 图片名称的起始编号
        filename_prefix (str): 图片名称前缀
    """
    # 检查文件夹是否存在
    if not os.path.exists(folder_path):
        print(f"错误: 文件夹不存在 - {folder_path}")
        return False

    # 支持的视频格式[1](@ref)
    supported_formats = [".mp4", ".avi", ".mov", ".mkv", ".wmv", ".flv", ".webm", ".m4v"]

    # 获取文件夹中所有视频文件[6](@ref)
    video_files = []
    for file in os.listdir(folder_path):
        if os.path.isfile(os.path.join(folder_path, file)):
            file_ext = os.path.splitext(file)[1].lower()
            if file_ext in supported_formats:
                video_files.append(file)

    if not video_files:
        print(f"在文件夹 {folder_path} 中未找到支持的视频文件")
        return False

    print(f"找到 {len(video_files)} 个视频文件:")
    for i, video_file in enumerate(video_files, 1):
        print(f"{i}. {video_file}")

    total_saved = 0
    current_start_index = start_index

    # 处理每个视频文件
    for video_file in video_files:
        video_path = os.path.join(folder_path, video_file)
        video_name = os.path.splitext(video_file)[0]

        # 为每个视频创建单独的子文件夹[1](@ref)
        video_save_path = os.path.join(save_base_path, video_name)
        if not os.path.exists(video_save_path):
            os.makedirs(video_save_path)

        print(f"\n{'=' * 50}")
        print(f"正在处理视频: {video_file}")
        print(f"{'=' * 50}")

        # 使用视频名作为前缀，避免文件名冲突
        video_prefix = f"{filename_prefix}{video_name}_"

        # 提取帧
        success = extract_frames(video_path, video_save_path, frame_interval, current_start_index, video_prefix)

        if success:
            # 计算这个视频保存了多少张图片，用于更新下一个视频的起始索引
            video = cv2.VideoCapture(video_path)
            total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
            video.release()
            frames_saved = total_frames // frame_interval
            total_saved += frames_saved
            current_start_index += frames_saved
        else:
            print(f"处理视频 {video_file} 时出现错误")

    print(f"\n所有视频处理完成! 共处理了 {len(video_files)} 个视频")
    return True


if __name__ == "__main__":
    # 修改为文件夹路径
    input_folder = r"C:\Users\30855\Desktop\2026.1.8大蒜数据集标记"  # 包含视频的文件夹路径
    save_base_path = r"C:\Users\30855\Desktop\2026.1.8大蒜数据集标记"  # 帧保存的基础路径

    # 也可以通过命令行参数传入
    if len(sys.argv) >= 3:
        input_folder = sys.argv[1]
        save_base_path = sys.argv[2]
        frame_interval = int(sys.argv[3]) if len(sys.argv) > 3 else 10
        start_index = int(sys.argv[4]) if len(sys.argv) > 4 else 0
        filename_prefix = sys.argv[5] if len(sys.argv) > 5 else "frame_"
    else:
        frame_interval = 40  # 默认每10帧提取一帧
        start_index = 1702  # 默认起始索引
        filename_prefix = "frame3_"  # 默认文件名前缀

    # 处理文件夹中的所有视频
    success = process_videos_in_folder(input_folder, save_base_path,
                                       frame_interval, start_index, filename_prefix)

    if not success:
        sys.exit(1)

    print("所有视频帧提取任务完成!")