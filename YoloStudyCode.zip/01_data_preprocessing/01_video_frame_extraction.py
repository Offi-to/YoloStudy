import cv2
import os
import sys


def extract_frames(video_path, save_path, frame_interval=10, start_index=0, filename_prefix="frame_"):
    """
    从视频中提取帧并保存为图片

    Args:
        video_path (str): 输入视频路径
        save_path (str): 保存图片的路径
        frame_interval (int): 提取帧的间隔，默认每10帧提取一帧
        start_index (int): 图片名称的起始编号，默认为0
        filename_prefix (str): 图片名称前缀，默认为"frame_"
    """
    # 检查输入视频路径是否存在
    if not os.path.exists(video_path):
        print(f"错误: 视频文件不存在 - {video_path}")
        return False

    # 如果路径不存在则创建路径
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    # 检查视频文件扩展名
    supported_formats = [".mp4", ".avi", ".mov",
                         ".mkv", ".wmv", ".flv", ".webm", ".m4v"]
    file_extension = os.path.splitext(video_path)[1].lower()

    if file_extension not in supported_formats:
        print(f"警告: 视频格式 {file_extension} 可能不受支持，尝试处理...")
    else:
        print(f"检测到支持的视频格式: {file_extension}")

    # 尝试打开视频文件
    video = cv2.VideoCapture(video_path)

    # 检查视频是否成功打开
    if not video.isOpened():
        print(f"错误: 无法打开视频文件 - {video_path}")
        return False

    # 获取视频信息
    total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = video.get(cv2.CAP_PROP_FPS)
    duration = total_frames / fps if fps > 0 else 0

    print(f"视频总帧数: {total_frames}, FPS: {fps:.2f}, 时长: {duration:.2f}秒")

    count = 0
    saved_count = 0

    while True:
        ret, frame = video.read()
        if not ret:
            print("视频读取完成")
            break

        count += 1

        # 每frame_interval帧提取一帧
        if count % frame_interval == 0:
            # 生成文件名
            filename = f"{filename_prefix}{saved_count + start_index:05d}.jpg"
            save_file_path = os.path.join(save_path, filename)

            # 保存帧
            success = cv2.imwrite(save_file_path, frame)
            if success:
                saved_count += 1
                print(f"已保存: {save_file_path}")
            else:
                print(f"保存失败: {save_file_path}")

    # 释放资源
    video.release()
    cv2.destroyAllWindows()

    print(f"提取完成! 共处理了 {count} 帧，保存了 {saved_count} 张图片")
    return True


if __name__ == "__main__":
    # 可以在这里修改视频路径和保存路径
    input_path = r"C:\Users\30855\Desktop\R标\r_red.avi"
    save_path = r"C:\Users\30855\Desktop\R标\red"

    # 也可以通过命令行参数传入
    if len(sys.argv) >= 3:
        input_path = sys.argv[1]
        save_path = sys.argv[2]
        frame_interval = int(sys.argv[3]) if len(sys.argv) > 3 else 10
        start_index = int(sys.argv[4]) if len(sys.argv) > 4 else 0
        filename_prefix = sys.argv[5] if len(sys.argv) > 5 else "frame_"
    else:
        frame_interval = 3  # 默认每10帧提取一帧
        start_index = 0      # 默认起始索引
        filename_prefix = "r_red_"  # 默认文件名前缀

    success = extract_frames(input_path, save_path,
                             frame_interval, start_index, filename_prefix)

    if not success:
        sys.exit(1)

    print("视频帧提取任务完成!")

'''说明：
1. 首先用`cv2.VideoCapture()`打开视频文件，获取一个视频对象`video`；
2. 然后使用`video.read()`读取视频的每一帧，返回一个布尔值`ret`和一帧图像`frame`；
3. 如果`ret`为`True`，说明读取成功，继续执行；
4. 如果`count`模5余0，说明取到了10的倍数帧，就使用`cv2.imwrite()`将该帧图像保存为jpg文件，文件名为`frame_数字.jpg`；
5. 最后用`video.release()`释放视频资源，用`cv2.destroyAllWindows()`关闭所有窗口。
注意：以上代码只适用于opencv版本为3.x及以上，如果使用opencv2.x版本，请将`cv2.destroyAllWindows()`改为`cv2.cv.DestroyAllWindows()`。
'''
